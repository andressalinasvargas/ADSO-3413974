# Sistema de Gestión — Supermercado "La Esquina"

Repositorio de documentación del proyecto. Este repositorio es la fuente de verdad documental. Todo cambio debe pasar por rama, Pull Request y revisión; no se trabaja directamente sobre `dev`, `qa` ni `main`.

**Caso de estudio:** Supermercado La Esquina — Neiva, Huila  
**Propietario:** Don Carlos Ríos  
**Equipo:** Andrés Salinas Vargas · Kevin Arguello · Paula Sofía Claros · Jhorman Pascuas Lara · Joaquín  
**Instructor:** Jesús Ariel González Bonilla · Ficha: 3413974

## Reglas rápidas

- Leer [CONTRIBUTING.md](./CONTRIBUTING.md) antes de agregar o mover documentos.
- Registrar cada archivo nuevo en el `README.md` de su sección.
- No publicar contraseñas, tokens, datos personales ni información sensible.
- Mantener fuente editable y exportación para cada diagrama.
- Usar `99-archive/` para preservar documentos deprecados; no eliminar historia sin acuerdo del equipo.

## Estructura y estado

| Sección | Descripción | Estado |
|---------|-------------|--------|
| [00-governance](./00-governance/) | Reglas, convenciones y criterios del repo | 🟢 |
| [01-context](./01-context/) | Contexto del negocio, alcance y glosario | 🟢 |
| [02-domain](./02-domain/) | Mapa de dominio, entidades y eventos | 🟢 |
| [03-product](./03-product/) | Visión, roadmap y backlog de producto | 🟢 |
| [04-requirements](./04-requirements/) | Requisitos funcionales, no funcionales y casos de uso | 🟢 |
| [05-architecture](./05-architecture/) | Visión de arquitectura y despliegue | 🟢 |
| [06-data](./06-data/) | Diccionario de datos, modelos y migración | 🟢 |
| [07-api](./07-api/) | Guía de API y autenticación | 🟢 |
| [08-uml](./08-uml/) | Diagramas UML (pendiente de archivos gráficos) | 🟡 |
| [09-microservices](./09-microservices/) | No aplica en v1.0 (sistema monolítico) | 🟡 |
| [10-devops](./10-devops/) | Setup local, CI/CD y entornos | 🟢 |
| [11-quality](./11-quality/) | Estrategia de pruebas y revisión | 🟢 |
| [12-ux-ui](./12-ux-ui/) | Sistema de diseño, navegación y wireframes | 🟢 |
| [13-operations](./13-operations/) | Observabilidad, incidentes y backups | 🟢 |
| [14-training](./14-training/) | Manuales de usuario, admin y onboarding | 🟢 |
| [15-project-control](./15-project-control/) | Backlog técnico, riesgos y dependencias | 🟢 |
| [99-archive](./99-archive/) | Documentos deprecados | 🟡 |

## Estado de íconos
- 🔴 Pendiente — 🟡 En progreso — 🟢 Completo — ⚫ Deprecado

## Documentos de gobierno

- [Guía de contribución](./CONTRIBUTING.md)
- [Reglas de documentación](./00-governance/documentation-rules.md)
- [Convenciones de Git](./00-governance/git-conventions.md)
- [Seguridad documental](./00-governance/security-rules.md)
- [Definition of Ready](./00-governance/definition-of-ready.md)
- [Definition of Done](./00-governance/definition-of-done.md)
