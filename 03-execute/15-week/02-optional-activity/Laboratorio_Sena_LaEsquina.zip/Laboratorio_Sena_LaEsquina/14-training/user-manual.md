# User Manual

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Manual de usuario — Cajero (Marta)

### Cómo entrar al sistema
1. Abrir el navegador (Chrome o Firefox).
2. Escribir la dirección del sistema en la barra de arriba.
3. Ingresar el usuario y la contraseña.
4. Presionar "Ingresar".

### Cómo registrar una venta
1. En el menú principal, presionar **Ventas**.
2. Presionar **Nueva venta**.
3. Buscar cada producto por nombre en el buscador.
4. Ingresar la cantidad que lleva el cliente.
5. Ingresar el dinero que entregó el cliente en el campo "Recibido".
6. Verificar que el cambio es correcto.
7. Presionar **Confirmar venta**.

> Si un producto no tiene suficiente cantidad, el sistema avisará en rojo y no dejará continuar.

### Cómo registrar un fiado
1. En el menú principal, presionar **Fiados**.
2. Buscar el nombre del cliente en la lista.
3. Si el cliente no está, presionar **Nuevo cliente** e ingresar el nombre y teléfono.
4. Seleccionar los productos del fiado y las cantidades.
5. Presionar **Registrar fiado**.

### Cómo cerrar sesión
- Presionar el botón **Salir** en la esquina superior derecha.
- El sistema también cierra la sesión solo después de 30 minutos sin actividad.
