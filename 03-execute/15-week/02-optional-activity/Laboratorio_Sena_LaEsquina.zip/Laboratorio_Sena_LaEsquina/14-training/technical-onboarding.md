# Technical Onboarding

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Para quien se une al equipo de desarrollo

### Primer día
1. Leer el archivo `README.md` en la raíz del repositorio.
2. Leer `00-governance/git-conventions.md` para entender cómo se trabaja.
3. Leer `01-context/overview.md` para entender el proyecto.
4. Clonar el repositorio siguiendo los pasos de `10-devops/local-setup.md`.

### Segunda lectura obligatoria
- `01-context/scope.md` — qué incluye y qué no incluye el sistema.
- `04-requirements/functional.md` — qué debe hacer el sistema.
- `02-domain/entities-and-rules.md` — las reglas del negocio que el código debe respetar.

### Cómo pedir ayuda
- Abrir un issue en GitHub describiendo el problema o la duda.
- Preguntar en el canal del equipo antes de tomar decisiones que afecten la arquitectura.
- Nunca tomar decisiones importantes solo; consultar primero.

### Regla de oro
Ningún cambio va directo a `main`. Todo pasa por rama → Pull Request → revisión → fusión.
