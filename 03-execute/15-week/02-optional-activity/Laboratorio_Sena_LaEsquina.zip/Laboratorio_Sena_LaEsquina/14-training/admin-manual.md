# Admin Manual

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Manual del administrador — Don Carlos

El administrador puede hacer todo lo que hace el cajero, más las siguientes funciones:

### Cómo agregar un producto al inventario
1. En el menú principal, presionar **Inventario**.
2. Presionar **Agregar producto**.
3. Llenar: nombre, categoría, precio de venta, cantidad disponible y stock mínimo.
4. Presionar **Guardar**.

### Cómo actualizar el precio de un producto
1. En el menú principal, presionar **Inventario**.
2. Buscar el producto por nombre.
3. Presionar **Editar**.
4. Cambiar el precio y presionar **Guardar**.

### Cómo ver el reporte de ventas
1. En el menú principal, presionar **Reportes**.
2. Seleccionar el período: hoy, esta semana o este mes.
3. El sistema muestra el total vendido y los productos más vendidos.

### Cómo crear un usuario nuevo
1. En el menú principal, presionar **Usuarios**.
2. Presionar **Nuevo usuario**.
3. Ingresar nombre, rol (administrador o cajero) y contraseña.
4. Presionar **Guardar**.

### Cómo marcar un fiado como pagado
1. En el menú principal, presionar **Fiados**.
2. Buscar el cliente.
3. Ver la lista de fiados pendientes.
4. Presionar **Marcar como pagado** en el fiado correspondiente.
