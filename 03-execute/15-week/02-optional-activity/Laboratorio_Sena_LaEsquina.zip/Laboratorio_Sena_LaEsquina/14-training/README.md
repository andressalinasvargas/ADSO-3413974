# Capacitación

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

Manuales de uso para cajero, administrador y nuevos integrantes del equipo de desarrollo.

## Archivos

- user-manual.md — Manual del cajero (Marta)
- admin-manual.md — Manual del administrador (don Carlos)
- technical-onboarding.md — Guía para nuevos desarrolladores
