# Deployment

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Entorno de producción

El sistema se despliega en un servidor accesible por internet. Don Carlos y Marta acceden desde el navegador del computador del negocio.

```
[Computador del negocio]
       │
       │  Navegador web (Chrome / Firefox / Edge)
       │
       ▼
[Servidor en internet]  ←── donde vive el sistema
       │
       ▼
[Base de datos]  ←── donde se guarda toda la información
```

## Requisitos del computador del negocio

- Conexión a internet estable.
- Navegador web actualizado (Chrome, Firefox o Edge).
- No se necesita instalar ningún programa adicional.

## Entornos

| Entorno | Para qué se usa |
|---|---|
| Desarrollo (local) | El equipo desarrolla y prueba aquí antes de subir cambios. |
| Pruebas (QA) | Se verifica que todo funcione correctamente antes de publicar. |
| Producción | El entorno real donde trabaja don Carlos y Marta. |

## Proceso de publicación

1. El desarrollador termina una función en su computador.
2. La sube a la rama `dev` del repositorio.
3. Se prueba en el entorno de QA.
4. Si pasa las pruebas, se aprueba y pasa a `main`.
5. Se publica en producción.
