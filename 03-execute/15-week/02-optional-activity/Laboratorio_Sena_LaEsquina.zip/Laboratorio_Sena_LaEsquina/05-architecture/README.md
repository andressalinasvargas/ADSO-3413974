# Arquitectura

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

Visión de la arquitectura monolítica del sistema, aspectos transversales y despliegue.

## Archivos

- overview.md — Capas, módulos y decisiones de diseño
- cross-cutting.md — Seguridad, manejo de errores y rendimiento
- deployment.md — Entornos y proceso de publicación
