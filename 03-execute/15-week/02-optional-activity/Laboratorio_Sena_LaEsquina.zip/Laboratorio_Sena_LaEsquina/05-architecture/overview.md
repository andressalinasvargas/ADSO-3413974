# Architecture Overview

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Tipo de arquitectura

El sistema es una **aplicación web monolítica** en su versión 1.0. Se eligió este enfoque porque el negocio es pequeño, el equipo de desarrollo es reducido y una arquitectura más compleja (microservicios) agregaría complejidad innecesaria en esta etapa.

## Capas del sistema

```
┌─────────────────────────────────┐
│         Navegador web           │  Chrome / Firefox / Edge
│     (interfaz del usuario)      │
└────────────────┬────────────────┘
                 │ HTTP / HTTPS
┌────────────────▼────────────────┐
│        Servidor web             │  Recibe las peticiones del navegador
│        (Backend)                │  Procesa la lógica del negocio
│                                 │  Devuelve respuestas
└────────────────┬────────────────┘
                 │ Consultas SQL
┌────────────────▼────────────────┐
│       Base de datos             │  Guarda toda la información:
│       (Persistencia)            │  productos, ventas, clientes, fiados
└─────────────────────────────────┘
```

## Módulos del sistema

| Módulo | Qué hace |
|---|---|
| Ventas | Registra cada transacción con el cliente. Calcula totales y cambio. |
| Inventario | Gestiona el catálogo de productos y sus existencias. Lanza alertas de stock mínimo. |
| Cuentas por cobrar | Registra y hace seguimiento de fiados por cliente. |
| Pedidos | Registra pedidos a proveedores y su estado. |
| Reportes | Genera resúmenes de ventas e inventario por período. |
| Seguridad | Controla el acceso por usuario y rol. Cierra sesión por inactividad. |

## Decisiones de diseño principales

- **Sistema web:** accesible desde cualquier navegador sin instalar nada, según RNF-02.
- **Un solo servidor:** arquitectura simple adecuada al volumen del negocio (~42-74 transacciones diarias).
- **Roles diferenciados:** Administrador y Cajero con permisos distintos, según RF-06.
- **Sin modo offline:** el sistema requiere internet, según RN-02.
