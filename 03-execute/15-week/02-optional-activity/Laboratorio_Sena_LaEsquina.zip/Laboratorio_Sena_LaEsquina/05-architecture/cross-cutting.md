# Cross-Cutting Concerns

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Seguridad

- Todo acceso al sistema requiere usuario y contraseña (RF-05).
- Las contraseñas se guardan cifradas, nunca en texto plano.
- La sesión se cierra automáticamente tras 30 minutos de inactividad.
- El cajero no puede acceder a configuración, precios ni eliminación de registros (RF-06).

## Registro de actividad

- Toda operación queda registrada con: usuario, fecha, hora y tipo de movimiento (RF-11).
- Esto permite saber quién hizo qué y cuándo, especialmente cuando hay más de un usuario activo.

## Manejo de errores

- Si falta un campo obligatorio, el sistema resalta el campo en rojo y no permite continuar.
- Si hay un producto duplicado, el sistema pregunta antes de crear uno nuevo.
- Si la conexión falla al confirmar una operación, el sistema avisa y pide reintentar.
- El sistema nunca pierde datos de forma silenciosa.

## Rendimiento

- El tiempo de carga de cualquier pantalla no debe superar los 3 segundos (RNF-03).
- Las operaciones más frecuentes (registrar una venta, consultar inventario) deben ser las más rápidas.

## Compatibilidad

- El sistema debe funcionar en Chrome, Firefox y Edge en sus versiones actuales (RNF-02).
- No requiere instalar ningún software adicional en el computador del negocio.
