# UML

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

Repositorio de diagramas UML del Supermercado La Esquina. Los diagramas se agregarán durante el desarrollo del sistema.

## Convenciones

- Fuentes editables en `diagrams/source/`
- Exportaciones en `diagrams/exports/` en formato `.svg` o `.png`
- Todo diagrama registrado en [diagram-index.md](./diagram-index.md)

## Archivos

| Archivo | Descripción | Estado |
|---|---|---|
| [diagram-index.md](./diagram-index.md) | Lista de diagramas planificados y su estado | 🟡 |
| [diagrams/source/](./diagrams/source/) | Archivos editables | 🔴 Pendiente |
| [diagrams/exports/](./diagrams/exports/) | Exportaciones finales | 🔴 Pendiente |
