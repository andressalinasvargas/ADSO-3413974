# Diagram Index

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Diagramas planificados para el proyecto

| Diagrama | Tipo | Módulo | Estado |
|---|---|---|---|
| Casos de uso del sistema | Caso de uso | General | 🔴 Pendiente |
| Modelo de datos | Entidad-Relación | Base de datos | 🔴 Pendiente |
| Flujo de registro de venta | Secuencia | Ventas | 🔴 Pendiente |
| Flujo de registro de fiado | Secuencia | Cuentas por cobrar | 🔴 Pendiente |
| Flujo de alerta de stock | Actividad | Inventario | 🔴 Pendiente |
| Clases del sistema | Clases | General | 🔴 Pendiente |

## Nota

Los archivos de diagrama (`.drawio`, `.puml`, `.svg`) se agregarán en las carpetas `diagrams/source/` y `diagrams/exports/` a medida que se desarrollen.
