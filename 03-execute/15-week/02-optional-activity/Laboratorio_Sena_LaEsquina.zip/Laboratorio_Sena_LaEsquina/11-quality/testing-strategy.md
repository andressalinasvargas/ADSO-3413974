# Testing Strategy

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Qué se prueba y cómo

| Tipo de prueba | Qué verifica | Ejemplo |
|---|---|---|
| Prueba funcional | Que el sistema hace lo que dice cada requisito. | Registrar una venta y verificar que el inventario se descuenta. |
| Prueba de flujos de excepción | Que los errores se manejan bien. | Intentar vender un producto sin stock y verificar que el sistema no lo permite. |
| Prueba de usabilidad | Que don Carlos y Marta pueden usar el sistema sin ayuda. | Pedirle a don Carlos que registre una venta solo, sin instrucciones previas. |
| Prueba de compatibilidad | Que el sistema funciona en los tres navegadores. | Abrir el sistema en Chrome, Firefox y Edge y verificar que todo se ve igual. |
| Prueba de rendimiento | Que las pantallas cargan en menos de 3 segundos. | Medir el tiempo de carga del módulo de ventas. |

## Casos de prueba prioritarios (Fase 1)

| ID | Caso | Resultado esperado |
|---|---|---|
| CP-01 | Registrar una venta con 3 productos. | La venta se guarda, el inventario baja, el cambio es correcto. |
| CP-02 | Intentar vender más unidades de las disponibles. | El sistema bloquea y muestra advertencia en rojo. |
| CP-03 | Agregar un producto y que el stock quede en el mínimo. | El sistema muestra alerta de stock mínimo. |
| CP-04 | Registrar un fiado y verificar la deuda del cliente. | El fiado queda en estado "pendiente" y la deuda del cliente aumenta. |
| CP-05 | Intentar iniciar sesión con contraseña incorrecta. | El sistema no permite el acceso y muestra mensaje de error. |
| CP-06 | Intentar que el cajero modifique un precio. | El sistema no muestra esa opción al cajero. |
