# Calidad

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

Estrategia de pruebas por módulo y lista de verificación para revisión de documentos.

## Archivos

- testing-strategy.md — Tipos de prueba y casos prioritarios de la Fase 1
- code-review.md — Lista de verificación para aprobar un Pull Request
