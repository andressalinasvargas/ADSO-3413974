# Code Review

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Lista de verificación para revisar un documento

Antes de aprobar un Pull Request, quien revisa debe confirmar que:

- [ ] El encabezado del archivo tiene estado, fecha, autor y equipo.
- [ ] El estado (🔴/🟡/🟢) refleja correctamente el avance real del documento.
- [ ] El contenido corresponde al caso de estudio (Supermercado La Esquina).
- [ ] No hay secciones con `<!-- Contenido pendiente -->` sin justificación.
- [ ] La redacción es clara y sin tecnicismos innecesarios.
- [ ] Las tablas tienen encabezados y están bien formateadas.
- [ ] Si hay requisitos referenciados (ej: RF-01), existen en `04-requirements/functional.md`.
- [ ] El archivo sigue la convención de nombre: `kebab-case.md`.

## Reglas del proceso de revisión

- Todo cambio necesita al menos una aprobación de otro integrante antes de fusionarse.
- No se aprueba un documento con secciones pendientes marcadas como 🟢.
- Los comentarios de revisión deben ser constructivos y específicos.
