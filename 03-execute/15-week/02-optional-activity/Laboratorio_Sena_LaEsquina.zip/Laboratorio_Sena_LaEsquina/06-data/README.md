# Datos

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

Diccionario de datos, modelo relacional y estrategia de carga inicial.

## Archivos

- data-dictionary.md — Tablas y campos del sistema
- models.md — Modelo relacional y relaciones entre tablas
- migration-strategy.md — Pasos de la carga inicial de datos
