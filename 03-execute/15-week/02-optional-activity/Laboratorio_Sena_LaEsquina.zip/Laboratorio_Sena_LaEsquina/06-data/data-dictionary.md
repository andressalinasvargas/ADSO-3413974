# Data Dictionary

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Tabla: productos

| Campo | Tipo | Obligatorio | Descripción |
|---|---|:---:|---|
| id | Entero (autoincremental) | Sí | Identificador único del producto. |
| nombre | Texto (100 caracteres) | Sí | Nombre del producto. Debe ser único en el catálogo. |
| categoria | Texto (50 caracteres) | No | Categoría del producto (ej: bebidas, abarrotes, aseo). |
| precio_venta | Decimal | Sí | Precio al que se vende al cliente. |
| precio_compra | Decimal | No | Precio al que se compra al proveedor. |
| cantidad_disponible | Entero | Sí | Cantidad actual en inventario. No puede ser negativa. |
| stock_minimo | Entero | Sí | Cantidad mínima antes de generar alerta. |
| activo | Booleano | Sí | Indica si el producto está disponible para la venta. |

## Tabla: ventas

| Campo | Tipo | Obligatorio | Descripción |
|---|---|:---:|---|
| id | Entero (autoincremental) | Sí | Identificador único de la venta. |
| fecha | Fecha y hora | Sí | Fecha y hora en que se registró la venta. |
| total | Decimal | Sí | Total calculado automáticamente. |
| monto_recibido | Decimal | Sí | Monto entregado por el cliente. |
| cambio | Decimal | Sí | Diferencia entre monto recibido y total. |
| usuario_id | Entero | Sí | Usuario que registró la venta. |

## Tabla: detalle_ventas

| Campo | Tipo | Obligatorio | Descripción |
|---|---|:---:|---|
| id | Entero (autoincremental) | Sí | Identificador único del detalle. |
| venta_id | Entero | Sí | Venta a la que pertenece este detalle. |
| producto_id | Entero | Sí | Producto vendido. |
| cantidad | Entero | Sí | Cantidad vendida de ese producto. |
| precio_unitario | Decimal | Sí | Precio del producto al momento de la venta. |
| subtotal | Decimal | Sí | cantidad × precio_unitario. |

## Tabla: clientes

| Campo | Tipo | Obligatorio | Descripción |
|---|---|:---:|---|
| id | Entero (autoincremental) | Sí | Identificador único del cliente. |
| nombre | Texto (100 caracteres) | Sí | Nombre del cliente con fiado. |
| telefono | Texto (20 caracteres) | No | Número de teléfono de contacto. |
| deuda_total | Decimal | Sí | Suma de todos los fiados pendientes del cliente. |

## Tabla: fiados

| Campo | Tipo | Obligatorio | Descripción |
|---|---|:---:|---|
| id | Entero (autoincremental) | Sí | Identificador único del fiado. |
| cliente_id | Entero | Sí | Cliente al que se le fió. |
| fecha | Fecha y hora | Sí | Fecha en que se registró el fiado. |
| total | Decimal | Sí | Monto total del fiado. |
| estado | Texto | Sí | Estado del fiado: pendiente o pagado. |
| usuario_id | Entero | Sí | Usuario que registró el fiado. |

## Tabla: usuarios

| Campo | Tipo | Obligatorio | Descripción |
|---|---|:---:|---|
| id | Entero (autoincremental) | Sí | Identificador único del usuario. |
| nombre | Texto (100 caracteres) | Sí | Nombre completo del usuario. |
| rol | Texto | Sí | Rol del usuario: administrador o cajero. |
| contrasena | Texto (cifrado) | Sí | Contraseña cifrada. Nunca se guarda en texto plano. |
| activo | Booleano | Sí | Indica si el usuario puede iniciar sesión. |
