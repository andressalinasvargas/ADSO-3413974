# Data Models

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Modelo relacional (diagrama en texto)

```
usuarios
  id, nombre, rol, contrasena, activo

productos
  id, nombre, categoria, precio_venta, precio_compra,
  cantidad_disponible, stock_minimo, activo

ventas
  id, fecha, total, monto_recibido, cambio, usuario_id → usuarios.id

detalle_ventas
  id, venta_id → ventas.id, producto_id → productos.id,
  cantidad, precio_unitario, subtotal

clientes
  id, nombre, telefono, deuda_total

fiados
  id, cliente_id → clientes.id, fecha, total, estado, usuario_id → usuarios.id

detalle_fiados
  id, fiado_id → fiados.id, producto_id → productos.id,
  cantidad, precio_unitario, subtotal

pedidos
  id, proveedor, fecha, estado, usuario_id → usuarios.id

detalle_pedidos
  id, pedido_id → pedidos.id, producto_id → productos.id,
  cantidad_pedida, cantidad_recibida
```

## Relaciones principales

| Relación | Tipo | Descripción |
|---|---|---|
| ventas → detalle_ventas | 1 a muchos | Una venta tiene varios productos. |
| fiados → detalle_fiados | 1 a muchos | Un fiado tiene varios productos. |
| pedidos → detalle_pedidos | 1 a muchos | Un pedido tiene varios productos. |
| clientes → fiados | 1 a muchos | Un cliente puede tener varios fiados. |
| usuarios → ventas | 1 a muchos | Un usuario puede registrar muchas ventas. |
| usuarios → fiados | 1 a muchos | Un usuario puede registrar muchos fiados. |
