# Migration Strategy

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Situación actual

Don Carlos no tiene datos digitales. Toda su información está en:
- Un cuaderno de ventas (sin formato definido).
- Una lista de productos escrita a mano (sin precios actualizados).
- Dos libretas de fiados (una de don Carlos y otra de Marta).
- Recibos de proveedores en papel.

## Estrategia de migración

Como no hay datos digitales previos, no hay migración técnica de base de datos. La puesta en marcha consiste en **carga inicial manual**:

| Paso | Qué se hace | Responsable | Tiempo estimado |
|---|---|---|---|
| 1 | Levantar el listado de todos los productos con nombre, categoría, precio y cantidad actual. | Don Carlos + equipo | 1-2 días |
| 2 | Cargar los productos al sistema uno por uno usando el módulo de inventario. | Equipo de desarrollo | 1 día |
| 3 | Registrar los 9 clientes con fiado activo identificados en la revisión documental. | Don Carlos | 2-3 horas |
| 4 | Crear los dos usuarios del sistema: don Carlos (administrador) y Marta (cajera). | Equipo de desarrollo | 15 minutos |
| 5 | Capacitación de don Carlos y Marta en el uso del sistema. | Equipo de desarrollo | 2 horas máximo (RNF-01) |
| 6 | Período de uso paralelo: seguir con el cuaderno mientras se verifica que el sistema funciona correctamente. | Don Carlos | 1 semana |
| 7 | Cierre del cuaderno manual y uso exclusivo del sistema. | Don Carlos | — |
