# Overview

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974 | Instructor: Jesús Ariel González Bonilla

## Contexto institucional

El Supermercado La Esquina es un negocio familiar ubicado en el barrio El Centro de la ciudad de Neiva, Huila. Con más de diez años de funcionamiento, es atendido por su propietario don Carlos Ríos, su esposa Marta y un empleado ocasional. Ofrece productos de la canasta familiar, abarrotes, bebidas y artículos de aseo a los residentes del sector.

El negocio tiene una clientela fija y registra un promedio de $348.000 en ventas diarias, según el seguimiento de 10 días hábiles realizado durante la fase de observación. Todos sus procesos administrativos se realizan de forma manual: cuaderno de ventas, libreta de fiados, revisión visual del inventario y pedidos a proveedores por llamada telefónica.

## Problema

La gestión manual del supermercado genera cinco problemas concretos que afectan la operación diaria y los ingresos del negocio:

- **Inventario sin control:** don Carlos revisa el inventario de memoria o mirando los estantes físicamente. En dos de los diez días observados hubo agotados que causaron ventas perdidas.
- **Ventas sin registro formal:** las ventas se anotan en cuaderno sin formato. Los cálculos se hacen con calculadora, lo que provoca errores en el cobro y demoras en la atención al cliente.
- **Cuentas por cobrar desorganizadas:** los fiados se registran en dos libretas distintas (don Carlos y Marta), generando confusión y pérdidas económicas confirmadas. Se encontraron 9 fiados activos sin fechas claras.
- **Pedidos sin trazabilidad:** los pedidos a proveedores se hacen únicamente por teléfono, sin dejar registro escrito de lo pedido, la fecha ni el estado de entrega.
- **Sin reportes:** don Carlos no tiene forma de saber cuánto vendió en una semana, qué productos se venden más ni en qué días hay más demanda.

## Objetivos

- Desarrollar un sistema web sencillo, accesible desde cualquier navegador, que permita al Supermercado La Esquina gestionar digitalmente sus operaciones principales.
- Registrar ventas con cálculo automático de totales y cambio.
- Controlar el inventario en tiempo real con alertas de stock mínimo.
- Gestionar cuentas por cobrar (fiados) centralizadas por cliente.
- Registrar y hacer seguimiento de pedidos a proveedores.
- Generar reportes de ventas e inventario por período.
- Reducir errores, ahorrar tiempo y apoyar la toma de decisiones con información organizada.

## Referencias

- Acuerdo 009 de 2024
- SRS v1.0 — Sistema de Gestión Supermercado La Esquina — Abril 2026
