# Scope

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Lo que el sistema SÍ incluye (v1.0)

- **Módulo de ventas:** registro de transacciones con cálculo automático de totales y cambio.
- **Módulo de inventario:** catálogo de productos, actualización en tiempo real y alertas de stock mínimo.
- **Módulo de cuentas por cobrar:** registro y seguimiento de fiados por cliente con historial.
- **Módulo de pedidos:** registro de pedidos a proveedores con estado de seguimiento (pendiente / recibido / cancelado).
- **Módulo de reportes:** reportes de ventas e inventario por período de tiempo.
- **Módulo de seguridad:** gestión de usuarios con roles (administrador y cajero) y control de acceso.

## Lo que el sistema NO incluye (v1.0)

- Facturación electrónica DIAN (puede implementarse en versiones futuras).
- Aplicación móvil nativa (solo versión web responsiva).
- Integración con pasarelas de pago electrónico (tarjeta, Nequi, etc.).
- Funcionamiento sin conexión a internet (modo offline).

## Supuestos

- El sistema opera en un dispositivo con acceso a internet (computador de escritorio o portátil).
- Los usuarios (don Carlos y Marta) tienen conocimientos básicos de uso de computador y navegador web.
- Los datos iniciales (productos, precios, clientes con fiado) serán ingresados manualmente en la puesta en marcha.

## Restricciones

- El sistema requiere conexión a internet para funcionar. No se contempla modo offline.
- No se generarán facturas electrónicas en esta versión.
- La interfaz debe ser usable sin capacitación técnica mayor a 2 horas.
