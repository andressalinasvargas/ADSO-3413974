# Glossary

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

| Término | Definición |
|---|---|
| Administrador | Usuario con acceso completo al sistema. En este caso, don Carlos Ríos, propietario del supermercado. |
| Cajero | Usuario con permisos para registrar ventas, consultar inventario y registrar fiados. No puede modificar precios ni eliminar registros. |
| Fiado | Venta a crédito en la que el cliente se lleva los productos y paga después. Se registra en el módulo de cuentas por cobrar. |
| Stock mínimo | Cantidad mínima configurada para un producto. Cuando el inventario llega a ese nivel, el sistema emite una alerta automática. |
| Inventario | Registro del catálogo de productos del supermercado con nombre, categoría, precio y cantidad disponible. |
| Canasta familiar | Conjunto de productos básicos de consumo diario que ofrece el supermercado (alimentos, aseo, bebidas). |
| Proveedor | Empresa o persona que suministra productos al supermercado. Los pedidos se registran y hacen seguimiento en el módulo de pedidos. |
| Reporte | Resumen generado por el sistema que muestra información de ventas o inventario por período de tiempo. |
| Rol | Perfil de usuario que define qué puede hacer y ver dentro del sistema. Los roles son: Administrador y Cajero. |
| Sesión | Tiempo activo de un usuario en el sistema. Se cierra automáticamente tras 30 minutos de inactividad. |
