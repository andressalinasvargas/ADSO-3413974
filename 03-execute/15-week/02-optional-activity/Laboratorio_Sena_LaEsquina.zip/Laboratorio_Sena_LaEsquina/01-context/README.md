# Contexto

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

Descripción del negocio, alcance del sistema y glosario de términos del Supermercado La Esquina.

## Archivos

- overview.md — Descripción del negocio, problema y objetivos
- scope.md — Qué incluye y no incluye el sistema, supuestos y restricciones
- glossary.md — Glosario de términos del proyecto
