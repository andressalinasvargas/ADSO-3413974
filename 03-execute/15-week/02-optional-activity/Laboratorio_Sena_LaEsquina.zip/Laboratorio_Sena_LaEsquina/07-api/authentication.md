# Authentication

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Cómo funciona el acceso

1. El usuario ingresa su nombre de usuario y contraseña en la pantalla de inicio de sesión.
2. El sistema verifica las credenciales contra la base de datos.
3. Si son correctas, crea una sesión activa para ese usuario.
4. El sistema recuerda el rol del usuario (administrador o cajero) durante toda la sesión.
5. La sesión se cierra automáticamente tras 30 minutos de inactividad (RF-05).

## Roles y permisos

| Acción | Administrador | Cajero |
|---|:---:|:---:|
| Registrar ventas | ✓ | ✓ |
| Consultar inventario | ✓ | ✓ |
| Registrar fiados | ✓ | ✓ |
| Modificar precios | ✓ | ✗ |
| Eliminar registros | ✓ | ✗ |
| Gestionar usuarios | ✓ | ✗ |
| Ver reportes | ✓ | ✗ |
| Crear pedidos | ✓ | ✗ |

## Seguridad de contraseñas

- Las contraseñas nunca se guardan en texto plano.
- Se usa una función de cifrado (hash) antes de guardarlas.
- Si un usuario olvida su contraseña, solo el administrador puede restablecerla.
