# API

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

Guía de convenciones de la API y control de acceso por rol de usuario.

## Archivos

- guidelines.md — Rutas, convenciones y formato de respuesta
- authentication.md — Roles, permisos y seguridad de contraseñas
