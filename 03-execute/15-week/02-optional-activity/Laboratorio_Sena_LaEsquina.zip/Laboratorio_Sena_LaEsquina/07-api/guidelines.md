# API Guidelines

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Convenciones generales

- Todas las rutas van en minúsculas y con guiones: `/cuentas-por-cobrar`, no `/CuentasPorCobrar`.
- Las respuestas siempre son en formato JSON.
- Las fechas van en formato ISO 8601: `2026-04-11T10:30:00`.
- Los montos van en pesos colombianos (COP) como número entero sin decimales.

## Módulos y rutas principales

| Módulo | Ruta base | Operaciones |
|---|---|---|
| Ventas | `/ventas` | Registrar, listar, ver detalle |
| Inventario | `/productos` | Crear, editar, listar, buscar, desactivar |
| Cuentas por cobrar | `/fiados` | Registrar, listar por cliente, marcar como pagado |
| Pedidos | `/pedidos` | Crear, listar, actualizar estado |
| Reportes | `/reportes` | Ventas por período, productos más vendidos |
| Usuarios | `/usuarios` | Crear, editar, desactivar |
| Sesión | `/auth` | Iniciar sesión, cerrar sesión |

## Estructura de respuesta estándar

```json
{
  "ok": true,
  "datos": { },
  "mensaje": "Operación completada"
}
```

En caso de error:
```json
{
  "ok": false,
  "error": "Descripción del problema"
}
```
