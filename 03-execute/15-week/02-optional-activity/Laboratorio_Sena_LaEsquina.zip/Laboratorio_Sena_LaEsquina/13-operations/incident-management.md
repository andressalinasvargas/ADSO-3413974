# Incident Management

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Qué hacer si algo falla

| Problema | Qué hacer primero |
|---|---|
| El sistema no carga | Verificar que el computador tiene internet. Intentar recargar la página. |
| No puedo iniciar sesión | Verificar que el usuario y contraseña son correctos. Contactar al administrador. |
| Una venta no se guardó | Revisar el historial de ventas para confirmar. Registrarla de nuevo si no aparece. |
| El inventario no actualizó | Recargar la página de inventario. Si persiste, contactar al equipo de desarrollo. |
| El sistema está muy lento | Cerrar otras pestañas del navegador. Verificar la conexión a internet. |

## Contacto de soporte

Para problemas que no se resuelven solos, contactar al equipo de desarrollo del proyecto (Ficha 3413974, SENA Neiva).
