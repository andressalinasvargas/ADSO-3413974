# Operaciones

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

Monitoreo del sistema, gestión de incidentes y política de copias de seguridad.

## Archivos

- observability.md — Qué se monitorea y cómo se registra la actividad
- incident-management.md — Qué hacer cuando algo falla
- backup-and-recovery.md — Copias de seguridad y recuperación
