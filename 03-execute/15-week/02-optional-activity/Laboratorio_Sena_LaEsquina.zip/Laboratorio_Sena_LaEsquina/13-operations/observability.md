# Observability

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Qué se monitorea

| Indicador | Por qué es importante |
|---|---|
| El sistema responde | Si el sistema cae, don Carlos no puede registrar ventas. |
| Tiempo de carga de pantallas | Debe ser menos de 3 segundos (RNF-03). |
| Errores registrados | Cualquier falla queda en un log para revisarla. |
| Sesiones activas | Saber cuándo y quién usa el sistema. |

## Registros del sistema (logs)

Toda operación importante queda registrada con: usuario, fecha, hora y tipo de acción. Esto permite revisar qué pasó si algo sale mal.

Ejemplos de registros:
- `2026-04-11 10:32:15 | carlos | VentaConfirmada | ID:247 | Total:$14.100`
- `2026-04-11 10:45:02 | sistema | StockMinimo | Producto:Azucar | Cantidad:2`
- `2026-04-11 11:00:00 | sistema | SesionCerrada | Usuario:marta | Inactividad`
