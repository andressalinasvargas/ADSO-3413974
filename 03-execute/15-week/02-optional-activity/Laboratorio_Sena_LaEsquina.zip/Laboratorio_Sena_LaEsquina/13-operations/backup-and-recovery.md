# Backup and Recovery

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Copias de seguridad

- La base de datos del sistema se respalda automáticamente una vez al día.
- Las copias se guardan en un lugar diferente al servidor principal.
- Se conservan copias de los últimos 7 días.

## Qué se respalda

- Todos los productos del inventario.
- Historial completo de ventas.
- Registro de clientes y fiados.
- Pedidos a proveedores.
- Usuarios del sistema.

## Recuperación

Si el servidor falla y se pierde información, el equipo de desarrollo puede restaurar la última copia de seguridad. El máximo de información que se puede perder es de un día (la del día del fallo, si no se había respaldado aún).
