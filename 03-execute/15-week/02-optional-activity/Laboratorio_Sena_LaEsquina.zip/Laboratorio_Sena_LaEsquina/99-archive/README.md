# Archivo Histórico

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

Documentos y decisiones que ya no están vigentes. Se conservan para no perder el historial del proyecto.

## Archivos

- deprecated/ — Documentos deprecados
- old-decisions/ — Decisiones antiguas que ya no aplican
