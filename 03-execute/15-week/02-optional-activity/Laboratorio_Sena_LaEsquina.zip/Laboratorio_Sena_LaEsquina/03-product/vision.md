# Product Vision

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Visión del producto

Desarrollar un sistema web sencillo, accesible desde cualquier navegador, que permita al Supermercado La Esquina gestionar digitalmente sus operaciones principales: registro de ventas, control de inventario, cuentas por cobrar y pedidos a proveedores, con el objetivo de reducir errores, ahorrar tiempo y apoyar la toma de decisiones con información organizada y en tiempo real.

## Para quién es

| Segmento | Necesidad |
|---|---|
| Don Carlos Ríos (administrador) | Conocer el estado real del negocio: ventas del día, productos agotados, fiados pendientes. |
| Marta Ríos (cajera) | Registrar ventas rápido y sin errores; anotar fiados de forma centralizada. |
| Empleado ocasional | Operar la caja en días pico sin depender de la memoria de don Carlos. |

## Propuesta de valor

> Para el Supermercado La Esquina, que hoy maneja toda su información de forma manual en cuadernos y libretas, el sistema de gestión es una herramienta web que centraliza ventas, inventario, fiados y pedidos en un solo lugar. A diferencia de seguir operando con cuadernos, el sistema elimina errores de cobro, evita agotados no detectados y le da a don Carlos visibilidad real sobre su negocio por primera vez en más de diez años.

## Métricas de éxito

- El tiempo de cierre de caja diario pasa de 20-35 minutos a menos de 5 minutos.
- Los agotados no detectados se reducen a cero en las dos primeras semanas de uso.
- Don Carlos puede ver el reporte de ventas de la semana en menos de 1 minuto.
- El 91.6% de aceptación potencial registrado en la encuesta se traduce en uso activo del sistema.
