# Product Backlog

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Backlog priorizado

| # | Historia | Módulo | Fase | Prioridad |
|---|---|---|---|---|
| 1 | Como cajero, quiero registrar una venta rápido para no hacer esperar al cliente. | Ventas | 1 | Alta |
| 2 | Como administrador, quiero ver cuánto queda de cada producto para saber qué pedir. | Inventario | 1 | Alta |
| 3 | Como sistema, quiero avisar cuando un producto llegue al mínimo para evitar agotados. | Inventario | 1 | Alta |
| 4 | Como cajero, quiero registrar un fiado con nombre del cliente para no usar libreta. | Cuentas por cobrar | 1 | Alta |
| 5 | Como administrador, quiero iniciar sesión con contraseña para proteger la información. | Seguridad | 1 | Alta |
| 6 | Como administrador, quiero crear usuarios con roles para que Marta no pueda borrar registros. | Seguridad | 1 | Alta |
| 7 | Como cajero, quiero que el sistema calcule el cambio solo para no equivocarme. | Ventas | 1 | Alta |
| 8 | Como administrador, quiero crear un pedido al proveedor para dejar registro escrito. | Pedidos | 2 | Media |
| 9 | Como administrador, quiero ver las ventas de la semana en un reporte para tomar decisiones. | Reportes | 2 | Media |
| 10 | Como administrador, quiero actualizar el precio de un producto desde una pantalla sencilla. | Inventario | 2 | Media |
| 11 | Como administrador, quiero ver quién hizo cada movimiento en el sistema. | Historial | 3 | Baja |
