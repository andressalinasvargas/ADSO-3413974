# Producto

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

Visión del producto, roadmap por fases y backlog de historias de usuario.

## Archivos

- vision.md — Visión general y propuesta de valor
- roadmap.md — Fases de desarrollo (1, 2 y 3)
- product-backlog.md — 11 historias de usuario priorizadas
