# Roadmap

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Fase 1 — Núcleo del sistema (prioridad alta, ≥20 puntos)

Módulos que deben estar listos en la primera entrega porque el negocio los necesita ya:

- RF-01 Registro de ventas
- RF-02 Control de inventario
- RF-03 Alertas de stock mínimo
- RF-04 Cuentas por cobrar (fiados)
- RF-05 Inicio de sesión seguro
- RF-06 Gestión de usuarios
- RF-07 Cálculo automático de cambio
- RNF-01 Usabilidad (transversal a toda la fase)

## Fase 2 — Ampliación (prioridad media, 12-16 puntos)

- RF-08 Gestión de pedidos a proveedores
- RF-09 Reportes de ventas por período
- RF-10 Actualización de precios con historial
- RNF-02 Compatibilidad web verificada en Chrome, Firefox y Edge

## Fase 3 — Mejoras (prioridad baja, ≤9 puntos)

- RF-11 Historial de movimientos por usuario
- RNF-03 Rendimiento optimizado (carga < 3 segundos)

## Fuera de alcance (versión futura)

- Facturación electrónica DIAN
- Aplicación móvil nativa
- Integración con pasarelas de pago electrónico
- Modo offline
