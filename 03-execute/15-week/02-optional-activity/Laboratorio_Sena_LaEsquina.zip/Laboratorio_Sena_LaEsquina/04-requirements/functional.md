# Functional Requirements

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Catálogo de requisitos funcionales

| ID | Nombre | Descripción | Fuente | Prioridad | Fase |
|---|---|---|---|---|---|
| RF-01 | Registro de ventas | Registrar cada venta con fecha, hora, productos, cantidades y total calculado automáticamente. El inventario se descuenta al confirmar. | Entrevista / Observación | Alta | 1 |
| RF-02 | Control de inventario | Gestionar el catálogo de productos con nombre, categoría, precio y cantidad disponible actualizada en tiempo real. | Entrevista / Encuesta / Obs. | Alta | 1 |
| RF-03 | Alertas de stock mínimo | Emitir alerta visual cuando la cantidad de un producto llegue al stock mínimo configurado por el administrador. | Observación directa | Alta | 1 |
| RF-04 | Cuentas por cobrar | Registrar fiados con nombre del cliente, productos, monto, fecha y estado (pendiente / pagado). Historial por cliente. | Entrevista / Rev. documental | Alta | 1 |
| RF-05 | Inicio de sesión seguro | Requerir usuario y contraseña para acceder al sistema. Cierre de sesión automático por inactividad mayor a 30 minutos. | Entrevista | Alta | 1 |
| RF-06 | Gestión de usuarios | Crear, editar y desactivar usuarios con roles diferenciados: administrador y cajero, con permisos distintos. | Entrevista | Alta | 1 |
| RF-07 | Cálculo automático de cambio | Al registrar una venta, el sistema calcula automáticamente el cambio a devolver al cliente según el monto recibido. | Observación directa | Alta | 1 |
| RF-08 | Gestión de pedidos | Crear pedidos a proveedores con proveedor, productos, cantidades, fecha y estado (pendiente / recibido / cancelado). | Entrevista / Encuesta | Media | 2 |
| RF-09 | Reportes de ventas | Generar reportes de ventas por día, semana y mes. Mostrar totales, productos más vendidos y comparativos de períodos. | Entrevista | Media | 2 |
| RF-10 | Actualización de precios | Permitir consultar y modificar el precio de venta de cualquier producto desde una pantalla sencilla con historial de cambios. | Encuesta / Observación | Media | 2 |
| RF-11 | Historial de movimientos | Registrar automáticamente cada operación realizada con usuario, fecha, hora y tipo de movimiento. | Observación directa | Baja | 3 |
