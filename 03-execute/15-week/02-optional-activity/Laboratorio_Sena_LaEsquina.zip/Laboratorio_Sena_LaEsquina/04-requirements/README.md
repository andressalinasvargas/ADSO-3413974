# Requisitos

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

Catálogo completo de requisitos funcionales, no funcionales y casos de uso.

## Archivos

- functional.md — RF-01 a RF-11 con prioridad y fase
- non-functional.md — RNF-01 a RNF-03 y restricciones de negocio
- user-stories.md — CU-01, CU-02 y CU-03 con flujos y excepciones
- traceability-matrix.md — Trazabilidad y matriz de priorización
