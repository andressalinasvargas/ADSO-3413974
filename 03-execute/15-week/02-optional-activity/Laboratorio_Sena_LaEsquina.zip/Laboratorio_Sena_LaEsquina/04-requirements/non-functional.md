# Non-Functional Requirements

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Requisitos no funcionales

| ID | Nombre | Descripción | Fuente | Prioridad | Fase |
|---|---|---|---|---|---|
| RNF-01 | Usabilidad | Interfaz intuitiva sin tecnicismos, con iconos claros y botones grandes. Un usuario sin experiencia técnica debe poder usarla sin capacitación mayor a 2 horas. | Entrevista / Observación | Alta | 1 |
| RNF-02 | Compatibilidad web | Funcionar correctamente en Chrome, Firefox y Edge en sus versiones actuales, sin instalar software adicional. | Entrevista | Alta | 1 |
| RNF-03 | Rendimiento | El tiempo de carga de cualquier pantalla no debe superar los 3 segundos en condiciones normales de red. | Encuesta | Media | 2 |

## Requisitos de negocio

| ID | Descripción | Impacto |
|---|---|---|
| RN-01 | El sistema NO generará facturas electrónicas DIAN en esta versión. | Alcance definido; puede implementarse en versiones futuras. |
| RN-02 | El sistema requiere conexión a internet para funcionar. No se contempla modo offline. | Restricción técnica; el negocio ya cuenta con internet. |
