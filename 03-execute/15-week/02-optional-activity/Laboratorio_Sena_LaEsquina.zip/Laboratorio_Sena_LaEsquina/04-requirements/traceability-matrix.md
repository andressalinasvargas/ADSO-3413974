# Traceability Matrix

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Matriz de trazabilidad — Requisitos vs Casos de uso

| Requisito | CU-01 Registrar venta | CU-02 Gestionar inventario | CU-03 Registrar fiado |
|---|:---:|:---:|:---:|
| RF-01 Registro de ventas | ✓ | | |
| RF-02 Control de inventario | ✓ | ✓ | ✓ |
| RF-03 Alertas de stock mínimo | ✓ | ✓ | |
| RF-04 Cuentas por cobrar | | | ✓ |
| RF-05 Inicio de sesión seguro | ✓ | | ✓ |
| RF-06 Gestión de usuarios | | ✓ | ✓ |
| RF-07 Cálculo automático de cambio | ✓ | | |
| RF-10 Actualización de precios | | ✓ | |

## Matriz de priorización — Importancia vs Urgencia

| ID | Requisito | Importancia (1-5) | Urgencia (1-5) | Prioridad (I×U) | Fase |
|---|---|:---:|:---:|:---:|---|
| RF-01 | Registro de ventas | 5 | 5 | **25** | Fase 1 |
| RF-02 | Control de inventario | 5 | 5 | **25** | Fase 1 |
| RNF-01 | Usabilidad | 5 | 5 | **25** | Transversal |
| RF-03 | Alertas de stock | 5 | 4 | **20** | Fase 1 |
| RF-04 | Cuentas por cobrar | 4 | 5 | **20** | Fase 1 |
| RF-05 | Inicio de sesión | 5 | 4 | **20** | Fase 1 |
| RF-06 | Gestión de usuarios | 5 | 4 | **20** | Fase 1 |
| RF-07 | Cálculo de cambio | 5 | 4 | **20** | Fase 1 |
| RF-08 | Gestión de pedidos | 4 | 4 | **16** | Fase 2 |
| RNF-02 | Compatibilidad web | 4 | 4 | **16** | Fase 2 |
| RF-09 | Reportes de ventas | 4 | 3 | **12** | Fase 2 |
| RF-10 | Actualización precios | 3 | 4 | **12** | Fase 2 |
| RF-11 | Historial movimientos | 3 | 3 | **9** | Fase 3 |
| RNF-03 | Rendimiento | 3 | 3 | **9** | Fase 3 |
