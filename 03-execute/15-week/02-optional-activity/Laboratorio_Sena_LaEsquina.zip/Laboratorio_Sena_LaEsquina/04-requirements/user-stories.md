# User Stories

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## CU-01 — Registrar una venta

| Campo | Descripción |
|---|---|
| **ID** | CU-01 |
| **Actor principal** | Cajero (Marta Ríos o empleado de turno) |
| **Actores secundarios** | Sistema de inventario (actualización automática) |
| **Precondiciones** | El cajero ha iniciado sesión. El módulo de ventas está activo. Los productos a vender existen en el catálogo con stock mayor a cero. |
| **Flujo normal** | 1. El cajero selecciona "Nueva venta". 2. Busca cada producto por nombre o código. 3. Ingresa la cantidad; el sistema muestra el subtotal y actualiza el total en tiempo real. 4. El cajero ingresa el monto recibido; el sistema calcula el cambio automáticamente. 5. El cajero presiona "Confirmar venta". 6. El inventario se descuenta automáticamente. |
| **Excepción E1** | Si un producto no tiene stock suficiente, el sistema muestra advertencia en rojo y no permite ingresar una cantidad mayor a la disponible. |
| **Excepción E2** | Si el cajero cierra sesión antes de confirmar, la venta no se guarda. Al reingresar, la pantalla aparece en blanco. |
| **Excepción E3** | Si la conexión a internet se interrumpe al confirmar, el sistema muestra un mensaje de error y pide intentarlo de nuevo. |
| **Postcondición** | La venta queda registrada con todos sus datos. El inventario queda actualizado. La información está disponible para reportes. |
| **Requisitos asociados** | RF-01, RF-02, RF-03, RF-07, RF-05 |

---

## CU-02 — Gestionar inventario de productos

| Campo | Descripción |
|---|---|
| **ID** | CU-02 |
| **Actor principal** | Administrador (don Carlos Ríos) |
| **Precondiciones** | El administrador ha iniciado sesión. Tiene información actualizada de los productos a registrar o modificar. |
| **Flujo normal** | 1. El administrador accede al módulo de inventario. 2. Selecciona "Agregar producto" o busca uno existente para editarlo. 3. Ingresa o actualiza: nombre, categoría, precio de venta, precio de compra, cantidad disponible y stock mínimo. 4. Presiona "Guardar". El producto queda disponible en el catálogo de ventas. |
| **Excepción E1** | Si un campo obligatorio está vacío (nombre, precio o cantidad), el sistema resalta el campo en rojo y no permite guardar. |
| **Excepción E2** | Si el nombre del producto ya existe, el sistema alerta sobre el posible duplicado y pregunta si desea actualizar el existente o crear uno nuevo. |
| **Postcondición** | El catálogo de inventario queda actualizado. Si la cantidad es menor al stock mínimo, se genera alerta de inmediato. |
| **Requisitos asociados** | RF-02, RF-03, RF-06, RF-10 |

---

## CU-03 — Registrar fiado a un cliente

| Campo | Descripción |
|---|---|
| **ID** | CU-03 |
| **Actor principal** | Administrador (don Carlos) o Cajero (Marta Ríos) |
| **Actores secundarios** | Módulo de cuentas por cobrar |
| **Precondiciones** | El usuario ha iniciado sesión. El cliente no ha superado el límite de crédito configurado. |
| **Flujo normal** | 1. El usuario accede al módulo de cuentas por cobrar. 2. Busca el cliente; si no existe, selecciona "Nuevo cliente" e ingresa nombre y teléfono. 3. Selecciona los productos del fiado y las cantidades. El sistema calcula el total automáticamente. 4. Presiona "Registrar fiado". El sistema guarda con fecha automática y estado "Pendiente". 5. El inventario descuenta los productos fiados. |
| **Excepción E1** | Si el cliente supera el límite de crédito, el sistema muestra alerta y no permite continuar sin autorización del administrador. |
| **Excepción E2** | Si un producto no tiene stock, el sistema avisa y no lo incluye en el fiado. |
| **Excepción E3** | Si se intenta crear un cliente con nombre ya existente, el sistema sugiere el cliente existente para evitar duplicados. |
| **Postcondición** | El fiado queda registrado. La deuda activa del cliente se actualiza. El inventario queda descontado. |
| **Requisitos asociados** | RF-04, RF-02, RF-06, RF-05 |
