# Technical Backlog

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Tareas técnicas pendientes

Estas tareas no son funcionalidades visibles para el usuario, pero son necesarias para que el sistema funcione bien.

| ID | Tarea | Por qué es necesaria | Fase |
|---|---|---|---|
| TT-01 | Crear la estructura de la base de datos con todas las tablas definidas en `06-data/data-dictionary.md`. | Sin esto no hay donde guardar la información. | 1 |
| TT-02 | Implementar el sistema de autenticación (inicio de sesión y roles). | Todos los módulos dependen de saber quién está usando el sistema. | 1 |
| TT-03 | Implementar el descuento automático de inventario al confirmar una venta. | Es una regla de negocio crítica: la venta y el inventario deben estar siempre sincronizados. | 1 |
| TT-04 | Implementar el sistema de alertas de stock mínimo. | Evita que don Carlos quede sin productos sin darse cuenta. | 1 |
| TT-05 | Cifrar las contraseñas de los usuarios antes de guardarlas. | Nunca se guardan contraseñas en texto plano. | 1 |
| TT-06 | Implementar el cierre de sesión automático por inactividad (30 min). | Requisito de seguridad RF-05. | 1 |
| TT-07 | Registrar toda operación con usuario, fecha y hora (log de actividad). | Necesario para trazabilidad y RF-11. | 2 |
| TT-08 | Implementar el módulo de reportes con filtros por período. | Permite a don Carlos ver las ventas por día, semana y mes. | 2 |
| TT-09 | Verificar compatibilidad en Chrome, Firefox y Edge. | RNF-02 exige que funcione en los tres navegadores. | 2 |
| TT-10 | Medir y optimizar tiempos de carga de cada pantalla. | RNF-03 exige menos de 3 segundos. | 3 |
