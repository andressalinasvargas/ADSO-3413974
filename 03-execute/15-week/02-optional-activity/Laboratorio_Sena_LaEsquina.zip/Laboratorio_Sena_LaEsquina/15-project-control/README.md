# Control del Proyecto

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

Control del proyecto: tareas técnicas pendientes, riesgos, dependencias y preguntas abiertas.

## Archivos

- technical-backlog.md — 10 tareas técnicas pendientes con fase asignada
- risks.md — 6 riesgos identificados con plan de mitigación
- dependencies.md — Dependencias externas e internas del sistema
- open-questions.md — Preguntas abiertas pendientes de respuesta
