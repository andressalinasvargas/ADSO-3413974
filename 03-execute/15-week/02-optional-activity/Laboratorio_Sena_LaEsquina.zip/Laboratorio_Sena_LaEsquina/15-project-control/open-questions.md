# Preguntas abiertas

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Flujo de resolución

1. Registrar la pregunta con estado `ABIERTA`.
2. Asignar un responsable y fecha límite.
3. Resolver y cambiar el estado a `RESUELTA`.
4. Si genera una decisión importante, documentarla en `05-architecture/decisions/`.

## Preguntas abiertas

| # | Pregunta | Área | Responsable | Fecha límite | Estado |
|---|---|---|---|---|---|
| 1 | ¿En qué servidor se va a alojar el sistema para producción? | Arquitectura / Devops | Por definir | Por definir | ABIERTA |
| 2 | ¿Cuántos productos tiene actualmente el supermercado en su catálogo? | Datos | Don Carlos Ríos | Antes de la carga inicial | ABIERTA |
| 3 | ¿Qué límite de crédito (deuda máxima) aplica don Carlos a los clientes con fiado? | Negocio | Don Carlos Ríos | Por definir | ABIERTA |
| 4 | ¿Qué navegador usa actualmente el computador del negocio? | Compatibilidad | Equipo | Por definir | ABIERTA |

## Resueltas

| # | Pregunta | Resolución |
|---|---|---|
| — | — | — |
