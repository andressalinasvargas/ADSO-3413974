# Dependencies

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Dependencias del proyecto

| Dependencia | Tipo | Por qué importa |
|---|---|---|
| Conexión a internet estable en el negocio | Externa | El sistema no funciona sin internet (RN-02). |
| Disponibilidad de don Carlos para la carga inicial de productos | Externa | Sin el catálogo de productos, el sistema no se puede usar. |
| Listado actualizado de clientes con fiado activo | Externa | Se necesita para migrar los 9 fiados activos identificados en la revisión documental. |
| Computador con navegador actualizado en el negocio | Externa | El sistema se usa desde el navegador (RNF-02). |
| Aprobación de don Carlos al diseño de la interfaz | Interna | Según RNF-01, si la interfaz no le parece simple, no la va a usar. |

## Dependencias entre módulos del sistema

| Módulo | Depende de |
|---|---|
| Ventas | Inventario (necesita los productos cargados para poder vender). |
| Fiados | Inventario (descuenta productos) y el módulo de Clientes. |
| Alertas de stock | Inventario (se activan cuando la cantidad baja del mínimo). |
| Reportes | Ventas (necesita historial de transacciones). |
| Todos los módulos | Seguridad (autenticación y roles deben estar listos primero). |
