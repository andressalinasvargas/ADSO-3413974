# Risks

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Riesgos identificados

| ID | Riesgo | Probabilidad | Impacto | Cómo reducirlo |
|---|---|---|---|---|
| R-01 | Don Carlos no adopta el sistema y sigue usando el cuaderno. | Alta | Alto | Diseño muy simple (RNF-01). Período de uso paralelo durante la primera semana. Capacitación de máximo 2 horas. |
| R-02 | El negocio no tiene internet estable y el sistema no carga. | Media | Alto | Verificar la conexión antes de la puesta en marcha. Recomendar un plan de internet más estable si es necesario. |
| R-03 | Los productos se ingresan mal en la carga inicial (errores de precio o cantidad). | Alta | Medio | Hacer la carga inicial con don Carlos presente para verificar cada dato. Usar la lista física de productos como referencia. |
| R-04 | Marta olvida la contraseña y no puede usar el sistema. | Media | Medio | El administrador (don Carlos) puede restablecer contraseñas. Procedimiento documentado en el manual de administrador. |
| R-05 | Se registran ventas duplicadas por error del cajero. | Baja | Medio | El historial de ventas muestra todas las transacciones con fecha y hora exacta para identificar duplicados. |
| R-06 | El equipo de desarrollo no termina a tiempo la Fase 1. | Media | Alto | Priorizar los 7 requisitos de Fase 1 y no empezar la Fase 2 hasta que estén completos y probados. |
