# Dominio

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

Mapa de dominio, entidades, reglas de negocio y eventos del sistema.

## Archivos

- domain-map.md — Mapa de actores y relaciones del negocio
- entities-and-rules.md — Entidades del sistema y reglas de negocio
- domain-events.md — Eventos que puede disparar el sistema
