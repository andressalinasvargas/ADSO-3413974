# Domain Events

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Eventos del dominio

| Evento | Lo dispara | Consecuencia |
|---|---|---|
| VentaConfirmada | Cajero o administrador al confirmar una venta | El inventario se descuenta; la venta queda en el historial. |
| StockMínimoAlcanzado | Sistema al actualizar el inventario | Se muestra una alerta visual en pantalla. |
| FiadoRegistrado | Cajero o administrador al registrar un fiado | El inventario se descuenta; la deuda activa del cliente aumenta. |
| FiadoPagado | Administrador al marcar un fiado como pagado | El estado del fiado cambia a "pagado"; la deuda del cliente disminuye. |
| ProductoAgregado | Administrador al agregar un producto nuevo | El producto queda disponible en el catálogo de ventas. |
| PrecioActualizado | Administrador al modificar el precio de un producto | El nuevo precio aplica a todas las ventas siguientes. |
| PedidoCreado | Administrador al registrar un pedido | El pedido queda en estado "pendiente". |
| PedidoRecibido | Administrador al marcar un pedido como recibido | El stock de los productos pedidos se actualiza. |
| UsuarioInició | Usuario al iniciar sesión con credenciales correctas | Se activa la sesión con los permisos del rol correspondiente. |
| SesiónCerrada | Sistema tras 30 minutos de inactividad, o usuario manualmente | La sesión se termina y se requiere nuevo inicio de sesión. |
