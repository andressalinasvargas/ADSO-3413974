# Entities and Business Rules

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Entidades principales

### Producto
- nombre, categoría, precio de venta, precio de compra, cantidad disponible, stock mínimo de alerta.
- Un producto no puede tener cantidad negativa.
- Si la cantidad llega al stock mínimo, se genera una alerta automática.

### Venta
- fecha, hora, lista de productos (cantidad y precio), total calculado automáticamente, monto recibido, cambio devuelto, usuario que registró.
- Al confirmar una venta, el inventario se descuenta automáticamente.
- No se puede confirmar una venta si un producto no tiene stock suficiente.

### Cliente
- nombre, teléfono, total de deuda activa.
- Un cliente puede tener varios fiados abiertos al mismo tiempo.

### Cuenta por cobrar (Fiado)
- cliente, lista de productos fiados, monto total, fecha, estado (pendiente / pagado), usuario que registró.
- El inventario se descuenta al registrar el fiado.
- No se puede agregar un producto al fiado si no hay stock disponible.

### Pedido a proveedor
- proveedor, lista de productos pedidos, cantidades, fecha, estado (pendiente / recibido / cancelado).

### Usuario
- nombre, rol (administrador / cajero), contraseña.
- El administrador tiene acceso completo.
- El cajero puede registrar ventas, consultar inventario y registrar fiados. No puede modificar precios ni eliminar registros.

## Reglas de negocio

| ID | Regla |
|---|---|
| RN-01 | El sistema NO genera facturas electrónicas DIAN en esta versión. |
| RN-02 | El sistema requiere conexión a internet. No hay modo offline. |
| RN-03 | La sesión se cierra automáticamente tras 30 minutos de inactividad. |
| RN-04 | El cajero no puede modificar precios ni eliminar registros. |
| RN-05 | Toda operación queda registrada con usuario, fecha y hora. |
