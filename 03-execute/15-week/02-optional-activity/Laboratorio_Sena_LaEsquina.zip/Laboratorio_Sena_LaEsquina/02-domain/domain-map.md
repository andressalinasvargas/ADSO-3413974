# Domain Map

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Descripción del dominio

El dominio es la gestión operativa de un supermercado de barrio. Comprende cuatro áreas principales que interactúan entre sí:

1. **Ventas** — registro de cada transacción con el cliente.
2. **Inventario** — control de productos, existencias y precios.
3. **Cuentas por cobrar** — seguimiento de clientes con fiado activo.
4. **Pedidos a proveedores** — gestión de reposición de productos.

## Mapa de dominios y relaciones

```
[Cliente] ──compra──► [Venta] ──descuenta──► [Inventario]
                                                    │
[Cliente] ──fía───► [Cuenta por cobrar]            │
                                                    │
[Proveedor] ──surte──► [Pedido] ──repone──────────►┘
```

## Actores del dominio

| Actor | Tipo | Descripción |
|---|---|---|
| Don Carlos Ríos | Persona | Propietario y administrador. Gestiona todo el negocio. |
| Marta Ríos | Persona | Esposa y cajera. Registra ventas y fiados. |
| Empleado ocasional | Persona | Apoya en caja en días de alto movimiento. |
| Cliente frecuente | Persona | Compra regularmente; puede tener fiado activo. |
| Proveedor | Organización | Surte de productos al supermercado. |
| Sistema | Automático | Actualiza inventario, genera alertas y registra historial. |
