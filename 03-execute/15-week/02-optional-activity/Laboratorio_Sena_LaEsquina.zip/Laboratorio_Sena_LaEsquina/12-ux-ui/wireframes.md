# Wireframes

> Estado: 🟡 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Pantalla 1 — Inicio de sesión

```
┌─────────────────────────────────┐
│                                 │
│    Sistema La Esquina           │
│                                 │
│    Usuario: [____________]      │
│    Contraseña: [____________]   │
│                                 │
│         [ Ingresar ]            │
│                                 │
└─────────────────────────────────┘
```

## Pantalla 2 — Menú principal

```
┌─────────────────────────────────┐
│  La Esquina          [Salir]    │
├─────────────────────────────────┤
│                                 │
│  [ Ventas ]    [ Inventario ]   │
│                                 │
│  [ Fiados ]    [ Pedidos ]      │
│                                 │
│  [ Reportes ]  [ Usuarios* ]    │
│                                 │
└─────────────────────────────────┘
* Solo si el usuario es administrador
```

## Pantalla 3 — Nueva venta

```
┌─────────────────────────────────┐
│  Nueva venta            [Atrás] │
├─────────────────────────────────┤
│  Buscar producto: [__________]  │
│                                 │
│  Producto        Cant.  Precio  │
│  ─────────────────────────────  │
│  Arroz 500g       2    $2.800   │
│  Aceite 500ml     1    $8.500   │
│                                 │
│  Total:              $14.100    │
│  Recibido: [___________]        │
│  Cambio:              $5.900    │
│                                 │
│          [ CONFIRMAR VENTA ]    │
└─────────────────────────────────┘
```
