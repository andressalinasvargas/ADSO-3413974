# Design System

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Principio de diseño

La interfaz debe ser tan simple que don Carlos, quien dice no ser bueno con los computadores, pueda usarla sin más de 2 horas de capacitación (RNF-01). Esto define todas las decisiones de diseño.

## Colores

| Uso | Color | Por qué |
|---|---|---|
| Fondo principal | Blanco | Limpio y sin distracción. |
| Texto principal | Negro / gris oscuro | Máxima legibilidad. |
| Botón principal (confirmar, guardar) | Verde | Indica acción positiva. |
| Alerta / error | Rojo | Llama la atención inmediatamente. |
| Alerta de stock mínimo | Naranja | Advertencia sin ser error crítico. |

## Tipografía

- Fuente sin serifas (ej: Roboto, Arial) para facilitar la lectura en pantalla.
- Tamaño mínimo de texto: 16px para el contenido, 14px para etiquetas secundarias.
- Los botones principales tienen texto grande y legible.

## Componentes clave

- **Botones grandes:** los botones de acción principal (Confirmar venta, Guardar, Registrar fiado) deben ser grandes y fáciles de presionar.
- **Mensajes de error claros:** cuando algo falla, el mensaje explica qué pasó en palabras simples, no códigos técnicos. Ejemplo: "No hay suficiente azúcar en el inventario", no "Error 422".
- **Campos resaltados:** cuando falta llenar un campo obligatorio, se resalta en rojo con un mensaje corto.
- **Alertas de stock:** aparecen como un aviso visible pero sin interrumpir el flujo de trabajo.
