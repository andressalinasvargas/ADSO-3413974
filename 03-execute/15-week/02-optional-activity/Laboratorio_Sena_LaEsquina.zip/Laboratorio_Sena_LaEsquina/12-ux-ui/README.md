# UX-UI

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

Sistema de diseño, mapa de navegación y wireframes de las pantallas principales.

## Archivos

- design-system.md — Colores, tipografía y componentes de la interfaz
- navigation-map.md — Estructura de pantallas por módulo
- wireframes.md — Bocetos de pantallas principales
