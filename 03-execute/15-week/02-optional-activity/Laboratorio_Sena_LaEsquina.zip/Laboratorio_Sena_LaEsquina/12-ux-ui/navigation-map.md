# Navigation Map

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Mapa de navegación del sistema

```
[Inicio de sesión]
        │
        ▼
[Menú principal]
   │    │    │    │    │    │
   ▼    ▼    ▼    ▼    ▼    ▼
[Ventas] [Inventario] [Fiados] [Pedidos] [Reportes] [Usuarios*]

* Solo visible para el administrador
```

## Pantallas por módulo

### Ventas
- Nueva venta (buscar producto → agregar → confirmar → ver cambio)
- Historial de ventas (lista por fecha)

### Inventario
- Lista de productos (con buscador)
- Agregar / editar producto
- Panel de alertas de stock mínimo

### Cuentas por cobrar (Fiados)
- Lista de clientes con fiado activo
- Detalle de fiados por cliente
- Registrar nuevo fiado
- Marcar fiado como pagado

### Pedidos
- Lista de pedidos (con estado)
- Crear pedido
- Actualizar estado del pedido

### Reportes
- Reporte de ventas por día / semana / mes
- Productos más vendidos

### Usuarios *(solo administrador)*
- Lista de usuarios
- Crear / editar usuario
- Desactivar usuario
