# CI/CD

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Flujo de integración y despliegue

```
[Rama de trabajo]
      │
      │  Pull Request
      ▼
   [dev]  ← revisión del equipo
      │
      │  Pull Request aprobado
      ▼
    [qa]  ← pruebas de calidad
      │
      │  Todo correcto
      ▼
  [main]  ← versión publicada en producción
```

## Verificaciones antes de aceptar un Pull Request

- El documento cumple la estructura definida en `00-governance/documentation-rules.md`.
- El estado del documento está actualizado (🔴 / 🟡 / 🟢).
- El autor y fecha están registrados en el encabezado.
- Al menos un integrante del equipo revisó y aprobó los cambios.
