# Local Setup

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Requisitos para desarrollar

- Computador con conexión a internet.
- Git instalado.
- Un editor de código (se recomienda VS Code).
- Navegador web actualizado para probar.

## Pasos para empezar

1. Clonar el repositorio:
   ```
   git clone https://github.com/JohanAceroSalazar/Laboratorio_Sena.git
   ```
2. Entrar a la carpeta del proyecto:
   ```
   cd Laboratorio_Sena
   ```
3. Crear una rama de trabajo a partir de `dev`:
   ```
   git checkout dev
   git checkout -b feat/doc-mi-seccion
   ```
4. Editar los archivos `.md` correspondientes.
5. Guardar los cambios y subirlos:
   ```
   git add .
   git commit -m "docs(seccion): descripcion del cambio"
   git push origin feat/doc-mi-seccion
   ```
6. Abrir un Pull Request hacia `dev` en GitHub.
