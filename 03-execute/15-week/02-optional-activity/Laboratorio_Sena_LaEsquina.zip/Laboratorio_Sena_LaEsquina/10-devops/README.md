# DevOps

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

Configuración del entorno local, flujo de publicación y definición de entornos.

## Archivos

- local-setup.md — Pasos para empezar a trabajar en el proyecto
- environments.md — Entornos: desarrollo, QA y producción
- ci-cd.md — Flujo de integración y despliegue continuo
