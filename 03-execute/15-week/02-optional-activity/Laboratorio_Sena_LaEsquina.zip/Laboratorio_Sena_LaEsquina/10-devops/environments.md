# Environments

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Entornos del proyecto

| Entorno | Rama | Para qué se usa |
|---|---|---|
| Desarrollo (local) | `feat/*` o `fix/*` | Cada integrante trabaja aquí en su computador. |
| Integración (dev) | `dev` | Se juntan los cambios de todos y se verifica que funcionen juntos. |
| Pruebas (QA) | `qa` | Se valida que todo esté correcto antes de publicar. |
| Producción | `main` | El entorno real donde trabaja don Carlos y Marta. |

## Reglas de los entornos

- Nadie trabaja directamente sobre `main`, `dev` ni `qa`.
- Todo cambio entra por Pull Request.
- Un cambio solo pasa a `main` después de pasar por `dev` y `qa`.
