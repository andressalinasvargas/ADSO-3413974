# Microservicios

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

No aplica en v1.0. El sistema es monolítico. Esta sección se mantiene como parte de la estructura estándar del repositorio.

## Archivos

- communication-patterns.md — Explicación de la arquitectura monolítica y comunicación interna entre módulos
