# Patrones de comunicación

> Estado: 🟢 | Última actualización: 2026-04-11
> Autor: Equipo Ficha 3413974

## Nota importante

El sistema del Supermercado La Esquina en su versión 1.0 es una **aplicación web monolítica**, no una arquitectura de microservicios. Esta sección se incluye como parte de la estructura estándar del repositorio, pero no aplica en esta versión.

## ¿Por qué no se usan microservicios?

| Razón | Explicación |
|---|---|
| Tamaño del negocio | El supermercado tiene 2-3 usuarios simultáneos como máximo. Una arquitectura distribuida es innecesaria. |
| Complejidad del equipo | Microservicios requieren más infraestructura y conocimiento técnico que el volumen del negocio justifica. |
| Velocidad de desarrollo | Un monolito bien estructurado permite entregar la Fase 1 más rápido. |

## Comunicación interna (dentro del monolito)

Los módulos del sistema se comunican directamente a través de llamadas internas:

- Ventas → llama al módulo de Inventario para descontar stock.
- Fiados → llama al módulo de Inventario para descontar stock y al de Clientes para actualizar deuda.
- Inventario → dispara alertas de stock mínimo automáticamente.

## Posible evolución futura

Si el negocio crece y necesita más capacidad, los módulos actuales están diseñados de forma independiente y podrían separarse en servicios distintos en una versión futura.
