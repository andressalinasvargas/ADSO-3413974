<?php
// =============================================================
// qr.php — Genera imagen QR para el token del checkpoint
// =============================================================
require 'conexion.php';

$token = $_GET['token'] ?? '';
if (!preg_match('/^[a-f0-9]{32}$/', $token)) { http_response_code(400); exit; }

$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
     . '://' . $_SERVER['HTTP_HOST']
     . dirname($_SERVER['PHP_SELF']) . '/registro_qr.php?token=' . urlencode($token);

$qr_url = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&ecc=M&data='
         . urlencode($url);

$img = @file_get_contents($qr_url);

if ($img === false) {
    header('Content-Type: image/svg+xml');
    echo '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200">
        <rect width="200" height="200" fill="#eee"/>
        <text x="100" y="100" dominant-baseline="middle" text-anchor="middle"
              font-family="Arial" font-size="13" fill="#666">QR sin internet</text>
    </svg>';
    exit;
}

header('Content-Type: image/png');
header('Cache-Control: no-store');
echo $img;
