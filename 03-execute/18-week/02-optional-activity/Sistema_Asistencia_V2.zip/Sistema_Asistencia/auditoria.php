<?php
// =============================================================
// auditoria.php — Log de modificaciones e intentos fallidos
// =============================================================
require 'conexion.php';
require 'funciones.php';

$idFicha = (int)($_GET['ficha'] ?? 0);
if ($idFicha <= 0) { header('Location: index.php'); exit; }

$s = mysqli_prepare($conexion, "SELECT * FROM ficha WHERE id = ? LIMIT 1");
mysqli_stmt_bind_param($s, 'i', $idFicha);
mysqli_stmt_execute($s);
$ficha = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
mysqli_stmt_close($s);
if (!$ficha) { header('Location: index.php'); exit; }

$fecha_filtro = isset($_GET['fecha']) && $_GET['fecha'] !== ''
    ? $_GET['fecha']
    : date('Y-m-d');

// Modificaciones del día para esta ficha
$sql_mod = "
    SELECT
        am.fecha_hora,
        ap.tipo_doc, ap.documento, ap.nombre,
        cp.tipo  AS checkpoint,
        am.estado_anterior,
        am.estado_nuevo
    FROM auditoria_modificacion am
    JOIN asistencia  a  ON am.idAsistencia = a.id
    JOIN aprendiz    ap ON a.idAprendiz    = ap.id
    JOIN checkpoint  cp ON a.idCheckpoint  = cp.id
    WHERE cp.idFicha = ? AND DATE(am.fecha_hora) = ?
    ORDER BY am.fecha_hora DESC
";
$s = mysqli_prepare($conexion, $sql_mod);
mysqli_stmt_bind_param($s, 'is', $idFicha, $fecha_filtro);
mysqli_stmt_execute($s);
$modificaciones = mysqli_fetch_all(mysqli_stmt_get_result($s), MYSQLI_ASSOC);
mysqli_stmt_close($s);

// Intentos fallidos del día para esta ficha
$sql_int = "
    SELECT
        if2.fecha_hora,
        if2.documento,
        if2.tipo_error,
        if2.ip,
        cp.tipo AS checkpoint
    FROM intento_fallido if2
    JOIN checkpoint cp ON if2.idCheckpoint = cp.id
    WHERE cp.idFicha = ? AND DATE(if2.fecha_hora) = ?
    ORDER BY if2.fecha_hora DESC
";
$s = mysqli_prepare($conexion, $sql_int);
mysqli_stmt_bind_param($s, 'is', $idFicha, $fecha_filtro);
mysqli_stmt_execute($s);
$intentos = mysqli_fetch_all(mysqli_stmt_get_result($s), MYSQLI_ASSOC);
mysqli_stmt_close($s);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auditoría — Ficha <?php echo htmlspecialchars($ficha['numero']); ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Sistema de Asistencia — SENA</h1>
    <p>Auditoría — Ficha <?php echo htmlspecialchars($ficha['numero']); ?></p>
</header>

<main>
    <h2>Auditoría del sistema</h2>

    <div class="info-box">
        <p><strong>Ficha:</strong> <?php echo htmlspecialchars($ficha['numero']); ?></p>
        <p><strong>Programa:</strong> <?php echo htmlspecialchars($ficha['programa']); ?></p>
    </div>

    <!-- Filtro por fecha -->
    <form method="GET" action="auditoria.php" class="form-busqueda">
        <input type="hidden" name="ficha" value="<?php echo $idFicha; ?>">
        <label for="fecha">Fecha:</label>
        <input type="date" id="fecha" name="fecha"
               value="<?php echo htmlspecialchars($fecha_filtro); ?>">
        <button type="submit" class="btn">Buscar</button>
    </form>

    <p style="font-size:13px;color:#666;margin-bottom:20px;">
        Mostrando registros del
        <strong><?php echo date('d/m/Y', strtotime($fecha_filtro)); ?></strong>
    </p>

    <!-- ===== MODIFICACIONES ===== -->
    <h3>
        Modificaciones de estado
        <span style="font-weight:normal;font-size:13px;color:#666;">
            (<?php echo count($modificaciones); ?>)
        </span>
    </h3>

    <?php if (empty($modificaciones)): ?>
    <div class="alerta alerta-info" style="margin-bottom:24px;">
        No hubo modificaciones el <?php echo date('d/m/Y', strtotime($fecha_filtro)); ?>.
    </div>
    <?php else: ?>
    <table class="table-dark">
        <thead>
            <tr>
                <th>Fecha y hora</th>
                <th>Tipo doc</th>
                <th>Documento</th>
                <th>Nombre</th>
                <th>Jornada</th>
                <th>Antes</th>
                <th>Después</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($modificaciones as $m): ?>
        <tr>
            <td><?php echo date('d/m/Y H:i:s', strtotime($m['fecha_hora'])); ?></td>
            <td><?php echo labelTipoDoc($m['tipo_doc']); ?></td>
            <td><?php echo htmlspecialchars($m['documento']); ?></td>
            <td><?php echo htmlspecialchars($m['nombre']); ?></td>
            <td><?php echo labelCheckpoint($m['checkpoint']); ?></td>
            <td class="<?php echo match($m['estado_anterior']) {
                'Asistio' => 'est-asistio',
                'Tarde'   => 'est-tarde',
                'Ausente' => 'est-ausente',
                default   => ''
            }; ?>">
                <?php echo labelEstado($m['estado_anterior']); ?>
            </td>
            <td class="<?php echo match($m['estado_nuevo']) {
                'Asistio' => 'est-asistio',
                'Tarde'   => 'est-tarde',
                'Ausente' => 'est-ausente',
                default   => ''
            }; ?>">
                <?php echo labelEstado($m['estado_nuevo']); ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>

    <!-- ===== INTENTOS FALLIDOS ===== -->
    <h3 style="margin-top:28px;">
        Intentos fallidos de registro QR
        <span style="font-weight:normal;font-size:13px;color:#666;">
            (<?php echo count($intentos); ?>)
        </span>
    </h3>

    <?php if (empty($intentos)): ?>
    <div class="alerta alerta-info">
        No hubo intentos fallidos el <?php echo date('d/m/Y', strtotime($fecha_filtro)); ?>.
    </div>
    <?php else: ?>
    <table class="table-dark">
        <thead>
            <tr>
                <th>Fecha y hora</th>
                <th>Documento ingresado</th>
                <th>Error</th>
                <th>IP</th>
                <th>Jornada</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $labels_error = [
            'codigo_invalido' => 'Código incorrecto o expirado',
            'ya_registrado'   => 'Ya tenía registro',
            'documento_invalido' => 'Documento no registrado',
        ];
        foreach ($intentos as $it):
            $err = $labels_error[$it['tipo_error']] ?? $it['tipo_error'];
        ?>
        <tr>
            <td><?php echo date('d/m/Y H:i:s', strtotime($it['fecha_hora'])); ?></td>
            <td><?php echo htmlspecialchars($it['documento'] ?? '—'); ?></td>
            <td class="est-ausente"><?php echo htmlspecialchars($err); ?></td>
            <td><?php echo htmlspecialchars($it['ip'] ?? '—'); ?></td>
            <td><?php echo labelCheckpoint($it['checkpoint']); ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>

    <div style="margin-top:24px;">
        <a href="panel_ficha.php?id=<?php echo $idFicha; ?>"
           class="btn btn-secondary">← Volver al panel</a>
    </div>
</main>

<footer>Sistema de Asistencia &mdash; SENA</footer>
</body>
</html>
