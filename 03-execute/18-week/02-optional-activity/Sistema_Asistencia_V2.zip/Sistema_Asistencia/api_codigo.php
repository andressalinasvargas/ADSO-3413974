<?php
// =============================================================
// api_codigo.php — Núcleo del registro QR
//
// Paso 'inicial':
//   1. Valida token + código de verificación
//   2. Crea sesion_qr temporal
//   3a. Si aprendiz existe → registra asistencia → redirige a ok
//   3b. Si no existe → redirige a paso 2 (pedir datos)
//
// Paso 'registro':
//   4. Valida sesion_qr
//   5. Crea aprendiz
//   6. Registra asistencia → redirige a ok
// =============================================================
require 'conexion.php';
require 'funciones.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }

$token        = $_POST['token']        ?? '';
$paso         = $_POST['paso']         ?? 'inicial';
$ip           = obtenerIP();

// ============================================================
// PASO INICIAL: validar código
// ============================================================
if ($paso === 'inicial') {
    $documento = trim($_POST['documento'] ?? '');
    $codigo    = strtoupper(trim($_POST['codigo'] ?? ''));

    // 1. Validar token
    if (!preg_match('/^[a-f0-9]{32}$/', $token)) {
        header('Location: index.php'); exit;
    }

    $s = mysqli_prepare($conexion,
        "SELECT * FROM checkpoint WHERE token_qr = ? AND estado = 'Abierto' LIMIT 1");
    mysqli_stmt_bind_param($s, 's', $token);
    mysqli_stmt_execute($s);
    $cp = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
    mysqli_stmt_close($s);

    if (!$cp) {
        header("Location: registro_qr.php?token=" . urlencode($token) . "&err=codigo_invalido");
        exit;
    }

    $idCp = (int)$cp['id'];

    // 2. Bloqueo por intentos
    if (intentosFallidos($conexion, $idCp, $ip) >= 5) {
        header("Location: registro_qr.php?token=" . urlencode($token) . "&err=bloqueado");
        exit;
    }

    // 3. Validar código de verificación
    $cv = codigoVigente($conexion, $idCp);
    if (!$cv || strtoupper($cv['codigo']) !== $codigo) {
        registrarIntentoFallido($conexion, $idCp, $documento, 'codigo_invalido');
        header("Location: registro_qr.php?token=" . urlencode($token) . "&err=codigo_invalido");
        exit;
    }

    // 4. Verificar si ya está registrado en este checkpoint
    $s = mysqli_prepare($conexion,
        "SELECT a.id FROM asistencia a
         JOIN aprendiz ap ON a.idAprendiz = ap.id
         WHERE ap.documento = ? AND a.idCheckpoint = ? LIMIT 1");
    mysqli_stmt_bind_param($s, 'si', $documento, $idCp);
    mysqli_stmt_execute($s);
    mysqli_stmt_store_result($s);
    if (mysqli_stmt_num_rows($s) > 0) {
        mysqli_stmt_close($s);
        registrarIntentoFallido($conexion, $idCp, $documento, 'ya_registrado');
        header("Location: registro_qr.php?token=" . urlencode($token) . "&err=ya_registrado");
        exit;
    }
    mysqli_stmt_close($s);

    // 5. Crear sesión QR (el aprendiz ya validó el código)
    $tokenSesion = crearSesionQR($conexion, $idCp, $documento);

    // 6. ¿Existe el aprendiz?
    $s = mysqli_prepare($conexion,
        "SELECT id, nombre FROM aprendiz WHERE documento = ? LIMIT 1");
    mysqli_stmt_bind_param($s, 's', $documento);
    mysqli_stmt_execute($s);
    $aprendiz = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
    mysqli_stmt_close($s);

    if ($aprendiz) {
        // Existe → registrar asistencia directamente
        registrarAsistencia($conexion, (int)$aprendiz['id'], $idCp, $cp, $ip);
        eliminarSesionQR($conexion, $tokenSesion);
        rotarCodigo($conexion, $idCp);
        header("Location: registro_qr.php?token=" . urlencode($token)
            . "&ok=1&nombre=" . urlencode($aprendiz['nombre']));
        exit;
    } else {
        // No existe → paso 2 (pedir nombre, sin recargar)
        header("Location: registro_qr.php?token=" . urlencode($token)
            . "&sesion=" . urlencode($tokenSesion));
        exit;
    }
}

// ============================================================
// PASO REGISTRO: el aprendiz ingresó sus datos
// ============================================================
if ($paso === 'registro') {
    $tokenSesion = trim($_POST['token_sesion'] ?? '');
    $nombre      = strtoupper(trim($_POST['nombre']   ?? ''));
    $tipo_doc    = strtoupper(trim($_POST['tipo_doc'] ?? ''));
    $tipos_ok    = ['CC', 'TI', 'CE', 'PA'];
    if (!in_array($tipo_doc, $tipos_ok)) {
        header("Location: registro_qr.php?token=" . urlencode($token)
            . "&sesion=" . urlencode($tokenSesion) . "&err=campos");
        exit;
    }

    if ($nombre === '' || $tokenSesion === '') {
        header("Location: registro_qr.php?token=" . urlencode($token) . "&err=campos");
        exit;
    }

    // Validar sesión QR
    $sesion = validarSesionQR($conexion, $tokenSesion);
    if (!$sesion || $sesion['cp_estado'] !== 'Abierto') {
        header("Location: registro_qr.php?token=" . urlencode($token) . "&err=sesion_expirada");
        exit;
    }

    $idCp      = (int)$sesion['idCheckpoint'];
    $documento = $sesion['documento'];
    $idFicha   = (int)$sesion['idFicha'];

    // Crear aprendiz (puede que otro dispositivo ya lo haya creado)
    $s = mysqli_prepare($conexion,
        "SELECT id, nombre FROM aprendiz WHERE documento = ? LIMIT 1");
    mysqli_stmt_bind_param($s, 's', $documento);
    mysqli_stmt_execute($s);
    $aprendiz = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
    mysqli_stmt_close($s);

    if (!$aprendiz) {
        $ins = mysqli_prepare($conexion,
            "INSERT INTO aprendiz (idFicha, tipo_doc, documento, nombre) VALUES (?, ?, ?, ?)");
        mysqli_stmt_bind_param($ins, 'isss', $idFicha, $tipo_doc, $documento, $nombre);
        mysqli_stmt_execute($ins);
        $idAprendiz = (int)mysqli_insert_id($conexion);
        mysqli_stmt_close($ins);
        $nombreFinal = $nombre;
    } else {
        $idAprendiz  = (int)$aprendiz['id'];
        $nombreFinal = $aprendiz['nombre'];
    }

    // Obtener datos del checkpoint
    $s = mysqli_prepare($conexion, "SELECT * FROM checkpoint WHERE id = ? LIMIT 1");
    mysqli_stmt_bind_param($s, 'i', $idCp);
    mysqli_stmt_execute($s);
    $cp = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
    mysqli_stmt_close($s);

    // Registrar asistencia
    registrarAsistencia($conexion, $idAprendiz, $idCp, $cp, $ip);
    eliminarSesionQR($conexion, $tokenSesion);
    rotarCodigo($conexion, $idCp);

    header("Location: registro_qr.php?token=" . urlencode($token)
        . "&ok=1&nombre=" . urlencode($nombreFinal));
    exit;
}

header('Location: index.php');
exit;

// ============================================================
// Función interna: inserta registro de asistencia
// ============================================================
function registrarAsistencia(mysqli $db, int $idAprendiz, int $idCp, array $cp, string $ip): void {
    // Evitar duplicado
    $s = mysqli_prepare($db,
        "SELECT id FROM asistencia WHERE idAprendiz = ? AND idCheckpoint = ? LIMIT 1");
    mysqli_stmt_bind_param($s, 'ii', $idAprendiz, $idCp);
    mysqli_stmt_execute($s);
    mysqli_stmt_store_result($s);
    if (mysqli_stmt_num_rows($s) > 0) { mysqli_stmt_close($s); return; }
    mysqli_stmt_close($s);

    // Estado: Tarde si pasaron más de 10 min de la apertura
    $apert   = strtotime($cp['fecha'] . ' ' . $cp['hora_apertura']);
    $estado  = (time() - $apert) > 600 ? 'Tarde' : 'Asistio';
    $hora    = date('H:i:s');
    $fecha   = $cp['fecha'];

    $ins = mysqli_prepare($db,
        "INSERT INTO asistencia (idAprendiz, idCheckpoint, fecha, hora, estado, fuente, ip)
         VALUES (?, ?, ?, ?, ?, 'QR', ?)");
    mysqli_stmt_bind_param($ins, 'iissss', $idAprendiz, $idCp, $fecha, $hora, $estado, $ip);
    mysqli_stmt_execute($ins);
    mysqli_stmt_close($ins);
}
