<?php
// =============================================================
// aprendiz_accion.php — CRUD de aprendices con validaciones
// - Tipo de documento con reglas de longitud y formato
// - Advertencia de nombre duplicado (no bloquea)
// =============================================================
require 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php'); exit;
}

$accion     = $_POST['accion']     ?? '';
$idFicha    = (int)($_POST['idFicha']    ?? 0);
$idAprendiz = (int)($_POST['idAprendiz'] ?? 0);
$volver     = "aprendices.php?ficha=$idFicha";

// Tipos de documento válidos con reglas de longitud
$tipos_ok = ['CC', 'TI', 'CE', 'PA'];
$reglas_doc = [
    'CC' => ['min' => 6,  'max' => 10, 'solo_numeros' => true ],
    'TI' => ['min' => 10, 'max' => 11, 'solo_numeros' => true ],
    'CE' => ['min' => 6,  'max' => 12, 'solo_numeros' => true ],
    'PA' => ['min' => 5,  'max' => 20, 'solo_numeros' => false],
];

// Valida el número de documento según el tipo
function validarDocumento(string $doc, string $tipo, array $reglas): ?string {
    if (!isset($reglas[$tipo])) return 'tipo_doc';
    $r   = $reglas[$tipo];
    $len = strlen($doc);
    if ($r['solo_numeros'] && !ctype_digit($doc)) return 'doc_formato';
    if (!$r['solo_numeros'] && !ctype_alnum($doc)) return 'doc_formato';
    if ($len < $r['min'] || $len > $r['max'])      return 'doc_formato';
    return null; // válido
}

// --- CREAR ---
if ($accion === 'crear') {
    $documento = strtoupper(trim($_POST['documento'] ?? ''));
    $nombre    = strtoupper(trim($_POST['nombre']    ?? ''));
    $tipo_doc  = strtoupper(trim($_POST['tipo_doc']  ?? ''));

    if (!in_array($tipo_doc, $tipos_ok)) {
        header("Location: $volver&err=tipo_doc"); exit;
    }
    if ($documento === '' || $nombre === '' || $idFicha <= 0) {
        header("Location: $volver&err=campos"); exit;
    }

    $err_doc = validarDocumento($documento, $tipo_doc, $reglas_doc);
    if ($err_doc) { header("Location: $volver&err=$err_doc"); exit; }

    // Duplicado por documento (global, no por ficha)
    $s = mysqli_prepare($conexion, "SELECT id FROM aprendiz WHERE documento = ? LIMIT 1");
    mysqli_stmt_bind_param($s, 's', $documento);
    mysqli_stmt_execute($s);
    mysqli_stmt_store_result($s);
    if (mysqli_stmt_num_rows($s) > 0) {
        mysqli_stmt_close($s);
        header("Location: $volver&err=duplicado"); exit;
    }
    mysqli_stmt_close($s);

    $ins = mysqli_prepare($conexion,
        "INSERT INTO aprendiz (idFicha, tipo_doc, documento, nombre) VALUES (?, ?, ?, ?)");
    mysqli_stmt_bind_param($ins, 'isss', $idFicha, $tipo_doc, $documento, $nombre);
    mysqli_stmt_execute($ins);
    mysqli_stmt_close($ins);

    header("Location: $volver&ok=creado"); exit;
}

// --- EDITAR ---
if ($accion === 'editar') {
    $nombre   = strtoupper(trim($_POST['nombre']   ?? ''));
    $tipo_doc = strtoupper(trim($_POST['tipo_doc'] ?? ''));

    if (!in_array($tipo_doc, $tipos_ok)) {
        header("Location: $volver&err=tipo_doc"); exit;
    }
    if ($nombre === '' || $idAprendiz <= 0) {
        header("Location: $volver&err=campos"); exit;
    }

    // Al editar no se cambia el documento, solo nombre y tipo_doc
    // Pero si el tipo cambió, verificar que el documento existente siga siendo válido
    $s = mysqli_prepare($conexion,
        "SELECT documento FROM aprendiz WHERE id = ? AND idFicha = ? LIMIT 1");
    mysqli_stmt_bind_param($s, 'ii', $idAprendiz, $idFicha);
    mysqli_stmt_execute($s);
    $ap = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
    mysqli_stmt_close($s);
    if (!$ap) { header("Location: $volver&err=no_encontrado"); exit; }

    $err_doc = validarDocumento($ap['documento'], $tipo_doc, $reglas_doc);
    if ($err_doc) { header("Location: $volver&err=$err_doc"); exit; }

    $upd = mysqli_prepare($conexion,
        "UPDATE aprendiz SET nombre = ?, tipo_doc = ? WHERE id = ? AND idFicha = ?");
    mysqli_stmt_bind_param($upd, 'ssii', $nombre, $tipo_doc, $idAprendiz, $idFicha);
    mysqli_stmt_execute($upd);
    mysqli_stmt_close($upd);

    header("Location: $volver&ok=editado"); exit;
}

// --- ELIMINAR ---
if ($accion === 'eliminar') {
    if ($idAprendiz <= 0) { header("Location: $volver"); exit; }
    $del = mysqli_prepare($conexion,
        "DELETE FROM aprendiz WHERE id = ? AND idFicha = ?");
    mysqli_stmt_bind_param($del, 'ii', $idAprendiz, $idFicha);
    mysqli_stmt_execute($del);
    mysqli_stmt_close($del);
    header("Location: $volver&ok=eliminado"); exit;
}

header("Location: $volver"); exit;
