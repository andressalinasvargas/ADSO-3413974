-- =============================================================
-- Sistema de Asistencia SENA v3
-- Base de datos: asistencia_sena
-- Sin datos de prueba. Todo lo registra el instructor.
-- =============================================================

CREATE DATABASE IF NOT EXISTS asistencia_sena
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE asistencia_sena;

-- -------------------------------------------------------------
-- Tabla: ficha
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ficha (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    numero     VARCHAR(20)  NOT NULL UNIQUE,
    programa   VARCHAR(150) NOT NULL DEFAULT 'Tecnólogo en Análisis y Desarrollo de Software',
    activa     TINYINT(1)   NOT NULL DEFAULT 1,
    creada_en  DATETIME     NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------------
-- Tabla: aprendiz
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS aprendiz (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    idFicha    INT          NOT NULL,
    tipo_doc   ENUM('CC','TI','CE','PA') NOT NULL DEFAULT 'CC',
    documento  VARCHAR(20)  NOT NULL UNIQUE,
    nombre     VARCHAR(100) NOT NULL,
    FOREIGN KEY (idFicha) REFERENCES ficha(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------------
-- Tabla: checkpoint
-- Cada jornada abierta (Inicio, Receso, Finalizacion)
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS checkpoint (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    idFicha       INT  NOT NULL,
    tipo          ENUM('Inicio','Receso','Finalizacion') NOT NULL,
    fecha         DATE NOT NULL,
    hora_apertura TIME NOT NULL,
    hora_cierre   TIME DEFAULT NULL,
    estado        ENUM('Abierto','Cerrado') NOT NULL DEFAULT 'Abierto',
    token_qr      VARCHAR(64) NOT NULL UNIQUE,
    FOREIGN KEY (idFicha) REFERENCES ficha(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_checkpoint_fecha ON checkpoint(fecha, estado);

-- -------------------------------------------------------------
-- Tabla: codigo_verificacion
-- Código alfanumérico rotativo por checkpoint
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS codigo_verificacion (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    idCheckpoint INT      NOT NULL,
    codigo       VARCHAR(8) NOT NULL,
    generado_en  DATETIME   NOT NULL,
    expira_en    DATETIME   NOT NULL,
    FOREIGN KEY (idCheckpoint) REFERENCES checkpoint(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_codigo_exp ON codigo_verificacion(idCheckpoint, expira_en);

-- -------------------------------------------------------------
-- Tabla: sesion_qr
-- Sesión temporal cuando el aprendiz ya validó el código
-- Evita que la página se recargue mientras escribe sus datos
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sesion_qr (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    idCheckpoint INT         NOT NULL,
    token_sesion VARCHAR(64) NOT NULL UNIQUE,
    documento    VARCHAR(20) NOT NULL,
    ip           VARCHAR(45) DEFAULT NULL,
    creada_en    DATETIME    NOT NULL,
    expira_en    DATETIME    NOT NULL,
    FOREIGN KEY (idCheckpoint) REFERENCES checkpoint(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------------
-- Tabla: asistencia
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS asistencia (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    idAprendiz   INT  NOT NULL,
    idCheckpoint INT  NOT NULL,
    fecha        DATE NOT NULL,
    hora         TIME NOT NULL,
    estado       ENUM('Asistio','Tarde','Ausente') NOT NULL DEFAULT 'Asistio',
    fuente       ENUM('QR','Manual') NOT NULL DEFAULT 'Manual',
    fue_editado  TINYINT(1) NOT NULL DEFAULT 0,
    ip           VARCHAR(45) DEFAULT NULL,
    UNIQUE KEY unico_ap_cp (idAprendiz, idCheckpoint),
    FOREIGN KEY (idAprendiz)   REFERENCES aprendiz(id)   ON DELETE CASCADE,
    FOREIGN KEY (idCheckpoint) REFERENCES checkpoint(id)  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_asistencia_fecha ON asistencia(fecha);

-- -------------------------------------------------------------
-- Tabla: auditoria_modificacion
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS auditoria_modificacion (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    idAsistencia    INT NOT NULL,
    estado_anterior ENUM('Asistio','Tarde','Ausente') NOT NULL,
    estado_nuevo    ENUM('Asistio','Tarde','Ausente') NOT NULL,
    fecha_hora      DATETIME NOT NULL,
    FOREIGN KEY (idAsistencia) REFERENCES asistencia(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------------
-- Tabla: intento_fallido
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS intento_fallido (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    idCheckpoint INT         NOT NULL,
    documento    VARCHAR(20) DEFAULT NULL,
    tipo_error   VARCHAR(80) NOT NULL,
    ip           VARCHAR(45) DEFAULT NULL,
    fecha_hora   DATETIME    NOT NULL,
    FOREIGN KEY (idCheckpoint) REFERENCES checkpoint(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
