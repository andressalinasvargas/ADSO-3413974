<?php
// =============================================================
// rotar_codigo.php — AJAX: rota el código y devuelve JSON
// Llamado desde script.js cuando el contador llega a cero
// =============================================================
require 'conexion.php';
require 'funciones.php';

header('Content-Type: application/json');

$idCp = (int)($_GET['cp'] ?? 0);
if ($idCp <= 0) { echo json_encode(['ok' => false]); exit; }

// Verificar que el checkpoint siga abierto
$s = mysqli_prepare($conexion,
    "SELECT id FROM checkpoint WHERE id = ? AND estado = 'Abierto' LIMIT 1");
mysqli_stmt_bind_param($s, 'i', $idCp);
mysqli_stmt_execute($s);
mysqli_stmt_store_result($s);
$abierto = mysqli_stmt_num_rows($s) > 0;
mysqli_stmt_close($s);

if (!$abierto) { echo json_encode(['ok' => false, 'cerrado' => true]); exit; }

$nuevo = rotarCodigo($conexion, $idCp);
echo json_encode([
    'ok'        => true,
    'codigo'    => $nuevo['codigo'],
    'expira_ts' => $nuevo['expira_ts'],
]);
exit;
