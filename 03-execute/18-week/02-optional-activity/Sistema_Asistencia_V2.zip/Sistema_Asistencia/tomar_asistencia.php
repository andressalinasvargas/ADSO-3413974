<?php
// =============================================================
// tomar_asistencia.php — Registro manual del instructor
// =============================================================
require 'conexion.php';
require 'funciones.php';

$idCp = (int)($_GET['cp'] ?? 0);
if ($idCp <= 0) { header('Location: index.php'); exit; }

$s = mysqli_prepare($conexion, "SELECT cp.*, f.numero AS ficha_num, f.id AS idFicha
     FROM checkpoint cp JOIN ficha f ON cp.idFicha = f.id WHERE cp.id = ? LIMIT 1");
mysqli_stmt_bind_param($s, 'i', $idCp);
mysqli_stmt_execute($s);
$cp = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
mysqli_stmt_close($s);

if (!$cp) { header('Location: index.php'); exit; }

$sql = "SELECT ap.id, ap.documento, ap.nombre, ap.tipo_doc,
               a.id AS idAs, a.estado, a.fuente, a.fue_editado
        FROM aprendiz ap
        LEFT JOIN asistencia a ON ap.id = a.idAprendiz AND a.idCheckpoint = ?
        WHERE ap.idFicha = ?
        ORDER BY ap.nombre ASC";
$s = mysqli_prepare($conexion, $sql);
mysqli_stmt_bind_param($s, 'ii', $idCp, $cp['idFicha']);
mysqli_stmt_execute($s);
$lista = mysqli_fetch_all(mysqli_stmt_get_result($s), MYSQLI_ASSOC);
mysqli_stmt_close($s);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asistencia manual — SENA</title>
    <link rel="stylesheet" href="style.css">
    <script src="script.js"></script>
</head>
<body>
<header>
    <h1>Sistema de Asistencia — SENA</h1>
    <p>Ficha <?php echo htmlspecialchars($cp['ficha_num']); ?> — Registro manual</p>
</header>
<main>
    <h2>Registro manual — <?php echo labelCheckpoint($cp['tipo']); ?></h2>

    <?php if (isset($_GET['ok'])): ?>
    <div class="alerta alerta-ok">Asistencia guardada.</div>
    <?php elseif (isset($_GET['err'])): ?>
    <div class="alerta alerta-error">Error al guardar. Intenta nuevamente.</div>
    <?php endif; ?>

    <div class="info-box">
        <p><strong>Fecha:</strong> <?php echo date('d/m/Y', strtotime($cp['fecha'])); ?></p>
        <p><strong>Apertura:</strong> <?php echo substr($cp['hora_apertura'],0,5); ?>
            <?php if ($cp['hora_cierre']): ?>
            — <strong>Cierre:</strong> <?php echo substr($cp['hora_cierre'],0,5); ?>
            <?php endif; ?>
        </p>
        <p><strong>Estado:</strong>
            <span class="badge <?php echo $cp['estado']==='Abierto' ? 'badge-abierto' : 'badge-cerrado'; ?>">
                <?php echo $cp['estado']; ?>
            </span>
        </p>
    </div>

    <form action="guardar.php" method="POST" onsubmit="return confirmarGuardar()">
        <input type="hidden" name="idCheckpoint" value="<?php echo $idCp; ?>">
        <input type="hidden" name="idFicha"      value="<?php echo $cp['idFicha']; ?>">

        <table>
            <thead>
                <tr><th>#</th><th>Tipo</th><th>Documento</th><th>Nombre</th>
                    <th>Estado</th><th>Fuente</th></tr>
            </thead>
            <tbody>
            <?php $n=1; foreach ($lista as $fila):
                $est   = $fila['estado'] ?? 'Asistio';
                $clase = match($est) {
                    'Asistio' => 'est-asistio', 'Tarde' => 'est-tarde',
                    'Ausente' => 'est-ausente', default => ''
                };
            ?>
            <tr>
                <td><?php echo $n++; ?></td>
                <td><?php echo labelTipoDoc($fila['tipo_doc']); ?></td>
                <td><?php echo htmlspecialchars($fila['documento']); ?></td>
                <td>
                    <?php echo htmlspecialchars($fila['nombre']); ?>
                    <?php if ($fila['fue_editado']): ?><span class="badge badge-editado">Editado</span><?php endif; ?>
                </td>
                <td>
                    <input type="hidden" name="aprendices[]" value="<?php echo $fila['id']; ?>">
                    <select name="estado_<?php echo $fila['id']; ?>" class="<?php echo $clase; ?>">
                        <option value="Asistio" <?php if($est==='Asistio') echo 'selected'; ?>>Asistió</option>
                        <option value="Tarde"   <?php if($est==='Tarde')   echo 'selected'; ?>>Tarde</option>
                        <option value="Ausente" <?php if($est==='Ausente') echo 'selected'; ?>>Ausente</option>
                    </select>
                </td>
                <td>
                    <?php if ($fila['fuente']): ?>
                        <span class="badge <?php echo $fila['fuente']==='QR' ? 'badge-qr' : ''; ?>">
                            <?php echo $fila['fuente']; ?>
                        </span>
                    <?php else: ?>—<?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <?php if ($cp['estado'] === 'Abierto'): ?>
        <button type="submit" class="btn">Guardar asistencia</button>
        <?php endif; ?>
        <a href="panel_ficha.php?id=<?php echo $cp['idFicha']; ?>" class="btn btn-secondary">Volver</a>
    </form>
</main>
<footer>Sistema de Asistencia &mdash; SENA</footer>
</body>
</html>
