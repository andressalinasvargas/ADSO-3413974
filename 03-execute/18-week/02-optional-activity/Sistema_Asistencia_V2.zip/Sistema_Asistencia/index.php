<?php
// =============================================================
// index.php — Inicio: lista de fichas
// Incluye: crear ficha, archivar ficha, reactivar ficha
// =============================================================
require 'conexion.php';
require 'funciones.php';

// --- Crear ficha ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? '';

    if ($accion === 'crear_ficha') {
        $numero   = preg_replace('/[^0-9]/', '', trim($_POST['numero'] ?? ''));
        $programa = trim($_POST['programa'] ?? 'Tecnólogo en Análisis y Desarrollo de Software');
        if ($programa === '') $programa = 'Tecnólogo en Análisis y Desarrollo de Software';

        if ($numero !== '') {
            $chk = mysqli_prepare($conexion, "SELECT id FROM ficha WHERE numero = ? LIMIT 1");
            mysqli_stmt_bind_param($chk, 's', $numero);
            mysqli_stmt_execute($chk);
            mysqli_stmt_store_result($chk);
            $existe = mysqli_stmt_num_rows($chk) > 0;
            mysqli_stmt_close($chk);

            if (!$existe) {
                $ahora = date('Y-m-d H:i:s');
                $ins   = mysqli_prepare($conexion,
                    "INSERT INTO ficha (numero, programa, activa, creada_en) VALUES (?, ?, 1, ?)");
                mysqli_stmt_bind_param($ins, 'sss', $numero, $programa, $ahora);
                mysqli_stmt_execute($ins);
                mysqli_stmt_close($ins);
                header('Location: index.php?ok=ficha_creada');
                exit;
            } else {
                header('Location: index.php?err=duplicada');
                exit;
            }
        }
    }

    // --- Archivar ficha ---
    if ($accion === 'archivar_ficha') {
        $idFicha = (int)($_POST['idFicha'] ?? 0);
        if ($idFicha > 0) {
            // No se puede archivar si tiene un checkpoint abierto
            $chk = mysqli_prepare($conexion,
                "SELECT id FROM checkpoint WHERE idFicha = ? AND estado = 'Abierto' LIMIT 1");
            mysqli_stmt_bind_param($chk, 'i', $idFicha);
            mysqli_stmt_execute($chk);
            mysqli_stmt_store_result($chk);
            $tieneAbierto = mysqli_stmt_num_rows($chk) > 0;
            mysqli_stmt_close($chk);

            if ($tieneAbierto) {
                header('Location: index.php?err=tiene_checkpoint');
                exit;
            }

            $upd = mysqli_prepare($conexion, "UPDATE ficha SET activa = 0 WHERE id = ?");
            mysqli_stmt_bind_param($upd, 'i', $idFicha);
            mysqli_stmt_execute($upd);
            mysqli_stmt_close($upd);
            header('Location: index.php?ok=archivada');
            exit;
        }
    }

    // --- Reactivar ficha ---
    if ($accion === 'reactivar_ficha') {
        $idFicha = (int)($_POST['idFicha'] ?? 0);
        if ($idFicha > 0) {
            $upd = mysqli_prepare($conexion, "UPDATE ficha SET activa = 1 WHERE id = ?");
            mysqli_stmt_bind_param($upd, 'i', $idFicha);
            mysqli_stmt_execute($upd);
            mysqli_stmt_close($upd);
            header('Location: index.php?ok=reactivada');
            exit;
        }
    }

    // --- Eliminar ficha definitivamente ---
    if ($accion === 'eliminar_ficha') {
        $idFicha    = (int)($_POST['idFicha'] ?? 0);
        $confirmar  = $_POST['confirmar'] ?? '';
        if ($idFicha > 0 && $confirmar === 'SI') {
            $del = mysqli_prepare($conexion, "DELETE FROM ficha WHERE id = ?");
            mysqli_stmt_bind_param($del, 'i', $idFicha);
            mysqli_stmt_execute($del);
            mysqli_stmt_close($del);
            header('Location: index.php?ok=eliminada');
            exit;
        } else {
            header('Location: index.php?err=confirmar');
            exit;
        }
    }
}

// Listar fichas activas e inactivas
$fichas_activas = mysqli_fetch_all(mysqli_query($conexion,
    "SELECT f.*,
        (SELECT id   FROM checkpoint WHERE idFicha = f.id AND estado = 'Abierto' LIMIT 1) AS idCpAbierto,
        (SELECT tipo FROM checkpoint WHERE idFicha = f.id AND estado = 'Abierto' LIMIT 1) AS tipoCpAbierto,
        (SELECT COUNT(*) FROM aprendiz WHERE idFicha = f.id) AS total_aprendices
     FROM ficha f WHERE f.activa = 1 ORDER BY f.numero ASC"
), MYSQLI_ASSOC);

$fichas_archivadas = mysqli_fetch_all(mysqli_query($conexion,
    "SELECT f.*,
        (SELECT COUNT(*) FROM aprendiz WHERE idFicha = f.id) AS total_aprendices
     FROM ficha f WHERE f.activa = 0 ORDER BY f.numero ASC"
), MYSQLI_ASSOC);

$mostrarFormFicha  = isset($_GET['nueva']);
$mostrarArchivadas = isset($_GET['archivadas']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Asistencia — SENA</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Sistema de Asistencia — SENA</h1>
    <p>Panel principal</p>
</header>

<main>
    <h2>Fichas registradas</h2>

    <?php
    $msgs_ok = [
        'ficha_creada' => 'Ficha creada correctamente.',
        'archivada'    => 'Ficha archivada. Sus datos se conservan.',
        'reactivada'   => 'Ficha reactivada correctamente.',
        'eliminada'    => 'Ficha eliminada definitivamente.',
    ];
    $msgs_err = [
        'duplicada'        => 'Ya existe una ficha con ese número.',
        'tiene_checkpoint' => 'No se puede archivar: la ficha tiene una jornada activa. Ciérrala primero.',
        'confirmar'        => 'Para eliminar definitivamente escribe SI en el campo de confirmación.',
    ];
    if (isset($_GET['ok']) && isset($msgs_ok[$_GET['ok']])): ?>
    <div class="alerta alerta-ok"><?php echo $msgs_ok[$_GET['ok']]; ?></div>
    <?php endif;
    if (isset($_GET['err']) && isset($msgs_err[$_GET['err']])): ?>
    <div class="alerta alerta-error"><?php echo $msgs_err[$_GET['err']]; ?></div>
    <?php endif; ?>

    <!-- Botón crear ficha -->
    <?php if (!$mostrarFormFicha): ?>
    <a href="index.php?nueva=1" class="btn" style="margin-bottom:18px;">+ Crear ficha</a>
    <a href="politica_datos.php" class="btn btn-secondary" style="margin-bottom:18px;font-size:13px;">
        Política de datos
    </a>
    <?php else: ?>
    <!-- Formulario crear ficha -->
    <div class="card card-verde" style="max-width:560px;margin-bottom:20px;">
        <h3 style="margin-top:0;">Nueva ficha</h3>
        <form method="POST" action="index.php">
            <input type="hidden" name="accion" value="crear_ficha">
            <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
                <div>
                    <label style="display:block;font-size:13px;font-weight:bold;margin-bottom:4px;">
                        Número de ficha *
                    </label>
                    <input type="text" name="numero" placeholder="Ej: 3413974"
                           maxlength="10" required style="width:150px;" autofocus
                           pattern="[0-9]+" title="Solo números">
                </div>
                <div style="flex:1;min-width:200px;">
                    <label style="display:block;font-size:13px;font-weight:bold;margin-bottom:4px;">
                        Programa
                    </label>
                    <input type="text" name="programa"
                           value="Tecnólogo en Análisis y Desarrollo de Software"
                           maxlength="150" style="width:100%;">
                </div>
                <div>
                    <button type="submit" class="btn">Crear</button>
                    <a href="index.php" class="btn btn-secondary">Cancelar</a>
                </div>
            </div>
        </form>
    </div>
    <?php endif; ?>

    <!-- Fichas activas -->
    <?php if (empty($fichas_activas)): ?>
    <div class="alerta alerta-info">
        No hay fichas activas. Crea la primera usando el botón de arriba.
    </div>
    <?php else: ?>
    <div class="grid-fichas">
        <?php foreach ($fichas_activas as $f): ?>
        <div class="ficha-card">
            <div class="ficha-num"><?php echo htmlspecialchars($f['numero']); ?></div>
            <div class="ficha-prog"><?php echo htmlspecialchars($f['programa']); ?></div>
            <div style="font-size:12px;color:#777;margin-bottom:4px;">
                <?php echo $f['total_aprendices']; ?> aprendiz(ces)
            </div>
            <div class="ficha-est">
                <?php if ($f['idCpAbierto']): ?>
                <span class="badge badge-abierto">
                    ● <?php echo labelCheckpoint($f['tipoCpAbierto']); ?> activo
                </span>
                <?php else: ?>
                <span style="color:#555;font-size:12px;">Sin jornada activa</span>
                <?php endif; ?>
            </div>
            <div class="ficha-btn" style="display:flex;gap:6px;flex-wrap:wrap;margin-top:10px;">
                <a href="panel_ficha.php?id=<?php echo $f['id']; ?>" class="btn">
                    Abrir ficha
                </a>
                <!-- Archivar (no elimina, solo oculta) -->
                <?php if (!$f['idCpAbierto']): ?>
                <form method="POST" action="index.php" style="display:inline;"
                      onsubmit="return confirm('¿Archivar la ficha <?php echo htmlspecialchars(addslashes($f['numero'])); ?>?\nSus datos se conservarán y podrá reactivarla después.')">
                    <input type="hidden" name="accion"  value="archivar_ficha">
                    <input type="hidden" name="idFicha" value="<?php echo $f['id']; ?>">
                    <button type="submit" class="btn btn-secondary" style="font-size:12px;padding:5px 10px;">
                        Archivar
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Fichas archivadas -->
    <?php if (!empty($fichas_archivadas)): ?>
    <div style="margin-top:28px;">
        <a href="index.php<?php echo $mostrarArchivadas ? '' : '?archivadas=1'; ?>"
           class="btn btn-secondary" style="font-size:13px;padding:6px 14px;">
            <?php echo $mostrarArchivadas
                ? 'Ocultar fichas archivadas'
                : 'Ver fichas archivadas (' . count($fichas_archivadas) . ')'; ?>
        </a>
    </div>

    <?php if ($mostrarArchivadas): ?>
    <h3 style="margin-top:18px;">Fichas archivadas</h3>
    <div class="grid-fichas">
        <?php foreach ($fichas_archivadas as $f): ?>
        <div class="ficha-card" style="opacity:.8;border-color:#ccc;">
            <div class="ficha-num" style="color:#888;"><?php echo htmlspecialchars($f['numero']); ?></div>
            <div class="ficha-prog"><?php echo htmlspecialchars($f['programa']); ?></div>
            <div style="font-size:12px;color:#aaa;margin-bottom:6px;">
                <?php echo $f['total_aprendices']; ?> aprendiz(ces) · Archivada
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px;">
                <!-- Reactivar -->
                <form method="POST" action="index.php" style="display:inline;">
                    <input type="hidden" name="accion"  value="reactivar_ficha">
                    <input type="hidden" name="idFicha" value="<?php echo $f['id']; ?>">
                    <button type="submit" class="btn" style="font-size:12px;padding:5px 10px;">
                        Reactivar
                    </button>
                </form>
                <!-- Eliminar definitivamente -->
                <button class="btn btn-danger" style="font-size:12px;padding:5px 10px;"
                        onclick="confirmarEliminacion(<?php echo $f['id']; ?>, '<?php echo htmlspecialchars(addslashes($f['numero'])); ?>')">
                    Eliminar
                </button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Formulario oculto para eliminación con doble confirmación -->
    <form id="form-eliminar" method="POST" action="index.php" style="display:none;">
        <input type="hidden" name="accion"    value="eliminar_ficha">
        <input type="hidden" name="idFicha"   id="del-idFicha">
        <input type="hidden" name="confirmar" id="del-confirmar">
    </form>
    <?php endif; ?>
    <?php endif; ?>

</main>

<footer>Sistema de Asistencia &mdash; SENA &mdash;
    <a href="politica_datos.php" style="color:#aaa;">Política de datos</a>
</footer>

<script>
function confirmarEliminacion(id, numero) {
    var respuesta = prompt(
        'Esta acción ELIMINARÁ PERMANENTEMENTE la ficha ' + numero +
        ' y todos sus datos (aprendices, asistencias, historial).\n\n' +
        'Esta acción NO se puede deshacer.\n\n' +
        'Escribe SI para confirmar:'
    );
    if (respuesta === null) return; // canceló
    document.getElementById('del-idFicha').value   = id;
    document.getElementById('del-confirmar').value = respuesta.trim().toUpperCase();
    document.getElementById('form-eliminar').submit();
}
</script>
</body>
</html>
