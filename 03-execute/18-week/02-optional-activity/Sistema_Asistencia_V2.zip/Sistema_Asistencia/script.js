// =============================================================
// script.js — Sistema de Asistencia SENA v3
// =============================================================

// ----- Contador regresivo del código alfanumérico -----
// El elemento #contador-seg lleva data-expira (Unix timestamp)
// Cuando llega a 0 rota el código vía AJAX sin recargar la página

function iniciarContadorInstructor() {
    var el = document.getElementById('contador-seg');
    if (!el) return;

    function tick() {
        var expira    = parseInt(el.getAttribute('data-expira'), 10);
        var restantes = expira - Math.floor(Date.now() / 1000);

        if (restantes <= 0) {
            // Rotar código vía AJAX para no recargar la página del instructor
            fetch('rotar_codigo.php?cp=' + el.getAttribute('data-cp'))
                .then(function(r) { return r.json(); })
                .then(function(d) {
                    if (d.ok) {
                        // Actualizar código en pantalla
                        var codEl = document.getElementById('codigo-display');
                        if (codEl) codEl.textContent = d.codigo;
                        el.setAttribute('data-expira', d.expira_ts);
                    }
                })
                .catch(function() {});
            return;
        }

        el.textContent = restantes;
    }

    tick();
    setInterval(tick, 1000);
}

// ----- Auto-refresco de aprendices registrados (panel instructor) -----
// Consulta silenciosa cada 10 s sin recargar la página

function iniciarRefreshRegistrados() {
    var el = document.getElementById('registrados-count');
    if (!el) return;

    var cp = el.getAttribute('data-cp');

    setInterval(function() {
        fetch('estado_checkpoint.php?cp=' + cp)
            .then(function(r) { return r.json(); })
            .then(function(d) {
                if (d.registrados !== undefined) {
                    el.textContent = d.registrados;
                }
                if (d.total !== undefined) {
                    var tot = document.getElementById('registrados-total');
                    if (tot) tot.textContent = d.total;
                }
                // Actualizar barra de progreso
                var bar = document.getElementById('progreso-bar');
                if (bar && d.total > 0) {
                    bar.style.width = Math.round((d.registrados / d.total) * 100) + '%';
                }
            })
            .catch(function() {});
    }, 10000);
}

// ----- Mayúsculas automáticas en campos de nombre -----
function activarMayusculas() {
    document.querySelectorAll('.campo-mayus').forEach(function(input) {
        input.addEventListener('input', function() {
            var pos = this.selectionStart;
            this.value = this.value.toUpperCase();
            this.setSelectionRange(pos, pos);
        });
    });
}

// ----- Confirmaciones -----
function confirmarCierre() {
    return confirm('¿Cerrar el checkpoint? Los aprendices sin registro quedarán como Ausente.');
}
function confirmarEliminar(nombre) {
    return confirm('¿Eliminar a ' + nombre + '? Esta acción no se puede deshacer.');
}
function confirmarGuardar() {
    return confirm('¿Guardar la asistencia de todos los aprendices?');
}

// ----- Init -----
window.addEventListener('load', function() {
    iniciarContadorInstructor();
    iniciarRefreshRegistrados();
    activarMayusculas();
});
