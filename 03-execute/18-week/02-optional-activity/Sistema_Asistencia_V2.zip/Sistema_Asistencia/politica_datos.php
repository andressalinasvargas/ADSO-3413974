<?php
// =============================================================
// politica_datos.php — Política de datos y retención
// Marco: Ley 1581 de 2012 y Decreto 1377 de 2013 (Colombia)
// =============================================================
require 'conexion.php';
require 'funciones.php';

// Estadísticas para mostrar al administrador
$total_aprendices = (int)mysqli_fetch_assoc(
    mysqli_query($conexion, "SELECT COUNT(*) AS t FROM aprendiz"))['t'];

$total_registros = (int)mysqli_fetch_assoc(
    mysqli_query($conexion, "SELECT COUNT(*) AS t FROM asistencia"))['t'];

$fecha_mas_antigua = mysqli_fetch_assoc(
    mysqli_query($conexion, "SELECT MIN(fecha) AS f FROM asistencia"))['f'];

$total_fichas = (int)mysqli_fetch_assoc(
    mysqli_query($conexion, "SELECT COUNT(*) AS t FROM ficha"))['t'];

// Registros con más de 2 años (candidatos a depuración)
$fecha_limite = date('Y-m-d', strtotime('-2 years'));
$candidatos   = (int)mysqli_fetch_assoc(mysqli_query($conexion,
    "SELECT COUNT(*) AS t FROM asistencia WHERE fecha < '$fecha_limite'"))['t'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Política de Datos — SENA</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Sistema de Asistencia — SENA</h1>
    <p>Política de protección y retención de datos</p>
</header>

<main>
    <h2>Política de protección y retención de datos</h2>

    <div class="alerta alerta-info">
        Este sistema almacena datos personales de aprendices del SENA. Su tratamiento
        está regulado por la <strong>Ley 1581 de 2012</strong> de Protección de Datos
        Personales y el <strong>Decreto 1377 de 2013</strong>.
    </div>

    <!-- Estado actual de los datos -->
    <h3>Estado actual de los datos</h3>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));
                gap:12px;margin-bottom:24px;">
        <?php
        $stats = [
            ['Fichas registradas',      $total_fichas,     '#39A900'],
            ['Aprendices registrados',  $total_aprendices, '#39A900'],
            ['Registros de asistencia', $total_registros,  '#3a6bc4'],
            ['Registros > 2 años',      $candidatos,       $candidatos > 0 ? '#c0392b' : '#39A900'],
        ];
        foreach ($stats as $st): ?>
        <div style="background:#fff;border:1px solid #ddd;border-radius:6px;
                    padding:14px;text-align:center;">
            <div style="font-size:28px;font-weight:bold;color:<?php echo $st[2]; ?>;">
                <?php echo $st[1]; ?>
            </div>
            <div style="font-size:12px;color:#666;margin-top:4px;">
                <?php echo $st[0]; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php if ($fecha_mas_antigua): ?>
    <p style="font-size:13px;color:#666;margin-bottom:20px;">
        Registro más antiguo: <strong><?php echo date('d/m/Y', strtotime($fecha_mas_antigua)); ?></strong>
    </p>
    <?php endif; ?>

    <!-- Marco legal -->
    <h3>Marco legal aplicable</h3>
    <div class="card" style="margin-bottom:16px;">
        <p><strong>Ley 1581 de 2012 — Protección de Datos Personales (Colombia)</strong></p>
        <p style="font-size:13px;margin-top:6px;line-height:1.7;">
            Los datos personales almacenados (nombre, tipo de documento, número de documento)
            son datos de carácter personal. El SENA, como entidad responsable del tratamiento,
            debe:<br>
            • Informar a los aprendices que sus datos serán almacenados y con qué finalidad.<br>
            • Conservar los datos únicamente durante el tiempo necesario para cumplir la
              finalidad del tratamiento.<br>
            • Eliminar o anonimizar los datos cuando ya no sean necesarios o cuando el
              titular lo solicite.
        </p>
    </div>
    <div class="card" style="margin-bottom:16px;">
        <p><strong>Decreto 1377 de 2013 — Reglamentario de la Ley 1581</strong></p>
        <p style="font-size:13px;margin-top:6px;line-height:1.7;">
            Establece que el responsable del tratamiento debe definir políticas internas
            de retención de datos y comunicarlas a los titulares antes de recolectar
            su información.
        </p>
    </div>

    <!-- Tiempos de retención -->
    <h3>Tiempos de retención definidos</h3>
    <table>
        <thead>
            <tr>
                <th>Tipo de dato</th>
                <th>Tiempo de retención</th>
                <th>Acción al vencer</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Registros de asistencia activos</td>
                <td>Durante la vigencia del programa de formación</td>
                <td>Archivar</td>
            </tr>
            <tr>
                <td>Registros históricos de asistencia</td>
                <td>2 años adicionales al cierre del programa</td>
                <td>Anonimizar o eliminar</td>
            </tr>
            <tr>
                <td>Datos personales del aprendiz</td>
                <td>Hasta que venza el período de retención, salvo obligación legal</td>
                <td>Anonimizar (no eliminar si hay obligación)</td>
            </tr>
            <tr>
                <td>Log de intentos fallidos</td>
                <td>6 meses desde el registro</td>
                <td>Eliminar automáticamente</td>
            </tr>
            <tr>
                <td>Auditoría de modificaciones</td>
                <td>2 años adicionales al cierre del programa</td>
                <td>Eliminar</td>
            </tr>
        </tbody>
    </table>

    <!-- Finalidades del tratamiento -->
    <h3>Finalidad del tratamiento de datos</h3>
    <div class="info-box">
        <p>Los datos personales recolectados por este sistema se utilizan exclusivamente para:</p>
        <ul style="margin-top:8px;padding-left:18px;font-size:14px;line-height:1.8;">
            <li>Registrar y verificar la asistencia de los aprendices a las jornadas de
                formación.</li>
            <li>Generar reportes de asistencia para uso interno del SENA.</li>
            <li>Cumplir con los requisitos de trazabilidad del proceso formativo.</li>
        </ul>
        <p style="margin-top:8px;font-size:13px;color:#555;">
            Los datos <strong>no se comparten con terceros</strong> ni se utilizan con
            finalidades distintas a las descritas.
        </p>
    </div>

    <!-- Derechos de los titulares -->
    <h3>Derechos de los titulares</h3>
    <div class="card">
        <p style="font-size:14px;line-height:1.8;">
            De acuerdo con el artículo 8 de la Ley 1581 de 2012, cada aprendiz tiene
            derecho a:<br>
            <strong>Conocer</strong> los datos que el sistema tiene almacenados sobre su persona.<br>
            <strong>Actualizar</strong> sus datos si son incorrectos o están desactualizados.<br>
            <strong>Rectificar</strong> información errónea en sus registros de asistencia.<br>
            <strong>Solicitar la supresión</strong> de sus datos cuando no exista obligación
            legal de conservarlos.<br>
            <strong>Revocar la autorización</strong> para el tratamiento de sus datos
            personales.
        </p>
        <p style="margin-top:10px;font-size:13px;color:#555;">
            Para ejercer estos derechos, el aprendiz debe dirigirse al instructor o
            coordinador académico de su ficha de formación.
        </p>
    </div>

    <!-- Pendiente técnico -->
    <?php if ($candidatos > 0): ?>
    <div class="alerta alerta-warn" style="margin-top:20px;">
        <strong>Atención:</strong> Hay <?php echo $candidatos; ?> registro(s) de asistencia
        con más de 2 años de antigüedad (anteriores al
        <?php echo date('d/m/Y', strtotime($fecha_limite)); ?>).
        Estos registros son candidatos a depuración según la política de retención.
        Contacte al administrador del sistema para iniciar el proceso de anonimización
        o eliminación.
    </div>
    <?php endif; ?>

    <div class="alerta alerta-warn" style="margin-top:16px;">
        <strong>Nota técnica:</strong> La función de depuración y anonimización automática
        de datos está pendiente de implementación. Requiere revisión legal del SENA antes
        de su despliegue en producción. Ver sección 16 del documento de análisis.
    </div>

    <div style="margin-top:24px;">
        <a href="index.php" class="btn btn-secondary">← Volver al inicio</a>
    </div>
</main>

<footer>Sistema de Asistencia &mdash; SENA &mdash;
    Ley 1581 de 2012 · Decreto 1377 de 2013
</footer>
</body>
</html>
