<?php
// =============================================================
// estado_checkpoint.php — AJAX: registrados / total en tiempo real
// =============================================================
require 'conexion.php';

header('Content-Type: application/json');

$idCp = (int)($_GET['cp'] ?? 0);
if ($idCp <= 0) { echo json_encode(['ok' => false]); exit; }

$cp = mysqli_fetch_assoc(mysqli_query($conexion,
    "SELECT idFicha FROM checkpoint WHERE id = $idCp AND estado = 'Abierto' LIMIT 1"));

if (!$cp) { echo json_encode(['ok' => false, 'cerrado' => true]); exit; }

$total = (int)mysqli_fetch_assoc(mysqli_query($conexion,
    "SELECT COUNT(*) AS t FROM aprendiz WHERE idFicha = {$cp['idFicha']}"))['t'];

$reg = (int)mysqli_fetch_assoc(mysqli_query($conexion,
    "SELECT COUNT(*) AS t FROM asistencia WHERE idCheckpoint = $idCp"))['t'];

echo json_encode(['ok' => true, 'registrados' => $reg, 'total' => $total]);
exit;
