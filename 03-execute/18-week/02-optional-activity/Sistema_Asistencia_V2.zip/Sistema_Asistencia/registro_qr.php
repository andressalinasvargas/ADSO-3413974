<?php
// =============================================================
// registro_qr.php — Registro del aprendiz via QR
//
// Pasos:
//   1. Ingresar documento + código de verificación
//   2a. Si existe → registrar asistencia directamente
//   2b. Si no existe → pedir nombre + tipo_doc, crear aprendiz, registrar
//
// Una vez que el aprendiz valida el código se crea una sesion_qr
// temporal para que no se vea afectado por el cambio del código.
// La página NO se recarga automáticamente.
// =============================================================
require 'conexion.php';
require 'funciones.php';

$token = $_GET['token'] ?? '';

// --- Validar token y obtener checkpoint ---
$cp          = null;
$error_fatal = null;

if (!preg_match('/^[a-f0-9]{32}$/', $token)) {
    $error_fatal = 'El enlace no es válido.';
} else {
    $s = mysqli_prepare($conexion,
        "SELECT cp.*, f.numero AS ficha_num
         FROM checkpoint cp JOIN ficha f ON cp.idFicha = f.id
         WHERE cp.token_qr = ? AND cp.estado = 'Abierto' LIMIT 1");
    mysqli_stmt_bind_param($s, 's', $token);
    mysqli_stmt_execute($s);
    $cp = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
    mysqli_stmt_close($s);

    if (!$cp) {
        $error_fatal = 'Esta jornada ya fue cerrada o el enlace no es válido.';
    }
}

// --- Leer estado desde GET ---
$estado_ok   = $_GET['ok']     ?? '';       // 'ok' cuando se registró
$error_msg   = $_GET['err']    ?? '';       // código de error
$nombre_reg  = $_GET['nombre'] ?? '';       // nombre del aprendiz registrado

// Sesión QR activa (aprendiz ya validó código, va al paso 2)
$token_sesion = $_GET['sesion'] ?? '';
$sesion       = null;
if ($token_sesion !== '') {
    $sesion = validarSesionQR($conexion, $token_sesion);
    if (!$sesion) {
        $error_msg = 'sesion_expirada';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Asistencia — SENA</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Sobreescrituras solo para esta vista móvil */
        body { background: #fff; }
        .qr-mobile-box input,
        .qr-mobile-box select { font-size: 17px; padding: 12px; }
    </style>
</head>
<body>

<header>
    <h1>Registro de Asistencia</h1>
    <p>SENA<?php if ($cp): ?> — Ficha <?php echo htmlspecialchars($cp['ficha_num']); ?><?php endif; ?></p>
</header>

<main>

<?php if ($error_fatal): ?>
<!-- Error fatal: checkpoint cerrado o token inválido -->
<div class="qr-mobile-box">
    <div class="alerta alerta-error"><?php echo htmlspecialchars($error_fatal); ?></div>
</div>

<?php elseif ($estado_ok): ?>
<!-- ===== ÉXITO ===== -->
<div class="qr-mobile-box">
    <div class="alerta alerta-ok">
        <div class="nombre-grande"><?php echo htmlspecialchars($nombre_reg); ?></div>
        Tu asistencia fue registrada correctamente.
    </div>
    <p style="font-size:13px;color:#555;margin-top:12px;">
        <strong>Jornada:</strong> <?php echo labelCheckpoint($cp['tipo']); ?><br>
        <strong>Fecha:</strong> <?php echo date('d/m/Y', strtotime($cp['fecha'])); ?>
    </p>
</div>

<?php elseif ($error_msg): ?>
<!-- ===== ERROR ===== -->
<?php
$textos = [
    'codigo_invalido'  => 'El código de verificación es incorrecto o ya expiró.',
    'ya_registrado'    => 'Tu asistencia ya fue registrada en esta jornada.',
    'bloqueado'        => 'Demasiados intentos fallidos. Espera 5 minutos.',
    'campos'           => 'Completa todos los campos requeridos.',
    'sesion_expirada'  => 'Tu sesión expiró. Vuelve a ingresar tu documento y código.',
];
$msg_texto = $textos[$error_msg] ?? 'Ocurrió un error. Intenta de nuevo.';
?>
<div class="qr-mobile-box">
    <div class="alerta alerta-error"><?php echo $msg_texto; ?></div>
    <a href="registro_qr.php?token=<?php echo urlencode($token); ?>"
       class="btn btn-bloque" style="margin-top:12px;">Intentar de nuevo</a>
</div>

<?php elseif ($sesion): ?>
<!-- ===== PASO 2: aprendiz no existe, pedir nombre ===== -->
<div class="qr-mobile-box">
    <p style="font-size:13px;color:#555;margin-bottom:4px;">
        Documento <strong><?php echo htmlspecialchars($sesion['documento']); ?></strong>
        no está registrado. Ingresa tus datos para continuar.
    </p>

    <form action="api_codigo.php" method="POST">
        <input type="hidden" name="token"        value="<?php echo htmlspecialchars($token); ?>">
        <input type="hidden" name="token_sesion" value="<?php echo htmlspecialchars($token_sesion); ?>">
        <input type="hidden" name="paso"         value="registro">

        <label for="tipo_doc">Tipo de documento:</label>
        <select name="tipo_doc" id="tipo_doc" required>
            <option value="" disabled selected>-- Seleccionar --</option>
            <option value="CC">C.C. — Cédula de Ciudadanía</option>
            <option value="TI">T.I. — Tarjeta de Identidad</option>
            <option value="CE">C.E. — Cédula de Extranjería</option>
            <option value="PA">Pasaporte</option>
        </select>

        <label for="nombre">Nombre completo:</label>
        <input type="text" id="nombre" name="nombre"
               placeholder="Ej: JUAN DAVID TORRES"
               maxlength="100" required autofocus
               class="campo-mayus">

        <button type="submit" class="btn btn-bloque">Confirmar y registrar</button>
    </form>
    <p style="font-size:11px;color:#aaa;text-align:center;margin-top:10px;">
        Tus datos quedarán guardados para futuras sesiones.
    </p>
</div>

<?php else: ?>
<!-- ===== PASO 1: documento + código ===== -->
<?php
$codigo_vigente = codigoVigente($conexion, $cp['id']);
?>
<div class="qr-mobile-box">
    <p style="font-size:14px;margin-bottom:4px;">
        <strong>Jornada:</strong> <?php echo labelCheckpoint($cp['tipo']); ?>
    </p>
    <p style="font-size:14px;margin-bottom:18px;">
        <strong>Fecha:</strong> <?php echo date('d/m/Y', strtotime($cp['fecha'])); ?>
    </p>

    <?php if (!$codigo_vigente): ?>
    <div class="alerta alerta-warn">
        El código se está renovando. Espera unos segundos y recarga la página.
    </div>
    <?php else: ?>

    <form action="api_codigo.php" method="POST">
        <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
        <input type="hidden" name="paso"  value="inicial">

        <label for="documento">Número de documento:</label>
        <input type="text" id="documento" name="documento"
               placeholder="Ej: 1075324810"
               maxlength="20" required autofocus inputmode="numeric">

        <label for="codigo">Código de verificación:</label>
        <input type="text" id="codigo" name="codigo"
               placeholder="Código del tablero (6 caracteres)"
               maxlength="8" required autocomplete="off"
               class="campo-mayus">

        <button type="submit" class="btn btn-bloque">Registrar asistencia</button>
    </form>

    <p style="font-size:12px;color:#888;text-align:center;margin-top:14px;">
        ⚠ El código cambia cada 60 segundos.<br>
        Una vez enviado, el cambio no te afectará.
    </p>
    <?php endif; ?>
</div>
<?php endif; ?>

</main>

<footer>Sistema de Asistencia &mdash; SENA</footer>
<script src="script.js"></script>
<script>
// Solo activar mayúsculas aquí, sin contadores ni recargas
activarMayusculas();
</script>
</body>
</html>
