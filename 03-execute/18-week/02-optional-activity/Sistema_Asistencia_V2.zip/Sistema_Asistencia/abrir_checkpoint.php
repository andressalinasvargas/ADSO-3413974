<?php
// =============================================================
// abrir_checkpoint.php — Abre un nuevo checkpoint para una ficha
// =============================================================
require 'conexion.php';
require 'funciones.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }

$idFicha = (int)($_POST['idFicha'] ?? 0);
$tipo    = $_POST['tipo'] ?? '';
$tipos   = ['Inicio', 'Receso', 'Finalizacion'];

if ($idFicha <= 0 || !in_array($tipo, $tipos)) {
    header('Location: index.php');
    exit;
}

// Verificar que no haya otro checkpoint abierto (en cualquier ficha)
if (checkpointAbierto($conexion)) {
    header("Location: panel_ficha.php?id=$idFicha&err=ya_abierto");
    exit;
}

$hoy   = date('Y-m-d');
$hora  = date('H:i:s');
$token = generarTokenQR();

$s = mysqli_prepare($conexion,
    "INSERT INTO checkpoint (idFicha, tipo, fecha, hora_apertura, estado, token_qr)
     VALUES (?, ?, ?, ?, 'Abierto', ?)");
mysqli_stmt_bind_param($s, 'issss', $idFicha, $tipo, $hoy, $hora, $token);
mysqli_stmt_execute($s);
$idCp = (int)mysqli_insert_id($conexion);
mysqli_stmt_close($s);

// Generar primer código
rotarCodigo($conexion, $idCp);

header("Location: panel_ficha.php?id=$idFicha");
exit;
