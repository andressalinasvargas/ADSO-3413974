<?php
// =============================================================
// aprendices.php — CRUD de aprendices con:
// - Restricciones correctas en tipo de documento
// - Advertencia de nombre duplicado dentro de la misma ficha
// - Búsqueda por nombre o documento
// =============================================================
require 'conexion.php';
require 'funciones.php';

$idFicha = (int)($_GET['ficha'] ?? 0);
if ($idFicha <= 0) { header('Location: index.php'); exit; }

$s = mysqli_prepare($conexion, "SELECT * FROM ficha WHERE id = ? LIMIT 1");
mysqli_stmt_bind_param($s, 'i', $idFicha);
mysqli_stmt_execute($s);
$ficha = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
mysqli_stmt_close($s);
if (!$ficha) { header('Location: index.php'); exit; }

// Aprendiz a editar
$editando = null;
if (!empty($_GET['editar'])) {
    $idEd = (int)$_GET['editar'];
    $s    = mysqli_prepare($conexion,
        "SELECT * FROM aprendiz WHERE id = ? AND idFicha = ? LIMIT 1");
    mysqli_stmt_bind_param($s, 'ii', $idEd, $idFicha);
    mysqli_stmt_execute($s);
    $editando = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
    mysqli_stmt_close($s);
}

// Búsqueda
$busqueda = trim($_GET['q'] ?? '');
$params   = [$idFicha];
$where    = "idFicha = ?";
$types    = 'i';
if ($busqueda !== '') {
    $like    = '%' . $busqueda . '%';
    $where  .= " AND (nombre LIKE ? OR documento LIKE ?)";
    $types  .= 'ss';
    $params[] = $like;
    $params[] = $like;
}
$s = mysqli_prepare($conexion,
    "SELECT * FROM aprendiz WHERE $where ORDER BY nombre ASC");
mysqli_stmt_bind_param($s, $types, ...$params);
mysqli_stmt_execute($s);
$aprendices = mysqli_fetch_all(mysqli_stmt_get_result($s), MYSQLI_ASSOC);
mysqli_stmt_close($s);

// Verificación AJAX: nombre duplicado en la misma ficha
if (isset($_GET['check_nombre'])) {
    header('Content-Type: application/json');
    $nom     = strtoupper(trim($_GET['check_nombre']));
    $excluir = (int)($_GET['excluir'] ?? 0);
    $s = mysqli_prepare($conexion,
        "SELECT id, documento FROM aprendiz
         WHERE idFicha = ? AND nombre = ? AND id != ? LIMIT 1");
    mysqli_stmt_bind_param($s, 'isi', $idFicha, $nom, $excluir);
    mysqli_stmt_execute($s);
    $dup = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
    mysqli_stmt_close($s);
    echo json_encode(['duplicado' => (bool)$dup, 'documento' => $dup['documento'] ?? '']);
    exit;
}

$msgs_ok  = ['creado'=>'Aprendiz agregado.','editado'=>'Datos actualizados.','eliminado'=>'Aprendiz eliminado.'];
$msgs_err = [
    'duplicado'     => 'Ya existe un aprendiz con ese número de documento en el sistema.',
    'campos'        => 'Completa todos los campos obligatorios.',
    'tipo_doc'      => 'El tipo de documento seleccionado no es válido.',
    'doc_formato'   => 'El número de documento solo puede contener dígitos.',
    'no_encontrado' => 'Aprendiz no encontrado.',
];

// Tipos de documento válidos con descripción
$tipos_doc = [
    'CC' => 'C.C. — Cédula de Ciudadanía',
    'TI' => 'T.I. — Tarjeta de Identidad',
    'CE' => 'C.E. — Cédula de Extranjería',
    'PA' => 'Pasaporte',
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aprendices — Ficha <?php echo htmlspecialchars($ficha['numero']); ?></title>
    <link rel="stylesheet" href="style.css">
    <script src="script.js"></script>
</head>
<body>
<header>
    <h1>Sistema de Asistencia — SENA</h1>
    <p>Aprendices — Ficha <?php echo htmlspecialchars($ficha['numero']); ?></p>
</header>
<main>
    <h2>Gestionar aprendices</h2>

    <?php if (isset($_GET['ok']) && isset($msgs_ok[$_GET['ok']])): ?>
    <div class="alerta alerta-ok"><?php echo $msgs_ok[$_GET['ok']]; ?></div>
    <?php endif; ?>
    <?php if (isset($_GET['err']) && isset($msgs_err[$_GET['err']])): ?>
    <div class="alerta alerta-error"><?php echo $msgs_err[$_GET['err']]; ?></div>
    <?php endif; ?>

    <div class="info-box">
        <p><strong>Ficha:</strong> <?php echo htmlspecialchars($ficha['numero']); ?></p>
        <p><strong>Programa:</strong> <?php echo htmlspecialchars($ficha['programa']); ?></p>
    </div>

    <!-- Formulario crear / editar -->
    <div class="card card-verde" style="margin-bottom:22px;">
        <h3 style="margin-top:0;">
            <?php echo $editando ? 'Editar aprendiz' : 'Agregar aprendiz'; ?>
        </h3>
        <form action="aprendiz_accion.php" method="POST" id="form-aprendiz">
            <input type="hidden" name="idFicha"    value="<?php echo $idFicha; ?>">
            <input type="hidden" name="accion"
                   value="<?php echo $editando ? 'editar' : 'crear'; ?>">
            <?php if ($editando): ?>
            <input type="hidden" name="idAprendiz" value="<?php echo $editando['id']; ?>">
            <?php endif; ?>

            <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-start;">

                <!-- Tipo de documento -->
                <div>
                    <label style="display:block;font-size:13px;font-weight:bold;margin-bottom:4px;">
                        Tipo de documento *
                    </label>
                    <select name="tipo_doc" id="tipo_doc" required
                            style="font-size:14px;padding:8px 10px;"
                            onchange="actualizarValidacionDoc()">
                        <option value="" disabled <?php echo !$editando ? 'selected' : ''; ?>>
                            -- Seleccionar --
                        </option>
                        <?php
                        $tdActual = $editando['tipo_doc'] ?? '';
                        foreach ($tipos_doc as $val => $lbl): ?>
                        <option value="<?php echo $val; ?>"
                                <?php if ($tdActual === $val) echo 'selected'; ?>>
                            <?php echo $lbl; ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <div id="hint-tipo" style="font-size:11px;color:#777;margin-top:3px;"></div>
                </div>

                <!-- Número de documento -->
                <div>
                    <label style="display:block;font-size:13px;font-weight:bold;margin-bottom:4px;">
                        Número de documento *
                    </label>
                    <input type="text" name="documento" id="documento"
                           value="<?php echo htmlspecialchars($editando['documento'] ?? ''); ?>"
                           placeholder="Solo dígitos" maxlength="20" required
                           inputmode="numeric" pattern="[0-9]+"
                           title="Solo números, sin puntos ni espacios"
                           style="width:170px;"
                           <?php if ($editando) echo 'readonly style="width:170px;background:#f0f0f0;"'; ?>>
                    <div id="hint-doc" style="font-size:11px;color:#777;margin-top:3px;"></div>
                </div>

                <!-- Nombre completo -->
                <div style="flex:1;min-width:200px;">
                    <label style="display:block;font-size:13px;font-weight:bold;margin-bottom:4px;">
                        Nombre completo *
                    </label>
                    <input type="text" name="nombre" id="nombre" class="campo-mayus"
                           value="<?php echo htmlspecialchars($editando['nombre'] ?? ''); ?>"
                           placeholder="Ej: JUAN DAVID TORRES MEDINA"
                           maxlength="100" required style="width:100%;"
                           oninput="verificarNombreDuplicado(this.value)">
                    <!-- Advertencia de nombre duplicado (no bloquea) -->
                    <div id="aviso-nombre" style="display:none;margin-top:4px;font-size:12px;
                         color:#7a5500;background:#fff8e1;border:1px solid #e6a800;
                         border-radius:3px;padding:5px 8px;">
                    </div>
                </div>

                <div style="align-self:flex-end;">
                    <button type="submit" class="btn">
                        <?php echo $editando ? 'Guardar cambios' : 'Agregar'; ?>
                    </button>
                    <?php if ($editando): ?>
                    <a href="aprendices.php?ficha=<?php echo $idFicha; ?>"
                       class="btn btn-secondary">Cancelar</a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>

    <!-- Plan de contingencia (enlace rápido) -->
    <div style="margin-bottom:18px;font-size:13px;">
        <a href="contingencia.php?ficha=<?php echo $idFicha; ?>"
           style="color:#39A900;">
            ℹ Consultar plan de contingencia
        </a>
        (aprendices sin celular, discapacidad u otras situaciones especiales)
    </div>

    <!-- Buscador -->
    <form method="GET" action="aprendices.php" class="form-busqueda">
        <input type="hidden" name="ficha" value="<?php echo $idFicha; ?>">
        <label for="q">Buscar:</label>
        <input type="search" id="q" name="q"
               value="<?php echo htmlspecialchars($busqueda); ?>"
               placeholder="Nombre o documento..." style="width:220px;">
        <button type="submit" class="btn">Buscar</button>
        <?php if ($busqueda): ?>
        <a href="aprendices.php?ficha=<?php echo $idFicha; ?>"
           class="btn btn-secondary">Ver todos</a>
        <?php endif; ?>
    </form>

    <!-- Lista -->
    <h3>
        Aprendices
        <span style="font-weight:normal;font-size:13px;color:#666;">
            (<?php echo count($aprendices); ?>
            <?php echo $busqueda ? 'resultado(s)' : 'registrados'; ?>)
        </span>
    </h3>

    <?php if (empty($aprendices)): ?>
    <div class="alerta alerta-info">
        <?php echo $busqueda
            ? 'No se encontraron aprendices con ese criterio.'
            : 'No hay aprendices registrados. Agrega el primero usando el formulario de arriba.'; ?>
    </div>
    <?php else: ?>
    <table>
        <thead>
            <tr><th>#</th><th>Tipo</th><th>Documento</th><th>Nombre</th><th>Acciones</th></tr>
        </thead>
        <tbody>
        <?php $n=1; foreach ($aprendices as $ap): ?>
        <tr <?php if ($editando && $editando['id']==$ap['id']) echo 'style="background:#e8f5e0;"';?>>
            <td><?php echo $n++; ?></td>
            <td><?php echo labelTipoDoc($ap['tipo_doc']); ?></td>
            <td><?php echo htmlspecialchars($ap['documento']); ?></td>
            <td><?php echo htmlspecialchars($ap['nombre']); ?></td>
            <td>
                <a href="aprendices.php?ficha=<?php echo $idFicha;
                   ?>&editar=<?php echo $ap['id']; ?>"
                   class="btn btn-sm">Editar</a>
                <form action="aprendiz_accion.php" method="POST" style="display:inline;"
                      onsubmit="return confirmarEliminar('<?php echo htmlspecialchars(addslashes($ap['nombre'])); ?>')">
                    <input type="hidden" name="accion"     value="eliminar">
                    <input type="hidden" name="idAprendiz" value="<?php echo $ap['id']; ?>">
                    <input type="hidden" name="idFicha"    value="<?php echo $idFicha; ?>">
                    <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>

    <div style="margin-top:20px;">
        <a href="panel_ficha.php?id=<?php echo $idFicha; ?>" class="btn btn-secondary">
            ← Volver al panel
        </a>
    </div>
</main>
<footer>Sistema de Asistencia &mdash; SENA</footer>

<script>
// Reglas de validación por tipo de documento
var reglas = {
    'CC': { min: 6,  max: 10, patron: /^[0-9]+$/, hint: 'C.C.: 6 a 10 dígitos numéricos.' },
    'TI': { min: 10, max: 11, patron: /^[0-9]+$/, hint: 'T.I.: 10 u 11 dígitos numéricos.' },
    'CE': { min: 6,  max: 12, patron: /^[0-9]+$/, hint: 'C.E.: 6 a 12 dígitos numéricos.' },
    'PA': { min: 5,  max: 20, patron: /^[A-Z0-9]+$/, hint: 'Pasaporte: letras y números, sin espacios.' },
};

function actualizarValidacionDoc() {
    var tipo  = document.getElementById('tipo_doc').value;
    var input = document.getElementById('documento');
    var hint  = document.getElementById('hint-tipo');
    var hintD = document.getElementById('hint-doc');
    if (!tipo || !reglas[tipo]) { hint.textContent = ''; return; }
    var r = reglas[tipo];
    hint.textContent = r.hint;
    input.minLength  = r.min;
    input.maxLength  = r.max;
    input.pattern    = tipo === 'PA' ? '[A-Z0-9]+' : '[0-9]+';
    input.title      = r.hint;
    hintD.textContent = '';
}

// Validar documento al salir del campo
document.getElementById('documento')?.addEventListener('blur', function() {
    var tipo  = document.getElementById('tipo_doc').value;
    var val   = this.value.trim();
    var hintD = document.getElementById('hint-doc');
    if (!tipo || !reglas[tipo] || val === '') { hintD.textContent = ''; return; }
    var r = reglas[tipo];
    if (!r.patron.test(val)) {
        hintD.style.color = '#c0392b';
        hintD.textContent = '⚠ Formato incorrecto. ' + r.hint;
    } else if (val.length < r.min || val.length > r.max) {
        hintD.style.color = '#c0392b';
        hintD.textContent = '⚠ Longitud inválida. ' + r.hint;
    } else {
        hintD.style.color = '#1f6200';
        hintD.textContent = '✓ Formato correcto.';
    }
});

// Verificar nombre duplicado (AJAX silencioso, solo advertencia)
var timerNombre = null;
var idExcluir   = <?php echo $editando ? $editando['id'] : 0; ?>;
var idFicha     = <?php echo $idFicha; ?>;

function verificarNombreDuplicado(nombre) {
    clearTimeout(timerNombre);
    var aviso = document.getElementById('aviso-nombre');
    if (nombre.trim().length < 4) { aviso.style.display = 'none'; return; }
    timerNombre = setTimeout(function() {
        fetch('aprendices.php?ficha=' + idFicha +
              '&check_nombre=' + encodeURIComponent(nombre.trim().toUpperCase()) +
              '&excluir=' + idExcluir)
            .then(function(r) { return r.json(); })
            .then(function(d) {
                if (d.duplicado) {
                    aviso.style.display = 'block';
                    aviso.textContent   = '⚠ Ya existe un aprendiz con este nombre '
                        + '(documento: ' + d.documento + '). '
                        + 'Si son personas distintas, puede continuar.';
                } else {
                    aviso.style.display = 'none';
                }
            })
            .catch(function() { aviso.style.display = 'none'; });
    }, 600);
}

// Init
actualizarValidacionDoc();
</script>
</body>
</html>
