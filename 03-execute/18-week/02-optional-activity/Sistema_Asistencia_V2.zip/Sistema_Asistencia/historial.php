<?php
// =============================================================
// historial.php — Historial de asistencias de una ficha
// =============================================================
require 'conexion.php';
require 'funciones.php';

$idFicha = (int)($_GET['ficha'] ?? 0);
if ($idFicha <= 0) { header('Location: index.php'); exit; }

$s = mysqli_prepare($conexion, "SELECT * FROM ficha WHERE id = ? LIMIT 1");
mysqli_stmt_bind_param($s, 'i', $idFicha);
mysqli_stmt_execute($s);
$ficha = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
mysqli_stmt_close($s);
if (!$ficha) { header('Location: index.php'); exit; }

// Fecha seleccionada
$fecha_sel = $_GET['fecha'] ?? '';
$idCpSel   = (int)($_GET['cp'] ?? 0);

// Jornadas de esa fecha (o todas si no hay fecha)
$checkpoints = [];
if ($fecha_sel !== '') {
    $s = mysqli_prepare($conexion,
        "SELECT * FROM checkpoint WHERE idFicha = ? AND fecha = ? ORDER BY hora_apertura ASC");
    mysqli_stmt_bind_param($s, 'is', $idFicha, $fecha_sel);
    mysqli_stmt_execute($s);
    $checkpoints = mysqli_fetch_all(mysqli_stmt_get_result($s), MYSQLI_ASSOC);
    mysqli_stmt_close($s);

    if ($idCpSel === 0 && !empty($checkpoints)) {
        $idCpSel = (int)$checkpoints[0]['id'];
    }
}

// Registros del checkpoint seleccionado
$registros = [];
$cpActual  = null;
if ($idCpSel > 0) {
    foreach ($checkpoints as $cp) {
        if ($cp['id'] == $idCpSel) { $cpActual = $cp; break; }
    }
    if ($cpActual) {
        $sql = "SELECT ap.documento, ap.nombre, ap.tipo_doc,
                       a.id AS idAs, a.estado, a.hora, a.fuente, a.fue_editado
                FROM aprendiz ap
                LEFT JOIN asistencia a ON ap.id = a.idAprendiz AND a.idCheckpoint = ?
                WHERE ap.idFicha = ?
                ORDER BY ap.nombre ASC";
        $s = mysqli_prepare($conexion, $sql);
        mysqli_stmt_bind_param($s, 'ii', $idCpSel, $idFicha);
        mysqli_stmt_execute($s);
        $registros = mysqli_fetch_all(mysqli_stmt_get_result($s), MYSQLI_ASSOC);
        mysqli_stmt_close($s);
    }
}

// Fechas disponibles para el calendario (para mostrar en el input)
$fechas_dis = mysqli_fetch_all(mysqli_query($conexion,
    "SELECT DISTINCT fecha FROM checkpoint WHERE idFicha = $idFicha ORDER BY fecha DESC"
), MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial — Ficha <?php echo htmlspecialchars($ficha['numero']); ?></title>
    <link rel="stylesheet" href="style.css">
    <script src="script.js"></script>
</head>
<body>
<header>
    <h1>Sistema de Asistencia — SENA</h1>
    <p>Historial — Ficha <?php echo htmlspecialchars($ficha['numero']); ?></p>
</header>
<main>
    <h2>Historial de asistencias</h2>

    <?php if (isset($_GET['editado'])): ?>
    <div class="alerta alerta-ok">Estado actualizado.</div>
    <?php endif; ?>

    <div class="info-box">
        <p><strong>Ficha:</strong> <?php echo htmlspecialchars($ficha['numero']); ?></p>
        <p><strong>Programa:</strong> <?php echo htmlspecialchars($ficha['programa']); ?></p>
    </div>

    <!-- Buscador de fecha -->
    <form method="GET" action="historial.php" class="form-busqueda">
        <input type="hidden" name="ficha" value="<?php echo $idFicha; ?>">
        <label for="fecha">Buscar por fecha:</label>
        <input type="date" id="fecha" name="fecha"
               value="<?php echo htmlspecialchars($fecha_sel); ?>">
        <button type="submit" class="btn">Buscar</button>
        <?php if ($fecha_sel): ?>
        <a href="historial.php?ficha=<?php echo $idFicha; ?>"
           class="btn btn-secondary">Ver todas</a>
        <?php endif; ?>
    </form>

    <?php if ($fecha_sel === ''): ?>
    <!-- Lista de todas las jornadas -->
    <h3>Jornadas registradas</h3>
    <?php if (empty($fechas_dis)): ?>
    <div class="alerta alerta-info">No hay jornadas registradas para esta ficha.</div>
    <?php else: ?>
    <table>
        <thead>
            <tr><th>Fecha</th><th>Tipo</th><th>Apertura</th><th>Cierre</th><th>Estado</th><th></th></tr>
        </thead>
        <tbody>
        <?php
        // Mostrar todos los checkpoints de la ficha
        $todos = mysqli_fetch_all(mysqli_query($conexion,
            "SELECT * FROM checkpoint WHERE idFicha = $idFicha ORDER BY fecha DESC, hora_apertura DESC"
        ), MYSQLI_ASSOC);
        foreach ($todos as $cp):
        ?>
        <tr>
            <td><?php echo date('d/m/Y', strtotime($cp['fecha'])); ?></td>
            <td><?php echo labelCheckpoint($cp['tipo']); ?></td>
            <td><?php echo substr($cp['hora_apertura'],0,5); ?></td>
            <td><?php echo $cp['hora_cierre'] ? substr($cp['hora_cierre'],0,5) : '—'; ?></td>
            <td>
                <span class="badge <?php echo $cp['estado']==='Abierto' ? 'badge-abierto' : 'badge-cerrado'; ?>">
                    <?php echo $cp['estado']; ?>
                </span>
            </td>
            <td>
                <a href="historial.php?ficha=<?php echo $idFicha;
                   ?>&fecha=<?php echo $cp['fecha'];
                   ?>&cp=<?php echo $cp['id']; ?>"
                   class="btn btn-sm">Ver registros</a>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>

    <?php else: ?>
    <!-- Detalle de la fecha seleccionada -->
    <p style="font-size:14px;margin-bottom:12px;">
        Jornadas del <strong><?php echo date('d/m/Y', strtotime($fecha_sel)); ?></strong>:
    </p>

    <?php if (empty($checkpoints)): ?>
    <div class="alerta alerta-warn">No hay jornadas para esa fecha.</div>

    <?php else: ?>
    <!-- Selector de checkpoint -->
    <?php if (count($checkpoints) > 1): ?>
    <div style="margin-bottom:14px;">
        <?php foreach ($checkpoints as $cp): ?>
        <a href="historial.php?ficha=<?php echo $idFicha;
           ?>&fecha=<?php echo urlencode($fecha_sel);
           ?>&cp=<?php echo $cp['id']; ?>"
           class="btn <?php echo $cp['id']==$idCpSel ? '' : 'btn-secondary'; ?>"
           style="font-size:13px;padding:6px 14px;">
            <?php echo labelCheckpoint($cp['tipo']); ?>
        </a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if ($cpActual): ?>
    <div class="info-box">
        <p><strong>Jornada:</strong> <?php echo labelCheckpoint($cpActual['tipo']); ?></p>
        <p><strong>Apertura:</strong> <?php echo substr($cpActual['hora_apertura'],0,5); ?>
            <?php if ($cpActual['hora_cierre']): ?>
            — <strong>Cierre:</strong> <?php echo substr($cpActual['hora_cierre'],0,5); ?>
            <?php endif; ?>
        </p>
    </div>

    <table>
        <thead>
            <tr><th>#</th><th>Tipo</th><th>Documento</th><th>Nombre</th>
                <th>Estado</th><th>Hora</th><th>Fuente</th><th>Modificar</th></tr>
        </thead>
        <tbody>
        <?php $n=1; foreach ($registros as $r):
            $est   = $r['estado'] ?? 'Ausente';
            $clase = match($est) {
                'Asistio' => 'est-asistio', 'Tarde' => 'est-tarde',
                'Ausente' => 'est-ausente', default => ''
            };
        ?>
        <tr>
            <td><?php echo $n++; ?></td>
            <td><?php echo labelTipoDoc($r['tipo_doc']); ?></td>
            <td><?php echo htmlspecialchars($r['documento']); ?></td>
            <td>
                <?php echo htmlspecialchars($r['nombre']); ?>
                <?php if ($r['fue_editado']): ?><span class="badge badge-editado">Editado</span><?php endif; ?>
            </td>
            <td class="<?php echo $clase; ?>"><?php echo labelEstado($est); ?></td>
            <td><?php echo $r['hora'] ? substr($r['hora'],0,5) : '—'; ?></td>
            <td><?php echo $r['fuente']
                ? '<span class="badge '.($r['fuente']==='QR'?'badge-qr':'').'">'.$r['fuente'].'</span>'
                : '—'; ?></td>
            <td>
                <?php if ($r['idAs']): ?>
                <form action="editar.php" method="POST"
                      style="display:flex;gap:4px;align-items:center;">
                    <input type="hidden" name="idAsistencia"  value="<?php echo $r['idAs']; ?>">
                    <input type="hidden" name="fecha"         value="<?php echo htmlspecialchars($fecha_sel); ?>">
                    <input type="hidden" name="idCheckpoint"  value="<?php echo $idCpSel; ?>">
                    <select name="nuevo_estado">
                        <option value="Asistio" <?php if($est==='Asistio') echo 'selected';?>>Asistió</option>
                        <option value="Tarde"   <?php if($est==='Tarde')   echo 'selected';?>>Tarde</option>
                        <option value="Ausente" <?php if($est==='Ausente') echo 'selected';?>>Ausente</option>
                    </select>
                    <button type="submit" class="btn btn-sm">OK</button>
                </form>
                <?php else: ?><span style="color:#aaa;font-size:12px;">Sin registro</span><?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>

    <div style="margin-top:20px;">
        <a href="panel_ficha.php?id=<?php echo $idFicha; ?>" class="btn btn-secondary">
            ← Volver al panel
        </a>
    </div>
</main>
<footer>Sistema de Asistencia &mdash; SENA</footer>
</body>
</html>
