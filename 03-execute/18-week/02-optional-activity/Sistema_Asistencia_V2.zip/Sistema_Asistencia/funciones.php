<?php
// =============================================================
// funciones.php — Funciones compartidas del sistema
// =============================================================

// --- Generadores ---

function generarTokenQR(): string {
    return bin2hex(random_bytes(16)); // 32 hex
}

function generarCodigoAlfanumerico(): string {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // sin O,0,I,1 para evitar confusión
    $code  = '';
    for ($i = 0; $i < 6; $i++) {
        $code .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $code;
}

function generarTokenSesion(): string {
    return bin2hex(random_bytes(24)); // 48 hex
}

// --- IP del cliente ---

function obtenerIP(): string {
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
    }
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

// --- Checkpoint ---

// Obtiene el checkpoint abierto (solo puede haber uno a la vez)
function checkpointAbierto(mysqli $db): ?array {
    $res  = mysqli_query($db,
        "SELECT * FROM checkpoint WHERE estado = 'Abierto' ORDER BY id DESC LIMIT 1");
    return mysqli_fetch_assoc($res) ?: null;
}

// Obtiene el checkpoint abierto de una ficha específica
function checkpointAbiertoFicha(mysqli $db, int $idFicha): ?array {
    $s = mysqli_prepare($db,
        "SELECT * FROM checkpoint WHERE idFicha = ? AND estado = 'Abierto' LIMIT 1");
    mysqli_stmt_bind_param($s, 'i', $idFicha);
    mysqli_stmt_execute($s);
    $fila = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
    mysqli_stmt_close($s);
    return $fila ?: null;
}

// --- Código de verificación ---

// Rota (crea nuevo) código alfanumérico para un checkpoint (vigencia: 60 seg)
function rotarCodigo(mysqli $db, int $idCheckpoint): array {
    $codigo   = generarCodigoAlfanumerico();
    $generado = date('Y-m-d H:i:s');
    $expira   = date('Y-m-d H:i:s', time() + 60);

    $s = mysqli_prepare($db,
        "INSERT INTO codigo_verificacion (idCheckpoint, codigo, generado_en, expira_en)
         VALUES (?, ?, ?, ?)");
    mysqli_stmt_bind_param($s, 'isss', $idCheckpoint, $codigo, $generado, $expira);
    mysqli_stmt_execute($s);
    mysqli_stmt_close($s);

    return ['codigo' => $codigo, 'expira_en' => $expira, 'expira_ts' => strtotime($expira)];
}

// Obtiene el código vigente de un checkpoint (null si no hay)
function codigoVigente(mysqli $db, int $idCheckpoint): ?array {
    $ahora = date('Y-m-d H:i:s');
    $s     = mysqli_prepare($db,
        "SELECT codigo, expira_en FROM codigo_verificacion
         WHERE idCheckpoint = ? AND expira_en > ?
         ORDER BY id DESC LIMIT 1");
    mysqli_stmt_bind_param($s, 'is', $idCheckpoint, $ahora);
    mysqli_stmt_execute($s);
    $fila = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
    mysqli_stmt_close($s);
    return $fila ?: null;
}

// --- Sesión QR (evita recargas mientras el aprendiz escribe) ---

// Crea una sesión temporal para el aprendiz que ya validó código
function crearSesionQR(mysqli $db, int $idCheckpoint, string $documento): string {
    $token    = generarTokenSesion();
    $ip       = obtenerIP();
    $ahora    = date('Y-m-d H:i:s');
    $expira   = date('Y-m-d H:i:s', time() + 600); // 10 minutos

    $s = mysqli_prepare($db,
        "INSERT INTO sesion_qr (idCheckpoint, token_sesion, documento, ip, creada_en, expira_en)
         VALUES (?, ?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($s, 'isssss', $idCheckpoint, $token, $documento, $ip, $ahora, $expira);
    mysqli_stmt_execute($s);
    mysqli_stmt_close($s);

    return $token;
}

// Valida una sesión QR existente
function validarSesionQR(mysqli $db, string $tokenSesion): ?array {
    $ahora = date('Y-m-d H:i:s');
    $s     = mysqli_prepare($db,
        "SELECT sq.*, cp.idFicha, cp.tipo, cp.fecha, cp.hora_apertura, cp.estado AS cp_estado
         FROM sesion_qr sq
         JOIN checkpoint cp ON sq.idCheckpoint = cp.id
         WHERE sq.token_sesion = ? AND sq.expira_en > ?
         LIMIT 1");
    mysqli_stmt_bind_param($s, 'ss', $tokenSesion, $ahora);
    mysqli_stmt_execute($s);
    $fila = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
    mysqli_stmt_close($s);
    return $fila ?: null;
}

// Elimina una sesión QR usada
function eliminarSesionQR(mysqli $db, string $tokenSesion): void {
    $s = mysqli_prepare($db, "DELETE FROM sesion_qr WHERE token_sesion = ?");
    mysqli_stmt_bind_param($s, 's', $tokenSesion);
    mysqli_stmt_execute($s);
    mysqli_stmt_close($s);
}

// --- Intentos fallidos ---

function registrarIntentoFallido(mysqli $db, int $idCheckpoint, string $documento, string $error): void {
    $ip   = obtenerIP();
    $ahora = date('Y-m-d H:i:s');
    $s = mysqli_prepare($db,
        "INSERT INTO intento_fallido (idCheckpoint, documento, tipo_error, ip, fecha_hora)
         VALUES (?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($s, 'issss', $idCheckpoint, $documento, $error, $ip, $ahora);
    mysqli_stmt_execute($s);
    mysqli_stmt_close($s);
}

function intentosFallidos(mysqli $db, int $idCheckpoint, string $ip): int {
    $desde = date('Y-m-d H:i:s', time() - 300);
    $s     = mysqli_prepare($db,
        "SELECT COUNT(*) AS t FROM intento_fallido
         WHERE idCheckpoint = ? AND ip = ? AND fecha_hora >= ?");
    mysqli_stmt_bind_param($s, 'iss', $idCheckpoint, $ip, $desde);
    mysqli_stmt_execute($s);
    $fila = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
    mysqli_stmt_close($s);
    return (int)($fila['t'] ?? 0);
}

// --- Etiquetas ---

function labelCheckpoint(string $tipo): string {
    return match($tipo) {
        'Inicio'       => 'Inicio de jornada',
        'Receso'       => 'Regreso de receso',
        'Finalizacion' => 'Finalización de jornada',
        default        => $tipo,
    };
}

function labelEstado(string $estado): string {
    return match($estado) {
        'Asistio' => 'Asistió',
        'Tarde'   => 'Tarde',
        'Ausente' => 'Ausente',
        default   => $estado,
    };
}

function labelTipoDoc(string $tipo): string {
    return match($tipo) {
        'CC' => 'C.C.',
        'TI' => 'T.I.',
        'CE' => 'C.E.',
        'PA' => 'Pasaporte',
        default => $tipo,
    };
}

// --- Limpieza periódica de sesiones expiradas ---
function limpiarSesionesExpiradas(mysqli $db): void {
    $ahora = date('Y-m-d H:i:s');
    mysqli_query($db, "DELETE FROM sesion_qr WHERE expira_en < '$ahora'");
}
