<?php
// =============================================================
// contingencia.php — Plan de contingencia del sistema
// =============================================================
require 'conexion.php';
require 'funciones.php';

$idFicha = (int)($_GET['ficha'] ?? 0);
$ficha   = null;
if ($idFicha > 0) {
    $s = mysqli_prepare($conexion, "SELECT * FROM ficha WHERE id = ? LIMIT 1");
    mysqli_stmt_bind_param($s, 'i', $idFicha);
    mysqli_stmt_execute($s);
    $ficha = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
    mysqli_stmt_close($s);
}

$casos = [
    [
        'icono'  => '📵',
        'titulo' => 'Aprendiz sin dispositivo móvil',
        'desc'   => 'El aprendiz no dispone de teléfono celular para escanear el código QR.',
        'accion' => 'El instructor registra manualmente la asistencia desde la opción <strong>"Ver lista manual"</strong> del checkpoint activo. No se requiere intervención adicional del aprendiz.',
        'tipo'   => 'manual',
    ],
    [
        'icono'  => '👁',
        'titulo' => 'Aprendiz con discapacidad visual',
        'desc'   => 'El aprendiz presenta una discapacidad visual que dificulta el uso del formulario QR desde su dispositivo.',
        'accion' => 'El instructor brinda apoyo directo durante el registro, o realiza el registro manual desde el panel administrativo.',
        'tipo'   => 'manual',
    ],
    [
        'icono'  => '🦻',
        'titulo' => 'Aprendiz con discapacidad auditiva',
        'desc'   => 'El aprendiz presenta discapacidad auditiva.',
        'accion' => 'El sistema utiliza exclusivamente mensajes visuales. El flujo QR es completamente accesible para aprendices con discapacidad auditiva sin modificaciones. El instructor brinda apoyo adicional si el aprendiz lo solicita.',
        'tipo'   => 'ok',
    ],
    [
        'icono'  => '🖐',
        'titulo' => 'Aprendiz con discapacidad motriz',
        'desc'   => 'El aprendiz tiene dificultades para manipular el dispositivo móvil.',
        'accion' => 'El instructor realiza el registro manual desde el panel del checkpoint activo.',
        'tipo'   => 'manual',
    ],
    [
        'icono'  => '📷',
        'titulo' => 'Código QR no legible o no generado',
        'desc'   => 'El QR no se genera correctamente o el dispositivo del aprendiz no puede leerlo.',
        'accion' => 'Si el QR no se renderiza (sin internet), el instructor puede dictar la URL directamente. Si el problema persiste, cierra y reabre el checkpoint para generar un nuevo token QR. Como alternativa, usa el registro manual.',
        'tipo'   => 'manual',
    ],
    [
        'icono'  => '⏱',
        'titulo' => 'Código de verificación expirado antes de enviarlo',
        'desc'   => 'El código de 60 segundos cambió mientras el aprendiz estaba ingresando sus datos en el Paso 1.',
        'accion' => 'El sistema muestra el mensaje correspondiente. El aprendiz debe ingresar el nuevo código visible en el tablero del instructor y enviar el formulario nuevamente.',
        'tipo'   => 'automatico',
    ],
    [
        'icono'  => '🔐',
        'titulo' => 'Código expirado después de validar (Paso 2)',
        'desc'   => 'El código rotó mientras el aprendiz completaba el formulario de datos (Paso 2, aprendiz nuevo).',
        'accion' => 'El sistema crea automáticamente una sesión temporal de 10 minutos al validar el código en el Paso 1. Esta sesión protege al aprendiz de la rotación posterior. El aprendiz puede completar el formulario con tranquilidad.',
        'tipo'   => 'automatico',
    ],
    [
        'icono'  => '🌐',
        'titulo' => 'Sin conexión a Internet',
        'desc'   => 'No hay conexión a Internet durante la toma de asistencia.',
        'accion' => 'El sistema opera en red local (LAN) y no requiere Internet para funcionar. El único componente afectado es la imagen QR (generada por un servicio externo). En ese caso el QR no se renderiza como imagen, pero el registro manual sigue disponible sin interrupciones.',
        'tipo'   => 'manual',
    ],
    [
        'icono'  => '👤',
        'titulo' => 'Aprendiz no registrado en la ficha',
        'desc'   => 'El aprendiz escanea el QR pero su documento no existe en la base de datos.',
        'accion' => 'El sistema detecta automáticamente la situación y solicita nombre completo y tipo de documento (Paso 2). Al confirmar, crea el aprendiz en la ficha y registra su asistencia. No requiere intervención del instructor.',
        'tipo'   => 'automatico',
    ],
    [
        'icono'  => '🔁',
        'titulo' => 'Intento de registro duplicado',
        'desc'   => 'El aprendiz intenta registrar su asistencia por segunda vez en el mismo checkpoint.',
        'accion' => 'El sistema bloquea automáticamente el nuevo registro y muestra el mensaje "Tu asistencia ya fue registrada en esta jornada."',
        'tipo'   => 'automatico',
    ],
    [
        'icono'  => '🚫',
        'titulo' => 'Cinco intentos fallidos consecutivos',
        'desc'   => 'Un dispositivo realizó 5 intentos fallidos de validación en menos de 5 minutos.',
        'accion' => 'El sistema aplica un bloqueo de 5 minutos para ese dispositivo. Todos los intentos quedan registrados en auditoría. Si fue un error del aprendiz legítimo, el instructor puede registrar manualmente su asistencia.',
        'tipo'   => 'automatico',
    ],
];

$colores = [
    'manual'    => ['bg' => '#fff8e1', 'borde' => '#e6a800', 'etiq' => '#7a5500', 'label' => 'Registro manual'],
    'automatico'=> ['bg' => '#e8f0ff', 'borde' => '#3a6bc4', 'etiq' => '#1a3a7a', 'label' => 'Automático'],
    'ok'        => ['bg' => '#e8f5e0', 'borde' => '#39A900', 'etiq' => '#1f6200', 'label' => 'Sin impacto'],
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plan de Contingencia — SENA</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Sistema de Asistencia — SENA</h1>
    <p>Plan de contingencia</p>
</header>

<main>
    <h2>Plan de contingencia</h2>

    <div class="info-box">
        <p>Este plan establece las acciones a seguir cuando se presenten situaciones
        excepcionales que impidan el registro normal de asistencia. Garantiza que
        <strong>ningún aprendiz quede sin registrar</strong> por problemas técnicos,
        falta de dispositivos o condiciones particulares.</p>
        <?php if ($ficha): ?>
        <p style="margin-top:6px;"><strong>Ficha activa:</strong>
            <?php echo htmlspecialchars($ficha['numero']); ?> —
            <?php echo htmlspecialchars($ficha['programa']); ?>
        </p>
        <?php endif; ?>
    </div>

    <!-- Leyenda -->
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;font-size:13px;">
        <?php foreach ($colores as $c): ?>
        <span style="background:<?php echo $c['bg']; ?>;border:1px solid <?php echo $c['borde']; ?>;
              color:<?php echo $c['etiq']; ?>;border-radius:3px;padding:3px 10px;">
            <?php echo $c['label']; ?>
        </span>
        <?php endforeach; ?>
    </div>

    <!-- Casos -->
    <?php foreach ($casos as $i => $caso):
        $c = $colores[$caso['tipo']];
    ?>
    <div style="border:1px solid <?php echo $c['borde']; ?>;border-radius:6px;
                background:<?php echo $c['bg']; ?>;padding:14px 18px;margin-bottom:14px;">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
            <span style="font-size:22px;"><?php echo $caso['icono']; ?></span>
            <strong style="font-size:15px;">
                Caso <?php echo $i + 1; ?>. <?php echo htmlspecialchars($caso['titulo']); ?>
            </strong>
            <span style="margin-left:auto;font-size:11px;background:<?php echo $c['borde']; ?>;
                  color:#fff;border-radius:3px;padding:2px 8px;">
                <?php echo $c['label']; ?>
            </span>
        </div>
        <p style="font-size:13px;color:#555;margin-bottom:6px;">
            <strong>Situación:</strong> <?php echo htmlspecialchars($caso['desc']); ?>
        </p>
        <p style="font-size:14px;">
            <strong>Acción:</strong> <?php echo $caso['accion']; ?>
        </p>
    </div>
    <?php endforeach; ?>

    <!-- Responsables -->
    <h3 style="margin-top:28px;">Responsables</h3>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px;margin-top:10px;">

        <div class="card" style="border-left:4px solid #39A900;">
            <strong style="color:#39A900;">Instructor</strong>
            <ul style="margin-top:8px;padding-left:18px;font-size:13px;line-height:1.7;">
                <li>Iniciar la jornada abriendo el checkpoint.</li>
                <li>Registrar manualmente cuando el aprendiz no pueda hacerlo.</li>
                <li>Verificar que todos queden registrados antes de cerrar.</li>
                <li>Revisar la auditoría si hay inconsistencias.</li>
            </ul>
        </div>

        <div class="card" style="border-left:4px solid #3a6bc4;">
            <strong style="color:#3a6bc4;">Aprendiz</strong>
            <ul style="margin-top:8px;padding-left:18px;font-size:13px;line-height:1.7;">
                <li>Escanear el QR y validar con su documento y código.</li>
                <li>Informar oportunamente cualquier inconveniente.</li>
                <li>En caso de ser nuevo: ingresar sus datos en el Paso 2.</li>
            </ul>
        </div>

        <div class="card" style="border-left:4px solid #555;">
            <strong style="color:#555;">Sistema</strong>
            <ul style="margin-top:8px;padding-left:18px;font-size:13px;line-height:1.7;">
                <li>Generar QR y código alfanumérico rotativo.</li>
                <li>Crear automáticamente aprendices nuevos.</li>
                <li>Evitar registros duplicados.</li>
                <li>Registrar intentos fallidos y modificaciones.</li>
                <li>Mostrar mensajes claros ante cualquier error.</li>
            </ul>
        </div>
    </div>

    <div style="margin-top:24px;">
        <?php if ($ficha): ?>
        <a href="aprendices.php?ficha=<?php echo $idFicha; ?>"
           class="btn btn-secondary">← Volver a aprendices</a>
        <a href="panel_ficha.php?id=<?php echo $idFicha; ?>"
           class="btn btn-secondary">Panel de ficha</a>
        <?php else: ?>
        <a href="index.php" class="btn btn-secondary">← Volver al inicio</a>
        <?php endif; ?>
    </div>
</main>

<footer>Sistema de Asistencia &mdash; SENA</footer>
</body>
</html>
