<?php
// =============================================================
// conexion.php — Conexión a MySQL
// =============================================================

// Zona horaria Colombia (UTC-5, sin cambio de horario de verano)
date_default_timezone_set('America/Bogota');

$host    = 'localhost';
$usuario = 'root';   // Cambiar según tu entorno
$clave   = '';       // Cambiar según tu entorno
$base    = 'asistencia_sena';

$conexion = mysqli_connect($host, $usuario, $clave, $base);

if (!$conexion) {
    http_response_code(500);
    die('<p style="font-family:Arial;color:red;padding:20px;">
        Error de conexión: ' . mysqli_connect_error() . '
    </p>');
}

mysqli_set_charset($conexion, 'utf8mb4');

// Sincronizar zona horaria de MySQL con PHP
mysqli_query($conexion, "SET time_zone = '-05:00'");
