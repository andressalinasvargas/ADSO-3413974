<?php
// =============================================================
// guardar.php — Guarda registro manual con auditoría
// =============================================================
require 'conexion.php';
require 'funciones.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }

$idCp      = (int)($_POST['idCheckpoint'] ?? 0);
$idFicha   = (int)($_POST['idFicha']      ?? 0);
$aprendices = $_POST['aprendices'] ?? [];
$estados_ok = ['Asistio','Tarde','Ausente'];

if ($idCp <= 0 || empty($aprendices)) {
    header("Location: tomar_asistencia.php?cp=$idCp&err=1"); exit;
}

// Verificar checkpoint abierto
$s = mysqli_prepare($conexion, "SELECT fecha FROM checkpoint WHERE id = ? AND estado = 'Abierto' LIMIT 1");
mysqli_stmt_bind_param($s, 'i', $idCp);
mysqli_stmt_execute($s);
$cp = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
mysqli_stmt_close($s);
if (!$cp) { header("Location: tomar_asistencia.php?cp=$idCp&err=1"); exit; }

$fecha = $cp['fecha'];
$hora  = date('H:i:s');
$ip    = obtenerIP();
$error = false;

foreach ($aprendices as $idAp) {
    $idAp   = (int)$idAp;
    $estado = $_POST['estado_'.$idAp] ?? 'Ausente';
    if (!in_array($estado, $estados_ok)) $estado = 'Ausente';

    // ¿Ya existe?
    $s = mysqli_prepare($conexion,
        "SELECT id, estado FROM asistencia WHERE idAprendiz = ? AND idCheckpoint = ? LIMIT 1");
    mysqli_stmt_bind_param($s, 'ii', $idAp, $idCp);
    mysqli_stmt_execute($s);
    $exist = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
    mysqli_stmt_close($s);

    if ($exist) {
        if ($exist['estado'] !== $estado) {
            $upd = mysqli_prepare($conexion,
                "UPDATE asistencia SET estado=?, hora=?, fuente='Manual', fue_editado=1, ip=?
                 WHERE id=?");
            mysqli_stmt_bind_param($upd, 'sssi', $estado, $hora, $ip, $exist['id']);
            if (!mysqli_stmt_execute($upd)) $error = true;
            mysqli_stmt_close($upd);

            // Auditoría
            $fh  = date('Y-m-d H:i:s');
            $aud = mysqli_prepare($conexion,
                "INSERT INTO auditoria_modificacion (idAsistencia,estado_anterior,estado_nuevo,fecha_hora)
                 VALUES (?,?,?,?)");
            mysqli_stmt_bind_param($aud, 'isss', $exist['id'], $exist['estado'], $estado, $fh);
            mysqli_stmt_execute($aud);
            mysqli_stmt_close($aud);
        }
    } else {
        $ins = mysqli_prepare($conexion,
            "INSERT INTO asistencia (idAprendiz,idCheckpoint,fecha,hora,estado,fuente,ip)
             VALUES (?,?,?,?,?,'Manual',?)");
        mysqli_stmt_bind_param($ins, 'iissss', $idAp, $idCp, $fecha, $hora, $estado, $ip);
        if (!mysqli_stmt_execute($ins)) $error = true;
        mysqli_stmt_close($ins);
    }
}

header("Location: tomar_asistencia.php?cp=$idCp" . ($error ? '&err=1' : '&ok=1'));
exit;
