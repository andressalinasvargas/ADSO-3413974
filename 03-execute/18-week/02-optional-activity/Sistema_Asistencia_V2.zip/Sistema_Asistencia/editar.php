<?php
// =============================================================
// editar.php — Modifica estado de asistencia con auditoría
// =============================================================
require 'conexion.php';
require 'funciones.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }

$idAs       = (int)($_POST['idAsistencia'] ?? 0);
$nuevoEst   = $_POST['nuevo_estado']        ?? '';
$fecha      = $_POST['fecha']               ?? date('Y-m-d');
$idCp       = (int)($_POST['idCheckpoint'] ?? 0);
$estados_ok = ['Asistio','Tarde','Ausente'];

if ($idAs <= 0 || !in_array($nuevoEst, $estados_ok)) {
    header('Location: historial.php'); exit;
}

$s = mysqli_prepare($conexion, "SELECT estado FROM asistencia WHERE id = ? LIMIT 1");
mysqli_stmt_bind_param($s, 'i', $idAs);
mysqli_stmt_execute($s);
$actual = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
mysqli_stmt_close($s);

if (!$actual) { header('Location: historial.php'); exit; }

if ($actual['estado'] !== $nuevoEst) {
    $hora = date('H:i:s');
    $upd  = mysqli_prepare($conexion,
        "UPDATE asistencia SET estado=?, hora=?, fuente='Manual', fue_editado=1 WHERE id=?");
    mysqli_stmt_bind_param($upd, 'ssi', $nuevoEst, $hora, $idAs);
    mysqli_stmt_execute($upd);
    mysqli_stmt_close($upd);

    $fh  = date('Y-m-d H:i:s');
    $aud = mysqli_prepare($conexion,
        "INSERT INTO auditoria_modificacion (idAsistencia,estado_anterior,estado_nuevo,fecha_hora)
         VALUES (?,?,?,?)");
    mysqli_stmt_bind_param($aud, 'isss', $idAs, $actual['estado'], $nuevoEst, $fh);
    mysqli_stmt_execute($aud);
    mysqli_stmt_close($aud);
}

header("Location: historial.php?fecha=" . urlencode($fecha)
    . "&cp=$idCp&editado=1");
exit;
