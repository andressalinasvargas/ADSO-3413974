<?php
// =============================================================
// aprendices.php — Gestión de aprendices (CRUD + búsqueda)
// =============================================================
require 'conexion.php';
require 'funciones.php';

$idFicha = (int)($_GET['ficha'] ?? 0);
if ($idFicha <= 0) { header('Location: index.php'); exit; }

$s = mysqli_prepare($conexion, "SELECT * FROM ficha WHERE id = ? LIMIT 1");
mysqli_stmt_bind_param($s, 'i', $idFicha);
mysqli_stmt_execute($s);
$ficha = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
mysqli_stmt_close($s);
if (!$ficha) { header('Location: index.php'); exit; }

// Aprendiz a editar
$editando = null;
if (!empty($_GET['editar'])) {
    $idEd = (int)$_GET['editar'];
    $s    = mysqli_prepare($conexion,
        "SELECT * FROM aprendiz WHERE id = ? AND idFicha = ? LIMIT 1");
    mysqli_stmt_bind_param($s, 'ii', $idEd, $idFicha);
    mysqli_stmt_execute($s);
    $editando = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
    mysqli_stmt_close($s);
}

// Búsqueda
$busqueda = trim($_GET['q'] ?? '');

$params = [$idFicha];
$where  = "idFicha = ?";
$types  = 'i';

if ($busqueda !== '') {
    $like    = '%' . $busqueda . '%';
    $where  .= " AND (nombre LIKE ? OR documento LIKE ?)";
    $types  .= 'ss';
    $params[] = $like;
    $params[] = $like;
}

$s = mysqli_prepare($conexion,
    "SELECT * FROM aprendiz WHERE $where ORDER BY nombre ASC");
mysqli_stmt_bind_param($s, $types, ...$params);
mysqli_stmt_execute($s);
$aprendices = mysqli_fetch_all(mysqli_stmt_get_result($s), MYSQLI_ASSOC);
mysqli_stmt_close($s);

$msgs_ok  = ['creado'=>'Aprendiz agregado.','editado'=>'Datos actualizados.','eliminado'=>'Aprendiz eliminado.'];
$msgs_err = ['duplicado'=>'Ya existe un aprendiz con ese documento.',
             'campos'=>'Completa todos los campos.',
             'no_encontrado'=>'Aprendiz no encontrado.'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aprendices — Ficha <?php echo htmlspecialchars($ficha['numero']); ?></title>
    <link rel="stylesheet" href="style.css">
    <script src="script.js"></script>
</head>
<body>
<header>
    <h1>Sistema de Asistencia — SENA</h1>
    <p>Aprendices — Ficha <?php echo htmlspecialchars($ficha['numero']); ?></p>
</header>
<main>
    <h2>Gestionar aprendices</h2>

    <?php if (isset($_GET['ok']) && isset($msgs_ok[$_GET['ok']])): ?>
    <div class="alerta alerta-ok"><?php echo $msgs_ok[$_GET['ok']]; ?></div>
    <?php endif; ?>
    <?php if (isset($_GET['err']) && isset($msgs_err[$_GET['err']])): ?>
    <div class="alerta alerta-error"><?php echo $msgs_err[$_GET['err']]; ?></div>
    <?php endif; ?>

    <div class="info-box">
        <p><strong>Ficha:</strong> <?php echo htmlspecialchars($ficha['numero']); ?></p>
        <p><strong>Programa:</strong> <?php echo htmlspecialchars($ficha['programa']); ?></p>
    </div>

    <!-- Formulario crear / editar -->
    <div class="card card-verde" style="margin-bottom:22px;">
        <h3 style="margin-top:0;">
            <?php echo $editando ? 'Editar aprendiz' : 'Agregar aprendiz'; ?>
        </h3>
        <form action="aprendiz_accion.php" method="POST">
            <input type="hidden" name="idFicha"    value="<?php echo $idFicha; ?>">
            <input type="hidden" name="accion"
                   value="<?php echo $editando ? 'editar' : 'crear'; ?>">
            <?php if ($editando): ?>
            <input type="hidden" name="idAprendiz" value="<?php echo $editando['id']; ?>">
            <?php endif; ?>

            <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
                <div>
                    <label style="display:block;font-size:13px;font-weight:bold;margin-bottom:4px;">
                        Tipo *
                    </label>
                    <select name="tipo_doc" style="font-size:14px;padding:8px 10px;">
                        <?php $td = $editando['tipo_doc'] ?? 'CC';
                        foreach(['CC'=>'C.C.','TI'=>'T.I.','CE'=>'C.E.','PA'=>'Pasaporte'] as $v=>$l): ?>
                        <option value="<?php echo $v; ?>" <?php if($td===$v) echo 'selected';?>>
                            <?php echo $l; ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label style="display:block;font-size:13px;font-weight:bold;margin-bottom:4px;">
                        Documento *
                    </label>
                    <input type="text" name="documento"
                           value="<?php echo htmlspecialchars($editando['documento'] ?? ''); ?>"
                           placeholder="Ej: 1075324810" maxlength="20" required
                           style="width:170px;"
                           <?php if ($editando) echo 'readonly style="width:170px;background:#f0f0f0;"'; ?>>
                </div>
                <div style="flex:1;min-width:200px;">
                    <label style="display:block;font-size:13px;font-weight:bold;margin-bottom:4px;">
                        Nombre completo *
                    </label>
                    <input type="text" name="nombre" class="campo-mayus"
                           value="<?php echo htmlspecialchars($editando['nombre'] ?? ''); ?>"
                           placeholder="Ej: JUAN DAVID TORRES MEDINA"
                           maxlength="100" required style="width:100%;">
                </div>
                <div>
                    <button type="submit" class="btn">
                        <?php echo $editando ? 'Guardar cambios' : 'Agregar'; ?>
                    </button>
                    <?php if ($editando): ?>
                    <a href="aprendices.php?ficha=<?php echo $idFicha; ?>"
                       class="btn btn-secondary">Cancelar</a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>

    <!-- Buscador -->
    <form method="GET" action="aprendices.php" class="form-busqueda">
        <input type="hidden" name="ficha" value="<?php echo $idFicha; ?>">
        <label for="q">Buscar:</label>
        <input type="search" id="q" name="q"
               value="<?php echo htmlspecialchars($busqueda); ?>"
               placeholder="Nombre o documento..." style="width:220px;">
        <button type="submit" class="btn">Buscar</button>
        <?php if ($busqueda): ?>
        <a href="aprendices.php?ficha=<?php echo $idFicha; ?>"
           class="btn btn-secondary">Ver todos</a>
        <?php endif; ?>
    </form>

    <!-- Lista -->
    <h3>
        Aprendices
        <span style="font-weight:normal;font-size:13px;color:#666;">
            (<?php echo count($aprendices); ?>
            <?php echo $busqueda ? 'resultado(s)' : 'registrados'; ?>)
        </span>
    </h3>

    <?php if (empty($aprendices)): ?>
    <div class="alerta alerta-info">
        <?php echo $busqueda
            ? 'No se encontraron aprendices con ese criterio.'
            : 'No hay aprendices registrados. Agrega el primero usando el formulario de arriba.'; ?>
    </div>
    <?php else: ?>
    <table>
        <thead>
            <tr><th>#</th><th>Tipo</th><th>Documento</th><th>Nombre</th><th>Acciones</th></tr>
        </thead>
        <tbody>
        <?php $n=1; foreach ($aprendices as $ap): ?>
        <tr <?php if ($editando && $editando['id']==$ap['id']) echo 'style="background:#e8f5e0;"';?>>
            <td><?php echo $n++; ?></td>
            <td><?php echo labelTipoDoc($ap['tipo_doc']); ?></td>
            <td><?php echo htmlspecialchars($ap['documento']); ?></td>
            <td><?php echo htmlspecialchars($ap['nombre']); ?></td>
            <td>
                <a href="aprendices.php?ficha=<?php echo $idFicha;
                   ?>&editar=<?php echo $ap['id']; ?>"
                   class="btn btn-sm">Editar</a>

                <form action="aprendiz_accion.php" method="POST" style="display:inline;"
                      onsubmit="return confirmarEliminar('<?php echo htmlspecialchars(addslashes($ap['nombre'])); ?>')">
                    <input type="hidden" name="accion"     value="eliminar">
                    <input type="hidden" name="idAprendiz" value="<?php echo $ap['id']; ?>">
                    <input type="hidden" name="idFicha"    value="<?php echo $idFicha; ?>">
                    <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>

    <div style="margin-top:20px;">
        <a href="panel_ficha.php?id=<?php echo $idFicha; ?>" class="btn btn-secondary">
            ← Volver al panel
        </a>
    </div>
</main>
<footer>Sistema de Asistencia &mdash; SENA</footer>
</body>
</html>
