<?php
// =============================================================
// cerrar_checkpoint.php — Cierra una jornada, marca ausentes
// =============================================================
require 'conexion.php';
require 'funciones.php';

$idCp    = (int)($_GET['id']    ?? 0);
$idFicha = (int)($_GET['ficha'] ?? 0);

if ($idCp <= 0) { header('Location: index.php'); exit; }

$s = mysqli_prepare($conexion,
    "SELECT * FROM checkpoint WHERE id = ? AND estado = 'Abierto' LIMIT 1");
mysqli_stmt_bind_param($s, 'i', $idCp);
mysqli_stmt_execute($s);
$cp = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
mysqli_stmt_close($s);

if (!$cp) { header("Location: panel_ficha.php?id=$idFicha"); exit; }

$hora  = date('H:i:s');
$fecha = $cp['fecha'];
$ip    = obtenerIP();
$fid   = $idFicha ?: $cp['idFicha'];

// Marcar Ausente a quienes no registraron
$aps = mysqli_query($conexion,
    "SELECT id FROM aprendiz WHERE idFicha = {$cp['idFicha']}");
while ($ap = mysqli_fetch_assoc($aps)) {
    $idAp = (int)$ap['id'];
    $chk  = mysqli_prepare($conexion,
        "SELECT id FROM asistencia WHERE idAprendiz = ? AND idCheckpoint = ? LIMIT 1");
    mysqli_stmt_bind_param($chk, 'ii', $idAp, $idCp);
    mysqli_stmt_execute($chk);
    mysqli_stmt_store_result($chk);
    if (mysqli_stmt_num_rows($chk) === 0) {
        $ins = mysqli_prepare($conexion,
            "INSERT INTO asistencia (idAprendiz, idCheckpoint, fecha, hora, estado, fuente, ip)
             VALUES (?, ?, ?, ?, 'Ausente', 'Manual', ?)");
        mysqli_stmt_bind_param($ins, 'iisss', $idAp, $idCp, $fecha, $hora, $ip);
        mysqli_stmt_execute($ins);
        mysqli_stmt_close($ins);
    }
    mysqli_stmt_close($chk);
}

// Cerrar checkpoint
$upd = mysqli_prepare($conexion,
    "UPDATE checkpoint SET estado = 'Cerrado', hora_cierre = ? WHERE id = ?");
mysqli_stmt_bind_param($upd, 'si', $hora, $idCp);
mysqli_stmt_execute($upd);
mysqli_stmt_close($upd);

header("Location: panel_ficha.php?id=$fid&cerrado=1");
exit;
