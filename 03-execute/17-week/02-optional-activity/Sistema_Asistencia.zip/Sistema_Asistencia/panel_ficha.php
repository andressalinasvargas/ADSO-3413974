<?php
// =============================================================
// panel_ficha.php — Panel de una ficha específica
// =============================================================
require 'conexion.php';
require 'funciones.php';

$idFicha = (int)($_GET['id'] ?? 0);
if ($idFicha <= 0) { header('Location: index.php'); exit; }

// Obtener datos de la ficha
$s = mysqli_prepare($conexion, "SELECT * FROM ficha WHERE id = ? LIMIT 1");
mysqli_stmt_bind_param($s, 'i', $idFicha);
mysqli_stmt_execute($s);
$ficha = mysqli_fetch_assoc(mysqli_stmt_get_result($s));
mysqli_stmt_close($s);

if (!$ficha) { header('Location: index.php'); exit; }

// Checkpoint activo de esta ficha
$cp = checkpointAbiertoFicha($conexion, $idFicha);

// Código vigente
$codigo = null;
if ($cp) {
    $codigo = codigoVigente($conexion, $cp['id']);
    if (!$codigo) {
        $codigo = rotarCodigo($conexion, $cp['id']);
    }
}

// Progreso de registrados
$total_ap   = 0;
$registrados = 0;
if ($cp) {
    $r = mysqli_fetch_assoc(mysqli_query($conexion,
        "SELECT COUNT(*) AS t FROM aprendiz WHERE idFicha = $idFicha"));
    $total_ap = (int)$r['t'];

    $r = mysqli_fetch_assoc(mysqli_query($conexion,
        "SELECT COUNT(*) AS t FROM asistencia WHERE idCheckpoint = {$cp['id']}"));
    $registrados = (int)$r['t'];
}

// URL base para el QR
$base_url    = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
             . '://' . $_SERVER['HTTP_HOST']
             . dirname($_SERVER['PHP_SELF']) . '/';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ficha <?php echo htmlspecialchars($ficha['numero']); ?> — SENA</title>
    <link rel="stylesheet" href="style.css">
    <script src="script.js"></script>
</head>
<body>

<header>
    <h1>Sistema de Asistencia — SENA</h1>
    <p>Ficha <?php echo htmlspecialchars($ficha['numero']); ?></p>
</header>

<main>

    <?php if (isset($_GET['cerrado'])): ?>
    <div class="alerta alerta-ok">Jornada cerrada. Aprendices sin registro marcados como Ausente.</div>
    <?php endif; ?>

    <!-- Info de la ficha -->
    <div class="info-box">
        <p><strong>Ficha:</strong> <?php echo htmlspecialchars($ficha['numero']); ?></p>
        <p><strong>Programa:</strong> <?php echo htmlspecialchars($ficha['programa']); ?></p>
        <p><strong>Fecha:</strong> <?php echo date('d/m/Y'); ?></p>
        <p><strong>Hora:</strong> <span id="reloj"><?php echo date('H:i:s'); ?></span></p>
    </div>

    <?php if ($cp): ?>
    <!-- ===== JORNADA ACTIVA ===== -->
    <h2>Jornada activa — <?php echo labelCheckpoint($cp['tipo']); ?></h2>

    <div class="panel-qr">
        <!-- QR -->
        <div class="qr-imagen">
            <img src="qr.php?token=<?php echo urlencode($cp['token_qr']); ?>"
                 alt="Código QR" width="190" height="190">
            <p style="font-size:11px;color:#777;margin-top:6px;">Escanear para registrar</p>
        </div>

        <!-- Código + progreso -->
        <div style="flex:1;min-width:220px;">
            <p style="font-size:13px;font-weight:bold;margin-bottom:4px;">
                Código de verificación:
            </p>
            <div class="codigo-alpha" id="codigo-display">
                <?php echo $codigo['codigo']; ?>
            </div>
            <div class="contador-wrap">
                Cambia en
                <span id="contador-seg"
                      data-expira="<?php echo strtotime($codigo['expira_en']); ?>"
                      data-cp="<?php echo $cp['id']; ?>">
                    ...
                </span> segundos
            </div>

            <hr>

            <!-- Progreso -->
            <p class="progreso-texto">
                Registrados:
                <strong id="registrados-count" data-cp="<?php echo $cp['id']; ?>">
                    <?php echo $registrados; ?>
                </strong>
                de
                <span id="registrados-total"><?php echo $total_ap; ?></span>
                aprendices
            </p>
            <div class="progreso-bar-wrap">
                <div class="progreso-bar" id="progreso-bar"
                     style="width:<?php echo $total_ap > 0
                        ? round(($registrados/$total_ap)*100) : 0; ?>%">
                </div>
            </div>

            <!-- Acciones del checkpoint -->
            <a href="tomar_asistencia.php?cp=<?php echo $cp['id']; ?>"
               class="btn">Ver lista manual</a>
            <a href="cerrar_checkpoint.php?id=<?php echo $cp['id']; ?>&ficha=<?php echo $idFicha; ?>"
               class="btn btn-danger"
               onclick="return confirmarCierre()">Cerrar jornada</a>
        </div>
    </div>

    <?php else: ?>
    <!-- ===== SIN JORNADA ACTIVA ===== -->
    <h2>Acciones</h2>
    <div class="acciones-grid">
        <form action="abrir_checkpoint.php" method="POST">
            <input type="hidden" name="idFicha" value="<?php echo $idFicha; ?>">
            <input type="hidden" name="tipo"    value="Inicio">
            <button type="submit" class="btn btn-bloque">▶ Iniciar asistencia de jornada</button>
        </form>

        <form action="abrir_checkpoint.php" method="POST">
            <input type="hidden" name="idFicha" value="<?php echo $idFicha; ?>">
            <input type="hidden" name="tipo"    value="Receso">
            <button type="submit" class="btn btn-bloque btn-secondary">↩ Registrar regreso de receso</button>
        </form>

        <form action="abrir_checkpoint.php" method="POST">
            <input type="hidden" name="idFicha" value="<?php echo $idFicha; ?>">
            <input type="hidden" name="tipo"    value="Finalizacion">
            <button type="submit" class="btn btn-bloque btn-secondary">■ Finalizar jornada</button>
        </form>
    </div>
    <?php endif; ?>

    <hr>

    <!-- Navegación adicional -->
    <div>
        <a href="historial.php?ficha=<?php echo $idFicha; ?>" class="btn btn-outline">
            Historial de asistencias
        </a>
        <a href="aprendices.php?ficha=<?php echo $idFicha; ?>" class="btn btn-outline">
            Gestionar aprendices
        </a>
        <a href="index.php" class="btn btn-secondary">← Volver al inicio</a>
    </div>

</main>

<footer>Sistema de Asistencia &mdash; SENA</footer>

<script>
// Reloj en tiempo real
setInterval(function() {
    var d = new Date();
    var h = String(d.getHours()).padStart(2,'0');
    var m = String(d.getMinutes()).padStart(2,'0');
    var s = String(d.getSeconds()).padStart(2,'0');
    var el = document.getElementById('reloj');
    if (el) el.textContent = h + ':' + m + ':' + s;
}, 1000);
</script>
</body>
</html>
