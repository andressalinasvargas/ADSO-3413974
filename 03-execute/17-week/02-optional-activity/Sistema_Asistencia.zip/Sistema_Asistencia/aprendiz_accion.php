<?php
// =============================================================
// aprendiz_accion.php — Procesa CRUD de aprendices
// =============================================================
require 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php'); exit;
}

$accion     = $_POST['accion']     ?? '';
$idFicha    = (int)($_POST['idFicha']    ?? 0);
$idAprendiz = (int)($_POST['idAprendiz'] ?? 0);
$volver     = "aprendices.php?ficha=$idFicha";
$tipos_ok   = ['CC','TI','CE','PA'];

// --- CREAR ---
if ($accion === 'crear') {
    $documento = trim($_POST['documento'] ?? '');
    $nombre    = strtoupper(trim($_POST['nombre']   ?? ''));
    $tipo_doc  = $_POST['tipo_doc'] ?? 'CC';
    if (!in_array($tipo_doc, $tipos_ok)) $tipo_doc = 'CC';

    if ($documento === '' || $nombre === '' || $idFicha <= 0) {
        header("Location: $volver&err=campos"); exit;
    }

    $s = mysqli_prepare($conexion, "SELECT id FROM aprendiz WHERE documento = ? LIMIT 1");
    mysqli_stmt_bind_param($s, 's', $documento);
    mysqli_stmt_execute($s);
    mysqli_stmt_store_result($s);
    if (mysqli_stmt_num_rows($s) > 0) {
        mysqli_stmt_close($s);
        header("Location: $volver&err=duplicado"); exit;
    }
    mysqli_stmt_close($s);

    $ins = mysqli_prepare($conexion,
        "INSERT INTO aprendiz (idFicha, tipo_doc, documento, nombre) VALUES (?, ?, ?, ?)");
    mysqli_stmt_bind_param($ins, 'isss', $idFicha, $tipo_doc, $documento, $nombre);
    mysqli_stmt_execute($ins);
    mysqli_stmt_close($ins);

    header("Location: $volver&ok=creado"); exit;
}

// --- EDITAR ---
if ($accion === 'editar') {
    $nombre   = strtoupper(trim($_POST['nombre']   ?? ''));
    $tipo_doc = $_POST['tipo_doc'] ?? 'CC';
    if (!in_array($tipo_doc, $tipos_ok)) $tipo_doc = 'CC';

    if ($nombre === '' || $idAprendiz <= 0) {
        header("Location: $volver&err=campos"); exit;
    }

    $upd = mysqli_prepare($conexion,
        "UPDATE aprendiz SET nombre = ?, tipo_doc = ? WHERE id = ? AND idFicha = ?");
    mysqli_stmt_bind_param($upd, 'ssii', $nombre, $tipo_doc, $idAprendiz, $idFicha);
    mysqli_stmt_execute($upd);
    mysqli_stmt_close($upd);

    header("Location: $volver&ok=editado"); exit;
}

// --- ELIMINAR ---
if ($accion === 'eliminar') {
    if ($idAprendiz <= 0) { header("Location: $volver"); exit; }

    $del = mysqli_prepare($conexion,
        "DELETE FROM aprendiz WHERE id = ? AND idFicha = ?");
    mysqli_stmt_bind_param($del, 'ii', $idAprendiz, $idFicha);
    mysqli_stmt_execute($del);
    mysqli_stmt_close($del);

    header("Location: $volver&ok=eliminado"); exit;
}

header("Location: $volver"); exit;
