<?php
// =============================================================
// index.php — Inicio: lista de fichas
// =============================================================
require 'conexion.php';
require 'funciones.php';

// Crear ficha
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accion'] ?? '') === 'crear_ficha') {
    $numero   = preg_replace('/[^0-9]/', '', trim($_POST['numero'] ?? ''));
    $programa = trim($_POST['programa'] ?? 'Tecnólogo en Análisis y Desarrollo de Software');
    if ($programa === '') $programa = 'Tecnólogo en Análisis y Desarrollo de Software';

    if ($numero !== '') {
        $chk = mysqli_prepare($conexion, "SELECT id FROM ficha WHERE numero = ? LIMIT 1");
        mysqli_stmt_bind_param($chk, 's', $numero);
        mysqli_stmt_execute($chk);
        mysqli_stmt_store_result($chk);
        $existe = mysqli_stmt_num_rows($chk) > 0;
        mysqli_stmt_close($chk);

        if (!$existe) {
            $ahora = date('Y-m-d H:i:s');
            $ins   = mysqli_prepare($conexion,
                "INSERT INTO ficha (numero, programa, activa, creada_en) VALUES (?, ?, 1, ?)");
            mysqli_stmt_bind_param($ins, 'sss', $numero, $programa, $ahora);
            mysqli_stmt_execute($ins);
            mysqli_stmt_close($ins);
            header('Location: index.php?ok=ficha_creada');
            exit;
        } else {
            header('Location: index.php?err=duplicada');
            exit;
        }
    }
}

// Listar fichas con checkpoint activo si lo tienen
$fichas = mysqli_fetch_all(mysqli_query($conexion,
    "SELECT f.*,
        (SELECT id FROM checkpoint WHERE idFicha = f.id AND estado = 'Abierto' LIMIT 1) AS idCpAbierto,
        (SELECT tipo FROM checkpoint WHERE idFicha = f.id AND estado = 'Abierto' LIMIT 1) AS tipoCpAbierto
     FROM ficha f ORDER BY f.activa DESC, f.numero ASC"
), MYSQLI_ASSOC);

$mostrarFormFicha = isset($_GET['nueva']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Asistencia — SENA</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Sistema de Asistencia — SENA</h1>
    <p>Panel principal</p>
</header>

<main>
    <h2>Fichas registradas</h2>

    <?php if (isset($_GET['ok'])): ?>
    <div class="alerta alerta-ok">
        <?php echo $_GET['ok'] === 'ficha_creada' ? 'Ficha creada correctamente.' : 'Operación exitosa.'; ?>
    </div>
    <?php endif; ?>
    <?php if (isset($_GET['err'])): ?>
    <div class="alerta alerta-error">
        <?php echo $_GET['err'] === 'duplicada' ? 'Ya existe una ficha con ese número.' : 'Error inesperado.'; ?>
    </div>
    <?php endif; ?>

    <!-- Botón crear ficha -->
    <?php if (!$mostrarFormFicha): ?>
    <a href="index.php?nueva=1" class="btn" style="margin-bottom:18px;">+ Crear ficha</a>
    <?php else: ?>
    <!-- Formulario crear ficha -->
    <div class="card card-verde" style="max-width:560px;margin-bottom:20px;">
        <h3 style="margin-top:0;">Nueva ficha</h3>
        <form method="POST" action="index.php">
            <input type="hidden" name="accion" value="crear_ficha">
            <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
                <div>
                    <label style="display:block;font-size:13px;font-weight:bold;margin-bottom:4px;">
                        Número de ficha *
                    </label>
                    <input type="text" name="numero" placeholder="Ej: 3413974"
                           maxlength="10" required style="width:150px;" autofocus>
                </div>
                <div style="flex:1;min-width:200px;">
                    <label style="display:block;font-size:13px;font-weight:bold;margin-bottom:4px;">
                        Programa
                    </label>
                    <input type="text" name="programa"
                           value="Tecnólogo en Análisis y Desarrollo de Software"
                           maxlength="150" style="width:100%;">
                </div>
                <div>
                    <button type="submit" class="btn">Crear</button>
                    <a href="index.php" class="btn btn-secondary">Cancelar</a>
                </div>
            </div>
        </form>
    </div>
    <?php endif; ?>

    <!-- Lista de fichas -->
    <?php if (empty($fichas)): ?>
    <div class="alerta alerta-info">
        No hay fichas registradas. Crea la primera usando el botón de arriba.
    </div>
    <?php else: ?>
    <div class="grid-fichas">
        <?php foreach ($fichas as $f): ?>
        <div class="ficha-card">
            <div class="ficha-num"><?php echo htmlspecialchars($f['numero']); ?></div>
            <div class="ficha-prog"><?php echo htmlspecialchars($f['programa']); ?></div>
            <div class="ficha-est">
                <?php if ($f['idCpAbierto']): ?>
                <span class="badge badge-abierto">
                    ● <?php echo labelCheckpoint($f['tipoCpAbierto']); ?> activo
                </span>
                <?php elseif ($f['activa']): ?>
                <span style="color:#555;font-size:12px;">Sin jornada activa</span>
                <?php else: ?>
                <span style="color:#aaa;font-size:12px;">Inactiva</span>
                <?php endif; ?>
            </div>
            <div class="ficha-btn">
                <a href="panel_ficha.php?id=<?php echo $f['id']; ?>" class="btn">
                    Abrir ficha
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</main>

<footer>Sistema de Asistencia &mdash; SENA</footer>
</body>
</html>
