<?php
// =============================================================
// conexion.php — Conexión a MySQL
// =============================================================

$host    = 'localhost';
$usuario = 'root';   // Cambiar según tu entorno
$clave   = '';       // Cambiar según tu entorno
$base    = 'asistencia_sena';

$conexion = mysqli_connect($host, $usuario, $clave, $base);

if (!$conexion) {
    http_response_code(500);
    die('<p style="font-family:Arial;color:red;padding:20px;">
        Error de conexión: ' . mysqli_connect_error() . '
    </p>');
}

mysqli_set_charset($conexion, 'utf8mb4');
